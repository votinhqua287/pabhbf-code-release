"""Independent check of the referee's claim (c): how much location leakage do
simple statistics already give, with and without shadowing, NF vs FF channels."""
import numpy as np

rng = np.random.default_rng(1)
C0, FC = 299_792_458.0, 28e9
LAM = C0 / FC
D = LAM / 2
NT, L, KAPPA, ETA = 64, 4, 10.0, 2.0
RMIN, RMAX, THM = 2.0, 20.0, np.pi / 3
N = 3000
dn = (np.arange(1, NT + 1) - (NT + 1) / 2) * D


def b_nf(r, th):  # r, th: (...,) -> (..., NT)
    r = np.asarray(r)[..., None]
    th = np.asarray(th)[..., None]
    dist = np.sqrt(r**2 + dn**2 - 2 * r * dn * np.sin(th))
    return np.exp(-1j * 2 * np.pi / LAM * (dist - r)) / np.sqrt(NT)


def a_ff(th):
    th = np.asarray(th)[..., None]
    return np.exp(1j * 2 * np.pi / LAM * dn * np.sin(th)) / np.sqrt(NT)


def drop(n):
    r = np.sqrt(rng.uniform(RMIN**2, RMAX**2, n))
    th = rng.uniform(-THM, THM, n)
    return r, th


r, th = drop(N)
p = np.stack([r * np.cos(th), r * np.sin(th)], 1)
trS = np.trace(np.cov(p.T))
sr, sth = drop(N * L)
sr, sth = sr.reshape(N, L), sth.reshape(N, L)
nlos = (rng.standard_normal((N, L)) + 1j * rng.standard_normal((N, L))) / np.sqrt(2)
zeta = rng.uniform(0, 2 * np.pi, N)
shadow_std_normal = rng.standard_normal(N)


def channels(model, sigma_db):
    beta = r ** (-ETA) * 10 ** (sigma_db * shadow_std_normal / 10)
    a0 = np.sqrt(KAPPA * beta / (KAPPA + 1)) * np.exp(1j * zeta)
    al = np.sqrt(beta / ((KAPPA + 1) * L))[:, None] * nlos
    resp = b_nf if model == "NF" else (lambda rr, tt: a_ff(tt))
    h = a0[:, None] * resp(r, th) + np.einsum("nl,nlm->nm", al, resp(sr, sth))
    return np.sqrt(NT) * h


def leak(est):
    return 1 - np.mean(np.sum((p - est) ** 2, 1)) / trS


def leak_r(rhat):
    return 1 - np.mean((r - rhat) ** 2) / np.var(r)


# genie bounds
ecos = np.sin(THM) / THM
print(f"tr(Sigma_p)={trS:.2f} m^2, Var(r)={np.var(r):.2f} m^2")
print(f"genie exact range: Lambda={leak(np.stack([r*ecos, 0*r],1)):.3f}")
print(f"genie exact angle: Lambda={leak(np.stack([r.mean()*np.cos(th), r.mean()*np.sin(th)],1)):.3f}")

sgrid = np.linspace(-np.sin(THM) * 1.05, np.sin(THM) * 1.05, 512)
A = a_ff(np.arcsin(sgrid))  # (512, NT)
rgrid = 1 / np.linspace(1 / 25, 1 / 1.5, 60)
RR, SS = np.meshgrid(rgrid, sgrid, indexing="ij")
Bnf = b_nf(RR.ravel(), np.arcsin(SS.ravel()))  # (60*512, NT)
edges = np.linspace(-THM, THM, 9)
centers = (edges[:-1] + edges[1:]) / 2

for model in ("NF", "FF"):
    for sdb in (0.0, 6.0):
        h = channels(model, sdb)
        g = np.sum(np.abs(h) ** 2, 1) / NT
        rhat_gain = np.clip(g ** (-1 / ETA), 0.5, 50)
        thhat = np.arcsin(sgrid[np.argmax(np.abs(h @ A.conj().T), 1)])
        est_mf = np.stack([rhat_gain * np.cos(thhat), rhat_gain * np.sin(thhat)], 1)
        sec = centers[np.clip(np.digitize(thhat, edges) - 1, 0, 7)]
        est_sec = np.stack([rhat_gain * np.cos(sec), rhat_gain * np.sin(sec)], 1)
        idx = np.concatenate([np.argmax(np.abs(h[i:i + 250] @ Bnf.conj().T), 1) for i in range(0, N, 250)])
        rhat_nf, thhat_nf = RR.ravel()[idx], np.arcsin(SS.ravel()[idx])
        est_nf = np.stack([rhat_nf * np.cos(thhat_nf), rhat_nf * np.sin(thhat_nf)], 1)
        print(f"{model} shadow={sdb:.0f}dB | MF angle+gain range: Lambda={leak(est_mf):.3f}, "
              f"8-sector+gain: {leak(est_sec):.3f}, NF 2D-MF: {leak(est_nf):.3f} | "
              f"range-only Lambda_r: gain {leak_r(rhat_gain):.3f}, NF-MF {leak_r(rhat_nf):.3f}")
