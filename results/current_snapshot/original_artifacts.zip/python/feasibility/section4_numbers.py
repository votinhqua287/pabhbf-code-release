"""Numbers for Section IV (v3), computed with methods independent of the Monte Carlo helpers.

Region: r in [8, 40] m, |theta| <= pi/3, users uniform in area. 28 GHz, d = lambda/2.
"""
import numpy as np
from scipy.special import fresnel
from scipy.optimize import brentq

C0, FC = 299_792_458.0, 28e9
LAM = C0 / FC
DSP = LAM / 2
RMIN, RMAX, THM = 8.0, 40.0, np.pi / 3
AREA = THM * (RMAX**2 - RMIN**2)
print(f"|R| = {AREA:.1f} m^2, log2(|R|/pi) = {np.log2(AREA / np.pi):.3f} bits")

# ---- covering of R by discs of radius 1 m (hexagonal covering lattice, spacing sqrt(3) rho)
rho = 1.0
a = np.sqrt(3) * rho
xs = np.arange(0.0, RMAX + 2 * rho, a)
ys = np.arange(-RMAX - 2 * rho, RMAX + 2 * rho, a * np.sqrt(3) / 2)
pts = []
for i, y in enumerate(ys):
    off = a / 2 if i % 2 else 0.0
    for x in xs + off:
        pts.append((x, y))
pts = np.array(pts)
rng = np.random.default_rng(0)
n = 400000
r = np.sqrt(rng.uniform(RMIN**2, RMAX**2, n))
th = rng.uniform(-THM, THM, n)
P = np.stack([r * np.cos(th), r * np.sin(th)], 1)
# keep only lattice points whose disc meets R (distance from point to R <= rho, checked on a dense sample + boundary)
bt = np.linspace(-THM, THM, 4000)
br = np.linspace(RMIN, RMAX, 4000)
boundary = np.concatenate([
    np.stack([RMIN * np.cos(bt), RMIN * np.sin(bt)], 1), np.stack([RMAX * np.cos(bt), RMAX * np.sin(bt)], 1),
    np.stack([br * np.cos(THM), br * np.sin(THM)], 1), np.stack([br * np.cos(-THM), br * np.sin(-THM)], 1)])
from scipy.spatial import cKDTree
tree_pts = cKDTree(np.concatenate([P, boundary]))
near = np.array([len(tree_pts.query_ball_point(p, rho)) > 0 for p in pts])
centres = pts[near]
d_cover, _ = cKDTree(centres).query(np.concatenate([P, boundary]))
print(f"hexagonal covering: {len(centres)} discs, max distance to nearest centre = {d_cover.max():.4f} m, "
      f"ceil(log2 N) = {int(np.ceil(np.log2(len(centres))))} bits")

# ---- beta_Delta from the Fresnel-integral correlation |G(beta)| = |C(beta) + j S(beta)| / beta
def absG(beta):
    S, Cc = fresnel(beta)
    return np.hypot(Cc, S) / beta

beta_half = brentq(lambda b: absG(b) - 0.5, 0.5, 2.5)
print(f"beta_0.5 = {beta_half:.4f}")
for nt in (64, 128, 256):
    D = (nt - 1) * DSP
    tau_d = 2 * beta_half**2 * LAM / (nt**2 * DSP**2)
    fres = 0.5 * np.sqrt(D**3 / LAM)
    rayl = 2 * D**2 / LAM
    # fraction of the area of R with tau_k > tau_d, i.e. r < cos^2(theta)/tau_d (exact integral over theta)
    t = np.linspace(-THM, THM, 200001)
    rb = np.clip(np.cos(t) ** 2 / tau_d, RMIN, RMAX)
    frac = np.trapezoid((rb**2 - RMIN**2) / 2, t) / AREA
    print(f"Nt={nt}: tau_Delta={tau_d:.5f} 1/m, 1/tau_Delta={1 / tau_d:.2f} m, Fresnel distance={fres:.2f} m, "
          f"Rayleigh distance={rayl:.1f} m, fraction with range-bounded cell={frac:.4f}")

    # heaviest focal cell (a_u = 2/Nt, a_tau = tau_d): exact tau-integral, numerical u-integral, grid search over centres
    a_u = 2.0 / nt
    su = np.sin(THM)
    best = 0.0
    tau_min_all, tau_max_all = np.cos(THM) ** 2 / RMAX, 1.0 / RMIN
    for uc in np.linspace(-su, su, 241):
        u = np.linspace(max(-su, uc - a_u), min(su, uc + a_u), 401)
        w = (1 - u**2)
        tlo_r, thi_r = w / RMAX, w / RMIN
        for tc in np.linspace(tau_min_all, tau_max_all, 241):
            lo = np.maximum(tc - tau_d, tlo_r)
            hi = np.minimum(tc + tau_d, thi_r)
            ok = hi > lo
            integrand = np.where(ok, w**1.5 * (1 / (2 * np.where(ok, lo, 1) ** 2) - 1 / (2 * np.where(ok, hi, 1) ** 2)), 0.0)
            mass = np.trapezoid(integrand, u) / AREA
            best = max(best, mass)
    print(f"   heaviest focal cell mass L_V = {best:.5f}, log2(1/L_V) = {np.log2(1 / best):.3f} bits")

    if nt == 256:
        # radius of the focal cell intersected with R, by boundary parametrization
        m = 3000
        rk = np.sqrt(rng.uniform(RMIN**2, RMAX**2, m))
        tk = rng.uniform(-THM, THM, m)
        uk, tauk = np.sin(tk), np.cos(tk) ** 2 / rk
        rad = np.zeros(m)
        e = np.linspace(-1, 1, 201)
        for i in range(m):
            U = np.concatenate([np.full(201, uk[i] - a_u), np.full(201, uk[i] + a_u), uk[i] + a_u * e, uk[i] + a_u * e])
            T = np.concatenate([tauk[i] + tau_d * e, tauk[i] + tau_d * e, np.full(201, tauk[i] - tau_d), np.full(201, tauk[i] + tau_d)])
            U = np.clip(U, -su, su)
            T = np.clip(T, (1 - U**2) / RMAX, (1 - U**2) / RMIN)
            R = (1 - U**2) / T
            TH = np.arcsin(U)
            rad[i] = np.max(np.hypot(R * np.cos(TH) - rk[i] * np.cos(tk[i]), R * np.sin(TH) - rk[i] * np.sin(tk[i])))
        print(f"   P(rho_V > 1 m) = {np.mean(rad > 1.0):.3f}, P(rho_V > 4 m) = {np.mean(rad > 4.0):.3f}, median rho_V = {np.median(rad):.2f} m")

# counting bound thresholds
print(f"disc rho=1: counting bound 2^TB * pi/|R| < 1 iff TB < {np.log2(AREA / np.pi):.3f}")
