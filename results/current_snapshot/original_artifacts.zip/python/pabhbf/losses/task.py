"""Communication losses and action metrics (Task 9)."""
from __future__ import annotations

import torch
import torch.nn.functional as F


def wsr_from_shares(A: torch.Tensor, shares: torch.Tensor, w: torch.Tensor, sigma2: torch.Tensor) -> torch.Tensor:
    """Weighted sum rate for fixed beams and RZF directions as a differentiable function of the power shares.

    A[b, k, j] = |h_k^H F_RF fbar_j|^2 / ||F_RF fbar_j||^2 (true channels), so that
    gamma_k = p_k A_kk / (sum_{j != k} p_j A_kj + sigma^2).
    """
    sig = torch.diagonal(A, dim1=1, dim2=2) * shares
    tot = torch.einsum("bkj,bj->bk", A, shares)
    return (w * torch.log2(1.0 + sig / (tot - sig + sigma2[:, None]))).sum(dim=1)


def communication_loss(out, batch: dict, weights: dict):
    """Imitation of the teacher's schedule and beam groups, and the realized-rate loss of the power shares.

    The rate term evaluates the controller's shares on the teacher's schedule and beams, normalized by the teacher's
    weighted sum rate of the same drop.
    """
    sched_logits, group_logits, power_logits = out
    l_sched = F.binary_cross_entropy_with_logits(sched_logits, batch["sched_label"])
    l_group = F.cross_entropy(group_logits.reshape(-1, group_logits.shape[-1]), batch["groups_all"].reshape(-1))
    logp = torch.log_softmax(torch.gather(power_logits, 1, batch["sched"]), dim=1)
    l_power = -(batch["shares"] * logp).sum(1).mean()
    ratio = wsr_from_shares(batch["A"], logp.exp(), batch["w_S"], batch["sigma2"]) / batch["wsr_teacher"]
    total = (weights.get("sched", 1.0) * l_sched + weights.get("group", 1.0) * l_group
             + weights.get("power", 0.1) * l_power - weights.get("rate", 1.0) * ratio.mean())
    return total, dict(sched=float(l_sched.detach()), group=float(l_group.detach()), power=float(l_power.detach()),
                       rate_ratio=float(ratio.mean().detach()))


@torch.no_grad()
def action_metrics(sched, groups, sched_teacher, groups_all_teacher) -> dict:
    overlap = (sched[:, :, None] == sched_teacher[:, None, :]).any(-1).float().mean()
    group_acc = (groups == torch.gather(groups_all_teacher, 1, sched)).float().mean()
    return dict(sched_overlap=float(overlap), group_acc=float(group_acc))
