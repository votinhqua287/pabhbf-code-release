"""Location grid, adversary and privacy losses, and disc-MAP decoding (Tasks 10-11).

The adversary is a classifier over square cells of the service region. Its posterior q(c | z) gives
- a disc-MAP location estimate: the cell center whose rho-disc collects the largest posterior mass, which targets the
  tolerance-region leakage directly;
- a variational bound I(C; Z) >= H(C) - E[-log q(C | Z)] on the cell information in the representation.
The encoder's privacy loss is either KL(prior || q) (maximum-entropy adversarial learning) or the negated adversary
cross-entropy (gradient reversal).
"""
from __future__ import annotations

from dataclasses import dataclass

import numpy as np
import torch
import torch.nn.functional as F


@dataclass
class Grid:
    cell: float
    x0: float
    y0: float
    nx: int
    ny: int
    lookup: np.ndarray   # (nx*ny,) active-cell index or -1
    centers: np.ndarray  # (C, 2)
    prior: np.ndarray    # (C,) empirical cell frequencies of the fitting positions
    disc: np.ndarray     # (C, C) 1 where two centers lie within rho

    @property
    def C(self) -> int:
        return len(self.centers)

    @property
    def entropy_nats(self) -> float:
        return float(-(self.prior * np.log(self.prior)).sum())

    def index(self, xy) -> np.ndarray:
        xy = np.asarray(xy, float).reshape(-1, 2)
        ix = np.clip(np.floor((xy[:, 0] - self.x0) / self.cell).astype(int), 0, self.nx - 1)
        iy = np.clip(np.floor((xy[:, 1] - self.y0) / self.cell).astype(int), 0, self.ny - 1)
        idx = self.lookup[ix * self.ny + iy]
        miss = np.flatnonzero(idx < 0)
        for i in miss:  # a position in a cell without fitting samples maps to the nearest active center
            idx[i] = int(np.argmin(((self.centers - xy[i]) ** 2).sum(1)))
        return idx


def make_grid(xy_fit, cell: float, rho: float, r_max: float, theta_max: float) -> Grid:
    xy = np.asarray(xy_fit, float).reshape(-1, 2)
    x0, y0 = 0.0, -r_max * np.sin(theta_max)
    nx, ny = int(np.ceil(r_max / cell)), int(np.ceil(2.0 * r_max * np.sin(theta_max) / cell))
    ix = np.clip(np.floor((xy[:, 0] - x0) / cell).astype(int), 0, nx - 1)
    iy = np.clip(np.floor((xy[:, 1] - y0) / cell).astype(int), 0, ny - 1)
    counts = np.bincount(ix * ny + iy, minlength=nx * ny)
    active = np.flatnonzero(counts)
    lookup = -np.ones(nx * ny, int)
    lookup[active] = np.arange(len(active))
    centers = np.stack([x0 + (active // ny + 0.5) * cell, y0 + (active % ny + 0.5) * cell], axis=1)
    dist = np.sqrt(((centers[:, None, :] - centers[None, :, :]) ** 2).sum(-1))
    return Grid(cell, x0, y0, nx, ny, lookup, centers, counts[active] / counts.sum(), (dist <= rho).astype(np.float32))


def disc_map(probs: np.ndarray, grid: Grid, batch: int = 4096) -> np.ndarray:
    out = np.empty((len(probs), 2))
    for i in range(0, len(probs), batch):
        out[i:i + batch] = grid.centers[np.argmax(probs[i:i + batch] @ grid.disc, axis=1)]
    return out


def posterior_mean(probs: np.ndarray, grid: Grid) -> np.ndarray:
    return probs @ grid.centers


def adversary_loss(logits: torch.Tensor, cell: torch.Tensor) -> torch.Tensor:
    return F.cross_entropy(logits, cell)


def privacy_loss(logits: torch.Tensor, cell: torch.Tensor, log_prior: torch.Tensor, kind: str = "maxent") -> torch.Tensor:
    if kind == "maxent":
        return (log_prior.exp() * (log_prior - torch.log_softmax(logits, dim=1))).sum(1).mean()
    if kind == "reversal":
        return -F.cross_entropy(logits, cell)
    raise ValueError(kind)
