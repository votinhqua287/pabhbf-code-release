"""LaTeX tables from saved results (Task 17). Writes manuscript/tables/*.tex.

  python -m pabhbf.plots.make_tables [--lam-main 0.03]

Confidence intervals are 95 % Student-t half-widths over training seeds and appear only when a tag has several seeds.
The latency of a scheme is K times the encoder time per user plus the controller and tool times per drop. It comes from
results/aggregated/runtime_benchmark.json (eval/runtime_benchmark.py, all schemes and the teacher timed back to back) when
that file exists, and otherwise from the runtimes recorded by eval/evaluate.py and eval/runtime_teacher.py.
"""
from __future__ import annotations

import argparse
import glob
import json
import math
import pathlib

import numpy as np

from ..phy import codebook as cbm
from ..utils.config import ROOT, load_config, system_params
from .paper_figures import LEAK, RAW, RMSE, fmt, load_agg, m

TAB = ROOT / "manuscript" / "tables"
TEACHER_RUNTIME = ROOT / "results" / "aggregated" / "runtime_teacher.json"


def num(x, digits=2):
    if x is None or not np.isfinite(x):
        return "--"
    return f"$-${-x:.{digits}f}" if x < 0 else f"{x:.{digits}f}"  # math minus sign with text digits


def pm(agg, tag, key, digits=2):
    mu, ci = m(agg, tag, key), m(agg, tag, key, "ci95")
    if not np.isfinite(mu):
        return "--"
    return f"{mu:.{digits}f}" if not np.isfinite(ci) else f"{mu:.{digits}f}\\,$\\pm$\\,{ci:.{digits}f}"


def seed_value(agg, tag, key, seed=1):
    try:
        g = agg[tag]
        return g["metrics"][key]["values"][g["seeds"].index(seed)]
    except (KeyError, ValueError, IndexError):
        return np.nan


BENCHMARK = ROOT / "results" / "aggregated" / "runtime_benchmark.json"


def latency_ms(agg, tag, K: int) -> float:
    """Latency per drop from eval/runtime_benchmark.py when it exists (all schemes timed back to back), else from the evaluation."""
    if BENCHMARK.exists():
        return float(json.loads(BENCHMARK.read_text())["schemes"].get(tag, {}).get("latency_ms_per_drop", np.nan))
    return float(K * m(agg, tag, "runtime.encoder_ms_per_user") + m(agg, tag, "runtime.controller_ms_per_drop")
                 + m(agg, tag, "runtime.tools_ms_per_drop"))


def teacher_latency_ms() -> float:
    if BENCHMARK.exists():
        return float(json.loads(BENCHMARK.read_text())["teacher"]["teacher_ms_per_drop"])
    return float(json.loads(TEACHER_RUNTIME.read_text())["teacher_ms_per_drop"]) if TEACHER_RUNTIME.exists() else np.nan


def write(name: str, body: str):
    TAB.mkdir(parents=True, exist_ok=True)
    (TAB / f"{name}.tex").write_text(body, encoding="utf-8")


def table_parameters():
    cfg = load_config()
    p = system_params(cfg)
    cb = cbm.polar_codebook(p)
    reg, ch, rep, tr, ds = cfg["region"], cfg["channel"], cfg["representation"], cfg["training"], cfg["dataset"]
    rows = [
        ("Carrier frequency (narrowband model)", f"{float(cfg['carrier_frequency_hz']) / 1e9:g}\\,GHz"),
        ("Reference distance $\\rref$", f"$r_{{\\max}}={fmt(reg['r_max_m'])}$\\,m"),
        ("Window $T$, adversary steps $T_{\\mathrm{a}}$, weights $c_{\\mathrm{P}}$, $c_{\\mathrm{R}}$", f"{ds['intervals_per_block']}, {cfg['privacy']['attacker_steps_per_update']}, 0.1, 1"),
        ("Budget update: step $\\eta_{\\mu}$, initial $\\mu$", "5, 0.1"),
        ("Antennas $\\Nt$, RF chains $\\NRF$, streams $\\Ns$", f"{p.Nt}, {p.Nrf}, {p.Ns}"),
        ("Requesting users $K$, weights $w_k$", f"{p.K}, $\\{{{', '.join(fmt(w) for w in cfg['weights']['classes'])}\\}}$ equiprobable"),
        ("Service region", f"$r\\in[{fmt(reg['r_min_m'])},{fmt(reg['r_max_m'])}]$\\,m, $|\\theta|\\le{fmt(reg['theta_max_deg'])}^\\circ$"),
        ("Rician factor $\\kappa$, scatterers $L$, radius $r_{\\mathrm{sc}}$", f"{fmt(ch['rician_k_db'])}\\,dB, {ch['num_nlos_paths']}, {fmt(ch['scatterer_radius_m'])}\\,m"),
        ("Path-loss exponent $\\eta$, shadowing $\\sigma_{\\zeta}$", f"{fmt(ch['pathloss_exponent'])}, {fmt(ch['shadowing_std_db'])}\\,dB"),
        ("Estimation error $\\sigest$ (relative to $\\beta(\\rref)$)", f"$-{fmt(cfg['estimation']['pilot_snr_db'])}$\\,dB"),
        ("Reference SNR", f"{fmt(min(cfg['snr_db_list']))} to {fmt(max(cfg['snr_db_list']))}\\,dB, step {fmt(cfg['snr_db_list'][1] - cfg['snr_db_list'][0])}\\,dB"),
        ("Phase bits $\\Nb$, correlation $\\Delta$, codewords $M$, groups $G$", f"{p.phase_bits}, {fmt(p.delta_cb)}, {cb.M}, {p.G}"),
        ("Latent $d_z$, bits $b_z$, payload $B$", f"{rep['latent_dim']}, {rep['bits_per_entry']}, {rep['latent_dim'] * rep['bits_per_entry']} bits"),
        ("Tolerance radius $\\rho$, best fixed guess $\\Lambda_{\\rho}^{0}$", f"{fmt(cfg['privacy']['tolerance_radius_m'])}\\,m, {np.pi * cfg['privacy']['tolerance_radius_m'] ** 2 / p.area:.4f}"),
        ("Drops (train, validation, test, attack)", f"{ds['num_train_drops']}, {ds['num_val_drops']}, {ds['num_test_drops']}, {ds['num_attack_drops']}"),
        ("Epochs (pretraining, adversarial), batch, learning rate", f"{tr['epochs_pretrain']}, {tr['epochs_adversarial']}, {tr['batch_size']} drops, $10^{{-3}}$"),
        ("Training seeds", ", ".join(str(s) for s in tr["seeds"])),
    ]
    body = ["\\begin{tabular}{p{0.50\\columnwidth}p{0.38\\columnwidth}}", "\\toprule", "Parameter & Value\\\\", "\\midrule"]
    body += [f"{a} & {b}\\\\" for a, b in rows]
    body += ["\\bottomrule", "\\end{tabular}"]
    write("tab_parameters", "\n".join(body) + "\n")
    return dict(M=cb.M)


def table_methods():
    """Table II: what each scheme exports per user, its payload, how it limits the export, and its encoder cost.

    The payloads follow the constructors in models/representations.py for the configured Nt and B.
    """
    cfg = load_config()
    p = system_params(cfg)
    rep = cfg["representation"]
    dz, bz = rep["latent_dim"], rep["bits_per_entry"]
    B = dz * bz
    raw = 2 * p.Nt * rep["raw_csi_bits_per_entry"]
    cb = cbm.polar_codebook(p)
    b4 = max(1, B // (2 * p.Nt))
    n4 = min(p.Nt, B // (2 * b4))
    idx_bits, gain_bits = math.ceil(math.log2(cb.M)), 4
    m6 = B // (idx_bits + gain_bits)
    n_pw = cbm.dft_codebook(p, bits=None).M
    proj = "$\\mathcal{O}(\\Nt d_z)$"
    mlp = "$\\mathcal{O}(\\Nt W_{\\mathrm{e}}+W_{\\mathrm{e}}^2+W_{\\mathrm{e}}d_z)$"
    rows = [
        ("B0 teacher", "Estimates $\\hh_k$", raw, "None", "Table~\\ref{tab:complexity}"),
        ("B1 raw CSI", "Input $\\mathbf{x}_k$", raw, "None", "--"),
        ("B2 PCA", "%d principal coefficients, %d bits each" % (dz, bz), B, "Truncation", proj),
        ("B3 random projection", "%d random coefficients, %d bits each" % (dz, bz), B, "Random basis", proj),
        ("B4 scalar quantization", "%d entries of $\\mathbf{x}_k$, %d bit per real part" % (n4, b4), 2 * n4 * b4, "Quantization", "$\\mathcal{O}(B)$"),
        ("B5 Gaussian noise", "B2 coefficients plus Gaussian noise", B, "Gaussian noise", proj),
        ("B6 strongest codewords", "%d indices of $\\mathcal{C}$ and their gains" % m6, m6 * (idx_bits + gain_bits), "Sparse beam report", "$\\mathcal{O}(M\\Nt)$"),
        ("B7 autoencoder", "Encoder trained for reconstruction", B, "Bottleneck", mlp),
        ("B8 angle domain", "%d principal coefficients of %d plane-wave beam gains" % (dz, n_pw), B, "No range sampling", "$\\mathcal{O}(\\Nt^2)$"),
        ("B9 Laplace noise", "Clipped B2 coefficients plus Laplace noise", B, "Laplace mechanism", proj),
        ("PAB-HBF", "Encoder trained against an adversary", B, "Adversarial training", mlp),
    ]
    body = ["\\begin{tabular}{llcll}", "\\toprule", "Scheme & Exported per user & $B$ (bits) & Mechanism & Encoder operations\\\\", "\\midrule"]
    body += [f"{a} & {b} & {c} & {d} & {e}\\\\" for a, b, c, d, e in rows]
    body += ["\\bottomrule", "\\end{tabular}"]
    write("tab_methods", "\n".join(body) + "\n")
    return dict(plane_wave_beams=n_pw, b4_entries=n4, b6_codewords=m6)


def table_main(lam_main: float, sigmas=(0.2, 0.8), epsilons=(100, 10)):
    e1, base = load_agg("e1"), load_agg("baselines")
    if not e1:
        return None
    K = system_params(load_config()).K
    rows = [("PAB-HBF", e1, f"lam{fmt(lam_main)}"), ("PAB-HBF, $\\mu=0$", e1, "lam0"), ("B1 raw CSI", base, "raw_csi"),
            ("B2 PCA", base, "pca"), ("B3 random projection", base, "random_projection"), ("B4 scalar quantization", base, "scalar_quant")]
    rows += [(f"B5, $\\sigma_{{\\mathrm{{B5}}}}={fmt(s)}$", base, f"gaussian_pca_{fmt(s)}") for s in sigmas]
    rows += [("B6 strongest codewords", base, "top_m_beams"), ("B7 autoencoder", base, "autoencoder"), ("B8 angle domain", base, "angle_domain")]
    rows += [(f"B9, $\\varepsilon_{{\\mathrm{{DP}}}}={fmt(e)}$", base, f"laplace_pca_{e}") for e in epsilons]
    # every E1 run is evaluated on the same test drops, so any tag gives the teacher rate
    teacher = next((v for v in (m(e1, t, "utility.teacher_wsr") for t in (f"lam{fmt(lam_main)}", "lam0")) if np.isfinite(v)), np.nan)
    teacher_ms = teacher_latency_ms()
    body = ["\\begin{tabular}{lcccccc}", "\\toprule",
            "Scheme & WSR (bit/s/Hz) & $\\Lambda_{\\rho}$ & RMSE (m) & NMSE (dB) & $B$ (bits) & Latency (ms)\\\\", "\\midrule",
            f"Teacher (B0) & {num(teacher)} & -- & -- & -- & {2 * system_params(load_config()).Nt * 16} & {num(teacher_ms, 1)}\\\\"]
    for label, agg, tag in rows:
        if tag not in agg:
            continue
        body.append(f"{label} & {pm(agg, tag, 'utility.wsr')} & {pm(agg, tag, LEAK, 3)} & {pm(agg, tag, RMSE)} & "
                    f"{num(m(agg, tag, 'privacy.decoder.nmse_db'))} & {int(m(agg, tag, 'payload_bits'))} & {num(latency_ms(agg, tag, K), 1)}\\\\")
    body += ["\\bottomrule", "\\end{tabular}"]
    write("tab_main", "\n".join(body) + "\n")
    return dict(rows=[t for _, _, t in rows])


def table_ablations(lam_main: float):
    ab, e1 = load_agg("ablations"), load_agg("e1")
    if not ab:
        return None
    lam = fmt(lam_main)
    rows = [("Reference", e1, f"lam{lam}"), ("No adversary ($\\mu=0$)", e1, "lam0"),
            ("Variational bottleneck", ab, f"abl_vib_lam{lam}"), ("No rate loss ($c_{\\mathrm{R}}=0$)", ab, f"abl_norate_lam{lam}"),
            ("No quantizer", ab, f"abl_continuous_lam{lam}"), ("Gradient reversal", ab, f"abl_reversal_lam{lam}"),
            ("Antenna-domain input", ab, f"abl_antennainput_lam{lam}"), ("Plane-wave gains input", ab, f"abl_angleinput_lam{lam}"),
            ("Convolutional encoder", ab, f"abl_cnn_lam{lam}"), ("One adversary step", ab, f"abl_onestep_lam{lam}")]
    body = ["\\begin{tabular}{lcccc}", "\\toprule", "Variant & Ratio & $\\Lambda_{\\rho}$ & RMSE (m) & NMSE (dB)\\\\", "\\midrule"]
    for label, agg, tag in rows:
        if tag not in agg:
            continue
        body.append(f"{label} & {num(seed_value(agg, tag, 'utility.ratio'), 3)} & {num(seed_value(agg, tag, LEAK), 3)} & "
                    f"{num(seed_value(agg, tag, RMSE))} & {num(seed_value(agg, tag, 'privacy.decoder.nmse_db'))}\\\\")
    body += ["\\bottomrule", "\\end{tabular}"]
    write("tab_ablations", "\n".join(body) + "\n")
    return dict(rows=[t for _, _, t in rows])


def table_dual():
    d = load_agg("e1d")
    if not d:
        return None
    eps_list = load_config()["privacy"]["budget_list"]
    # two seeds only: every cell lists the per-seed values instead of a confidence interval
    tr_path = ROOT / "results" / "aggregated" / "training_summary_e1d.json"
    tr = json.loads(tr_path.read_text()) if tr_path.exists() else {}

    def seeds(values, digits=3):
        return ", ".join(f"{v:.{digits}f}" for v in values)

    def last_mu(key):  # weight used in the last adversarial epoch, which produced the evaluated encoder
        log = ROOT / "results" / "raw" / "train_logs" / "pabhbf" / tr[key]["file"]
        return json.loads(log.read_text())["history"][-1]["lam"]

    body = ["\\begin{tabular}{ccccc}", "\\toprule",
            "Budget $\\epsilon$ & Last-epoch $\\mu$ & Training adversary & $\\Lambda_{\\rho}$ & Rate ratio\\\\", "\\midrule"]
    for eps in eps_list:
        tag = f"dual{fmt(eps)}"
        if tag not in d:
            continue
        g = d[tag]
        keys = [f"{tag}_s{s}" for s in g["seeds"] if f"{tag}_s{s}" in tr]
        hits = [tr[k]["hit_last"] for k in keys]
        mus = ", ".join("0" if v == 0 else f"{v:.2f}" for v in (last_mu(k) for k in keys)) or "--"
        body.append(f"{fmt(eps)} & {mus} & {seeds(hits) if hits else '--'} & "
                    f"{seeds(g['metrics'][LEAK]['values'])} & {seeds(g['metrics']['utility.ratio']['values'])}\\\\")
    body += ["\\bottomrule", "\\end{tabular}"]
    write("tab_dual", "\n".join(body) + "\n")
    return dict(budgets=eps_list)


def table_agentic():
    files = sorted(glob.glob(str(RAW / "e13_agentic" / "*.json")))
    if not files:
        return None
    ag = json.loads(pathlib.Path(files[-1]).read_text())
    names = {"direct": "Direct", "rule": "Rule-based", "search2": "Search, $C=2$", "search4": "Search, $C=4$"}
    body = ["\\begin{tabular}{lcccc}", "\\toprule", "Planner & Ratio & Latency (ms) & Calls & Bits\\\\", "\\midrule"]
    fit0 = ag["learned_fit"]
    names["learned"] = f"Learned ({fmt(fit0['mu_latency'])}, {fmt(fit0['nu_bits'])})"
    for key, v in ag["planners"].items():
        calls = sum(v["calls_per_drop"].values())
        body.append(f"{names.get(key, key)} & {v['ratio']:.3f} & {v['latency_ms_per_drop']:.1f} & {calls:.2f} & {v['exposure_bits_per_drop']:.1f}\\\\")
    # the learned tool policy refitted with other cost weights (eval/agentic.py --mu-latency --nu-bits --exp e13_agentic_costs)
    extra = sorted(glob.glob(str(RAW / "e13_agentic_costs" / "*.json")))
    for f in extra:
        d = json.loads(pathlib.Path(f).read_text())
        fit, v = d["learned_fit"], d["planners"]["learned"]
        calls = sum(v["calls_per_drop"].values())
        body.append(f"Learned ({fmt(fit['mu_latency'])}, {fmt(fit['nu_bits'])}) & {v['ratio']:.3f} & {v['latency_ms_per_drop']:.1f} & "
                    f"{calls:.2f} & {v['exposure_bits_per_drop']:.1f}\\\\")
    body += ["\\bottomrule", "\\end{tabular}"]
    write("tab_agentic", "\n".join(body) + "\n")
    return dict(source=files[-1], cost_sweep=extra)


def table_temporal():
    files = sorted(glob.glob(str(RAW / "e_temporal" / "*.json")))
    if not files:
        return None
    rows = []
    for f in files:
        d = json.loads(pathlib.Path(f).read_text())
        tag = pathlib.Path(d["checkpoint"]).name.rsplit("_s", 1)[0]
        rows.append((tag, {T: r["summary"]["leakage"] for T, r in d["results"].items()}))
    Ts = sorted({int(T) for _, r in rows for T in r})
    body = ["\\begin{tabular}{l" + "c" * len(Ts) + "}", "\\toprule", "Representation & " + " & ".join(f"$T={T}$" for T in Ts) + "\\\\", "\\midrule"]
    def label(tag):
        if tag == "raw_csi":
            return "B1 raw CSI"
        return f"PAB-HBF, $\\mu={tag[3:]}$" if tag.startswith("lam") else tag.replace("_", "\\_")

    for tag, r in rows:
        body.append(label(tag) + " & " + " & ".join(num(r.get(str(T)), 3) for T in Ts) + "\\\\")
    body += ["\\bottomrule", "\\end{tabular}"]
    write("tab_temporal", "\n".join(body) + "\n")
    return dict(files=files)


def table_phase_bits(lam_main: float):
    """E9: realized weighted sum rate (seed 1) with 2, 3 and 4 phase bits and ideal phases.

    The teacher is recomputed with the same phase resolution at the stored SNR of every test drop
    (eval/teacher_sweep.py --stored-snr). The 4-bit row uses the stored labels and the E1 evaluations.
    """
    pb, e1 = load_agg("phase_bits"), load_agg("e1")
    if not pb:
        return None
    lam = fmt(lam_main)
    body = ["\\begin{tabular}{lccc}", "\\toprule",
            f"Phase bits & Teacher (B0) & PAB-HBF, $\\mu={lam}$ & PAB-HBF, $\\mu=0$\\\\", "\\midrule"]
    rows = []
    for bits in ("2", "3", "4", "ideal"):
        if bits == "4":
            teacher = m(e1, "lam0", "utility.teacher_wsr")
            vals = [seed_value(e1, f"lam{lam}", "utility.wsr"), seed_value(e1, "lam0", "utility.wsr")]
        else:
            path = ROOT / "results" / "aggregated" / f"teacher_sweep_default_bits{bits}_stored.json"
            teacher = json.loads(path.read_text())["teacher_wsr"][0] if path.exists() else np.nan
            vals = [seed_value(pb, f"lam{lam}_bits{bits}", "utility.wsr"), seed_value(pb, f"lam0_bits{bits}", "utility.wsr")]
        cells = [f"{num(v)} ({num(v / teacher, 3)})" if np.isfinite(v) and np.isfinite(teacher) else num(v) for v in vals]
        body.append(f"{'Ideal' if bits == 'ideal' else bits} & {num(teacher)} & {cells[0]} & {cells[1]}\\\\")
        rows.append(dict(bits=bits, teacher=teacher, pab=vals[0], pab0=vals[1]))
    body += ["\\bottomrule", "\\end{tabular}"]
    write("tab_phase_bits", "\n".join(body) + "\n")
    return dict(rows=rows)


def table_attack_scaling(lam_main: float):
    """Leakage (seed 1) versus the number of attack drops (attacks/scaling.py).

    The "Standard" column repeats the evaluation of all other results (at most 40 epochs, patience 6, 20,000 drops). The
    other columns train the MLP, neighbor-based and cell attackers for at most 200 epochs with a patience of 20.
    """
    files = sorted(glob.glob(str(RAW / "attack_scaling" / "*.json")))
    if not files:
        return None
    res = {}
    for f in files:
        d = json.loads(pathlib.Path(f).read_text())
        res[(d["tag"], d["attack_drops"])] = d["leakage_common"]
    e1, e2, base = load_agg("e1"), load_agg("e2"), load_agg("baselines")
    lam = fmt(lam_main)
    rows = [(f"PAB-HBF, $\\mu={lam}$", f"lam{lam}", e1, f"lam{lam}"),
            ("PAB-HBF, $\\mu=0$", "lam0", e1, "lam0"),
            ("PAB-HBF, $\\mu=0$, $d_z=4$", "dz4_lam0", e2, "dz4_lam0"),
            ("B1 raw CSI", "raw_csi", base, "raw_csi")]
    sizes = sorted({n for _, n in res})

    def cell(v):
        return num(v, 3) if v is not None and np.isfinite(v) else "--"

    body = ["\\begin{tabular}{l" + "c" * (len(sizes) + 1) + "}", "\\toprule",
            " & Standard & \\multicolumn{" + str(len(sizes)) + "}{c}{Longer training}\\\\",
            "\\cmidrule(lr){2-2}\\cmidrule(lr){3-" + str(len(sizes) + 2) + "}",
            "Attack drops & 20,000 & " + " & ".join(f"{n:,}" for n in sizes) + "\\\\", "\\midrule"]
    out = []
    for label, tag, agg, atag in rows:
        std = seed_value(agg, atag, "privacy.leakage_common")
        vals = [res.get((tag, n)) for n in sizes]
        body.append(label + " & " + cell(std) + " & " + " & ".join(cell(v) for v in vals) + "\\\\")
        out.append(dict(tag=tag, standard=std, longer=dict(zip(sizes, vals))))
    body += ["\\bottomrule", "\\end{tabular}"]
    write("tab_attack_scaling", "\n".join(body) + "\n")
    return dict(rows=out, files=files)


def main(argv=None):
    ap = argparse.ArgumentParser()
    ap.add_argument("--lam-main", type=float, default=0.03)
    args = ap.parse_args(argv)
    out = dict(parameters=table_parameters(), methods=table_methods(), main=table_main(args.lam_main),
               ablations=table_ablations(args.lam_main), dual=table_dual(), agentic=table_agentic(), temporal=table_temporal(),
               phase_bits=table_phase_bits(args.lam_main), attack_scaling=table_attack_scaling(args.lam_main))
    print(json.dumps({k: ("written" if v is not None else "skipped: results missing") for k, v in out.items()}, indent=1))
    return out


if __name__ == "__main__":
    main()
