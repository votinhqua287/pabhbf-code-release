"""Plot conventions shared by every paper figure.

- Each scheme is drawn as a plain markered line with straight segments between simulated points: no error bars, no
  confidence bands, no smoothing. Uncertainty goes to the tables.
- The x-limits are the smallest and largest swept values, and the x-ticks are exactly the swept values.
- Vector PDF for the manuscript (copied to manuscript/figures) and PNG for inspection, serif fonts at IEEE column width.
- Figures are built from saved result files only.
"""
from __future__ import annotations

import shutil

import matplotlib

matplotlib.use("Agg")
import matplotlib.pyplot as plt  # noqa: E402

from ..utils.config import ROOT  # noqa: E402

COLUMN_WIDTH_IN = 3.5
MARKERS = ["o", "s", "^", "v", "D", "P", "X", "<", ">", "h", "*", "p"]
COLORS = plt.get_cmap("tab10").colors
FIG_DIR = ROOT / "results" / "figures"
MANUSCRIPT_FIG_DIR = ROOT / "manuscript" / "figures"


def setup():
    plt.rcParams.update({
        "font.family": "serif", "font.serif": ["Times New Roman", "Times", "DejaVu Serif"], "mathtext.fontset": "stix",
        "font.size": 8, "axes.labelsize": 8, "legend.fontsize": 6.5, "xtick.labelsize": 7, "ytick.labelsize": 7,
        "lines.linewidth": 1.0, "lines.markersize": 3.5, "axes.grid": True, "grid.linewidth": 0.3, "grid.alpha": 0.6,
        "legend.framealpha": 0.9, "legend.borderpad": 0.3, "legend.handlelength": 2.0,
        "pdf.fonttype": 42, "ps.fonttype": 42, "savefig.bbox": "tight", "savefig.pad_inches": 0.02,
    })


def figure(height_ratio: float = 0.72, width: float = COLUMN_WIDTH_IN, **kw):
    setup()
    return plt.subplots(figsize=(width, width * height_ratio), **kw)


def line(ax, x, y, i: int, label: str, **kw):
    return ax.plot(x, y, marker=MARKERS[i % len(MARKERS)], color=COLORS[i % len(COLORS)], label=label, **kw)


def swept_axis(ax, values, labels=None):
    values = list(values)
    ax.set_xlim(min(values), max(values))
    ax.set_xticks(values)
    if labels is not None:
        ax.set_xticklabels(labels)


def save(fig, name: str):
    FIG_DIR.mkdir(parents=True, exist_ok=True)
    MANUSCRIPT_FIG_DIR.mkdir(parents=True, exist_ok=True)
    fig.savefig(FIG_DIR / f"{name}.pdf")
    fig.savefig(FIG_DIR / f"{name}.png", dpi=300)
    shutil.copy(FIG_DIR / f"{name}.pdf", MANUSCRIPT_FIG_DIR / f"{name}.pdf")
    plt.close(fig)
