"""RESULTS_LEDGER.md from the figure manifest and the aggregated results (Task 17).

  python -m pabhbf.plots.ledger

Each entry lists the claim, script, configuration, input result files, creation date and git commit of a figure or
table. The "Claim" and "Key observation" lines are written by the authors after inspecting the output. The generator
keeps any text already present in these lines and marks new entries as awaiting inspection.
"""
from __future__ import annotations

import json
import re
import time

from ..train.common import run_metadata
from ..utils.config import ROOT

LEDGER = ROOT / "RESULTS_LEDGER.md"
AGG = ROOT / "results" / "aggregated"
FIG = ROOT / "results" / "figures"
TAB = ROOT / "manuscript" / "tables"

ENTRIES = [
    ("Supplementary: privacy weight", "fig02_privacy_weight", "plots/paper_figures.py::fig02_privacy_weight", ["e1", "baselines"]),
    ("Fig. 3", "fig03_pareto", "plots/paper_figures.py::fig03_pareto", ["e1", "e2", "baselines"]),
    ("Supplementary: latent dimension", "fig04_latent_dim", "plots/paper_figures.py::fig04_latent_dim", ["e2", "e1", "baselines"]),
    ("Supplementary: NMSE versus rate", "fig05_nmse_rate", "plots/paper_figures.py::fig05_nmse_rate", ["e1", "baselines"]),
    ("Fig. 2", "fig06_nf_ff", "plots/fig06_nf_ff.py", ["premise", "e1"]),
    ("Fig. 4", "fig07_array_size", "plots/paper_figures.py::fig07_array_size", ["nt_sweep", "e1", "baselines", "premise"]),
    ("Supplementary: SNR", "fig08_snr", "plots/paper_figures.py::fig08_snr", ["teacher_sweep_default", "e1", "baselines"]),
    ("Supplementary: mismatch", "fig09_mismatch", "plots/paper_figures.py::fig09_mismatch", ["mismatch", "e1", "baselines"]),
    ("Supplementary: overhead and planners", "fig10_overhead", "plots/paper_figures.py::fig10_overhead", ["e13_agentic", "e2", "e1", "baselines"]),
    ("Table III", "tab_parameters", "plots/make_tables.py::table_parameters", []),
    ("Supplementary: compared schemes", "tab_methods", "plots/make_tables.py::table_methods", []),
    ("Table IV", "tab_main", "plots/make_tables.py::table_main", ["e1", "baselines"]),
    ("Supplementary: ablations", "tab_ablations", "plots/make_tables.py::table_ablations", ["ablations", "e1"]),
    ("Supplementary: budget update", "tab_dual", "plots/make_tables.py::table_dual", ["e1d"]),
    ("Supplementary: planners", "tab_agentic", "plots/make_tables.py::table_agentic", ["e13_agentic", "e13_agentic_costs"]),
    ("Supplementary: temporal attacker", "tab_temporal", "plots/make_tables.py::table_temporal", ["e_temporal"]),
    ("Supplementary: phase bits", "tab_phase_bits", "plots/make_tables.py::table_phase_bits",
     ["phase_bits", "e1", "teacher_sweep_default_bits2_stored", "teacher_sweep_default_bits3_stored", "teacher_sweep_default_bitsideal_stored"]),
    ("Table V", "tab_attack_scaling", "plots/make_tables.py::table_attack_scaling", ["attack_scaling", "e1", "e2", "baselines"]),
    # numbers quoted in the text without a figure or table of their own
    ("Text: training behaviour", "results/aggregated/training_summary_e1.json", "eval/summarize_training.py", ["training_summary_e1"]),
    ("Text: mutual-information bound", "results/aggregated/e1.json", "attacks/suite.py (cell classifier), eval/aggregate.py",
     ["e1", "baselines"]),
    ("Text: checks behind Propositions 1 and 2", "results/aggregated/revision_checks.json", "attacks/revision_checks.py",
     ["revision_checks"]),
]


def _inputs(sources):
    out = []
    for s in sources:
        agg = AGG / f"{s}.json"
        if s in ("premise", "e13_agentic", "e13_agentic_costs", "e_temporal", "attack_scaling"):
            files = sorted((ROOT / "results" / "raw" / s).glob("*.json"))
            out.append(f"results/raw/{s}/ ({len(files)} files)")
        elif s.startswith("training_summary") and agg.exists():
            out.append(f"results/aggregated/{s}.json ({len(json.loads(agg.read_text()))} training logs)")
        elif agg.exists():
            data = json.loads(agg.read_text())
            per_tag = isinstance(data, dict) and all(isinstance(v, dict) for v in data.values()) and not s.startswith("teacher_sweep")
            n = sum(len(v.get("files", [])) for v in data.values()) if per_tag else 1
            out.append(f"results/aggregated/{s}.json ({n} raw result files)")
    return out


def _existing(text: str) -> dict:
    kept = {}
    for block in re.split(r"\n(?=### )", text):
        m = re.match(r"### (.+)", block)
        if m:
            fields = dict(re.findall(r"^- (Claim|Key observation): (.*)$", block, flags=re.M))
            kept[m.group(1).strip()] = fields
    return kept


def main():
    kept = _existing(LEDGER.read_text(encoding="utf-8")) if LEDGER.exists() else {}
    meta = run_metadata()
    lines = ["# Results ledger (Paper A)", "",
             "Every number in the manuscript traces to an entry below. Entries marked Supplementary belong to studies that the 13-page manuscript summarizes in text or omits. The factual fields are generated by `python -m pabhbf.plots.ledger`.",
             "The claim and observation lines are written after inspecting the output and are preserved on regeneration.", "",
             f"Generated {time.strftime('%Y-%m-%d %H:%M:%S')}, git commit: {meta['git_commit']}.", ""]
    for ident, stem, script, sources in ENTRIES:
        path = FIG / f"{stem}.pdf" if stem.startswith("fig") else TAB / f"{stem}.tex" if stem.startswith("tab") else ROOT / stem
        status = time.strftime("%Y-%m-%d %H:%M", time.localtime(path.stat().st_mtime)) if path.exists() else "not generated"
        prev = kept.get(ident, {})
        lines += [f"### {ident}", f"- File: `{path.relative_to(ROOT).as_posix()}` ({status})",
                  f"- Script: `python/pabhbf/{script}`", "- Config: `configs/default.yaml` plus the overrides stored in each checkpoint",
                  f"- Inputs: {', '.join(_inputs(sources)) or 'configuration only'}",
                  f"- Claim: {prev.get('Claim', 'awaiting inspection')}",
                  f"- Key observation: {prev.get('Key observation', 'awaiting inspection')}", ""]
    LEDGER.write_text("\n".join(lines), encoding="utf-8")
    print(f"wrote {LEDGER}")


if __name__ == "__main__":
    main()
