"""Regenerate every paper figure and table from saved results (Task 17).

  python -m pabhbf.plots.make_all [--lam-main 0.03]
Writes results/figures/*.pdf|png (copied to manuscript/figures), manuscript/tables/*.tex and results/figures/manifest.json.
"""
from __future__ import annotations

import argparse
import json
import time

from ..train.common import run_metadata
from . import fig06_nf_ff, make_tables, paper_figures, style


def main(argv=None):
    ap = argparse.ArgumentParser()
    ap.add_argument("--lam-main", type=float, default=0.03)
    args = ap.parse_args(argv)
    manifest = dict(created=time.strftime("%Y-%m-%d %H:%M:%S"), lam_main=args.lam_main, meta=run_metadata(), figures={})
    for fn in paper_figures.FIGURES:
        info = fn(args.lam_main)
        manifest["figures"][fn.__name__] = info if info is not None else "skipped: results missing"
    fig06_nf_ff.main(["--lam-main", paper_figures.fmt(args.lam_main)])
    manifest["figures"]["fig06_nf_ff"] = "written"
    manifest["tables"] = {k: ("written" if v is not None else "skipped: results missing")
                          for k, v in make_tables.main(["--lam-main", str(args.lam_main)]).items()}
    style.FIG_DIR.mkdir(parents=True, exist_ok=True)
    (style.FIG_DIR / "manifest.json").write_text(json.dumps(manifest, indent=1, default=str))
    print(json.dumps(manifest["figures"], indent=1, default=str))


if __name__ == "__main__":
    main()
