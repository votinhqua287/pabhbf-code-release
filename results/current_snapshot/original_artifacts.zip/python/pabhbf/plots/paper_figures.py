"""Paper figures built from saved results only (Task 17).

Every function reads results/aggregated/*.json (means over training seeds, `python -m pabhbf.eval.aggregate`) or
raw result files, draws plain markered lines with x-ticks at the swept values, and writes PDF and PNG files through
plots.style. The leakage plotted for sweeps is `privacy.leakage_common`, the largest hit probability over the attackers
that were run for every seed.
"""
from __future__ import annotations

import glob
import json
import pathlib

import numpy as np

from ..utils.config import ROOT, load_config, system_params
from . import style

AGG = ROOT / "results" / "aggregated"
RAW = ROOT / "results" / "raw"
LEAK = "privacy.leakage_common"
RMSE = "privacy.rmse_common_m"

SCHEMES = {
    "teacher": ("Teacher with raw CSI (B0)", 0),
    "pab": ("PAB-HBF", 1),
    "pab0": (r"PAB-HBF, $\mu=0$", 2),
    "raw_csi": ("B1 raw CSI", 3),
    "pca": ("B2 PCA", 4),
    "random_projection": ("B3 random projection", 5),
    "scalar_quant": ("B4 scalar quantization", 6),
    "gaussian_pca": ("B5 PCA with Gaussian noise", 7),
    "top_m_beams": ("B6 strongest codewords", 8),
    "autoencoder": ("B7 autoencoder", 9),
    "angle_domain": ("B8 angle domain", 10),
    "laplace_pca": ("B9 PCA with Laplace noise", 11),
    "strongest": ("Strongest users", 12),
}
PALETTE = ["#000000", "#d62728", "#ff7f0e", "#1f77b4", "#2ca02c", "#9467bd", "#8c564b", "#e377c2", "#7f7f7f",
           "#bcbd22", "#17becf", "#aec7e8", "#98df8a"]


def fmt(x) -> str:
    return f"{float(x):g}"


def load_agg(exp: str) -> dict:
    path = AGG / f"{exp}.json"
    return json.loads(path.read_text()) if path.exists() else {}


def m(agg: dict, tag: str, key: str, stat: str = "mean", default=np.nan):
    try:
        return agg[tag]["metrics"][key][stat]
    except KeyError:
        return default


def draw(ax, x, y, scheme: str, label=None, **kw):
    name, i = SCHEMES[scheme]
    kw.setdefault("marker", style.MARKERS[i % len(style.MARKERS)])
    return ax.plot(x, y, color=PALETTE[i], label=label or name, **kw)


def panel_label(ax, text: str, y: float = -0.30):
    ax.text(0.5, y, text, transform=ax.transAxes, ha="center", va="top", fontsize=8)


def prior_hit() -> float:
    cfg = load_config()
    p = system_params(cfg)
    return float(np.pi * cfg["privacy"]["tolerance_radius_m"] ** 2 / p.area)


def fig02_privacy_weight(lam_main: float):
    e1, base = load_agg("e1"), load_agg("baselines")
    lams = [l for l in load_config()["privacy"]["lambda_list"] if f"lam{fmt(l)}" in e1]
    if not lams:
        return None
    pos = np.arange(len(lams))
    tags = [f"lam{fmt(l)}" for l in lams]
    fig, (a, b) = style.figure(height_ratio=1.25, nrows=2)
    draw(a, pos, [m(e1, t, "utility.wsr") for t in tags], "pab", label="PAB-HBF")
    teacher = m(e1, tags[0], "utility.teacher_wsr")
    a.plot(pos, np.full(len(pos), teacher), color=PALETTE[0], ls="--", label=SCHEMES["teacher"][0])
    if "raw_csi" in base:
        a.plot(pos, np.full(len(pos), m(base, "raw_csi", "utility.wsr")), color=PALETTE[3], ls=":", label=SCHEMES["raw_csi"][0])
    a.set_ylabel("Weighted sum rate (bit/s/Hz)")
    b.set_ylabel(r"Leakage $\Lambda_{\rho}$")
    draw(b, pos, [m(e1, t, LEAK) for t in tags], "pab", label="PAB-HBF")
    if "raw_csi" in base:
        b.plot(pos, np.full(len(pos), m(base, "raw_csi", LEAK)), color=PALETTE[3], ls=":", label=SCHEMES["raw_csi"][0])
    b.plot(pos, np.full(len(pos), prior_hit()), color="gray", ls="-.", label="Best fixed guess")
    for ax, lab in ((a, "(a)"), (b, "(b)")):
        style.swept_axis(ax, pos, [fmt(l) for l in lams])
        ax.set_xlabel(r"Privacy weight $\mu$")
        ax.legend(loc="best")
        panel_label(ax, lab)
    fig.subplots_adjust(hspace=0.55)
    style.save(fig, "fig02_privacy_weight")
    return dict(lams=lams)


def _baseline_points(base: dict):
    singles = ["raw_csi", "pca", "random_projection", "scalar_quant", "top_m_beams", "autoencoder", "angle_domain"]
    sweeps = {"gaussian_pca": sorted((float(t.split("_")[-1]), t) for t in base if t.startswith("gaussian_pca_")),
              "laplace_pca": sorted((float(t.split("_")[-1]), t) for t in base if t.startswith("laplace_pca_"))}
    return [s for s in singles if s in base], sweeps


def fig03_pareto(lam_main: float):
    e1, base, e2 = load_agg("e1"), load_agg("baselines"), load_agg("e2")
    if not e1:
        return None
    lams = [l for l in load_config()["privacy"]["lambda_list"] if f"lam{fmt(l)}" in e1]
    tags = [f"lam{fmt(l)}" for l in lams]
    main_tag = f"lam{fmt(lam_main)}"
    # latent dimensions whose E2 runs cover the same training seeds as E1 (d_z = 4 and 8 have three seeds)
    small = [d for d in (4, 8) if all(len(e2.get(f"dz{d}_{t}", {}).get("seeds", [])) == len(e1[t]["seeds"]) for t in (main_tag, "lam0"))]
    fig, axes = style.figure(height_ratio=1.3, nrows=2)
    singles, sweeps = _baseline_points(base)
    for ax, key, xlabel, lab in ((axes[0], LEAK, r"Leakage $\Lambda_{\rho}$", "(a)"), (axes[1], RMSE, "Localization RMSE (m)", "(b)")):
        draw(ax, [m(e1, t, key) for t in tags], [m(e1, t, "utility.wsr") for t in tags], "pab", label=r"PAB-HBF ($\mu$ sweep)")
        dims = ",".join(str(d) for d in small + [32])
        for scheme, t, mu in (("pab", main_tag, fmt(lam_main)), ("pab0", "lam0", "0")) if small else ():
            refs = [(e2, f"dz{d}_{t}") for d in small] + [(e1, t)]
            draw(ax, [m(g, r, key) for g, r in refs], [m(g, r, "utility.wsr") for g, r in refs], scheme, ls=":", marker="o",
                 markerfacecolor="none", label=rf"PAB-HBF, $\mu={mu}$, $d_z\in\{{{dims}\}}$")
        for s in singles:
            draw(ax, [m(base, s, key)], [m(base, s, "utility.wsr")], s, ls="none")
        for s, pts in sweeps.items():
            if pts:
                draw(ax, [m(base, t, key) for _, t in pts], [m(base, t, "utility.wsr")for _, t in pts], s, ls="--")
        ax.set_xlabel(xlabel)
        ax.set_ylabel("Weighted sum rate (bit/s/Hz)")
        panel_label(ax, lab, y=-0.28)
    axes[1].legend(loc="upper center", bbox_to_anchor=(0.5, -0.42), ncol=2, fontsize=5.5)  # below the panel label, where it hides no point
    fig.subplots_adjust(hspace=0.5)
    style.save(fig, "fig03_pareto")
    return dict(singles=singles, sweeps={k: [t for _, t in v] for k, v in sweeps.items()})


def seed1(agg: dict, tag: str, key: str, seed: int = 1, default=np.nan):
    """Value of one training seed, for figures whose other points exist for seed 1 only (E2, E5, E7, E8)."""
    try:
        g = agg[tag]
        return g["metrics"][key]["values"][g["seeds"].index(seed)]
    except (KeyError, ValueError, IndexError):
        return default


def e2_series(lam_main: float, e2: dict, e1: dict, base: dict, dims) -> dict:
    """(aggregate, tag) per latent dimension, with the d_z = 32 runs taken from E1 and the baselines."""
    return {"pab": [(e2, f"dz{d}_lam{fmt(lam_main)}") if d != 32 else (e1, f"lam{fmt(lam_main)}") for d in dims],
            "pab0": [(e2, f"dz{d}_lam0") if d != 32 else (e1, "lam0") for d in dims],
            "autoencoder": [(e2, f"autoencoder_dz{d}") if d != 32 else (base, "autoencoder") for d in dims],
            "pca": [(e2, f"pca_dz{d}") if d != 32 else (base, "pca") for d in dims]}


def fig04_latent_dim(lam_main: float):
    e2, e1, base = load_agg("e2"), load_agg("e1"), load_agg("baselines")
    if not e2:
        return None
    dims = [4, 8, 16, 32, 64]
    series = e2_series(lam_main, e2, e1, base, dims)
    fig, (a, b) = style.figure(height_ratio=1.25, nrows=2)
    x = np.log2(dims)
    for s, refs in series.items():  # E2 runs seed 1 only, so the d_z = 32 points use seed 1 as well
        draw(a, x, [seed1(agg, t, RMSE) for agg, t in refs], s)
        draw(b, x, [seed1(agg, t, LEAK) for agg, t in refs], s)
    a.set_ylabel("Localization RMSE (m)")
    b.set_ylabel(r"Leakage $\Lambda_{\rho}$")
    for ax, lab in ((a, "(a)"), (b, "(b)")):
        style.swept_axis(ax, x, [str(d) for d in dims])
        ax.set_xlabel(r"Latent dimension $d_z$")
        panel_label(ax, lab)
    a.legend(loc="best")
    fig.subplots_adjust(hspace=0.55)
    style.save(fig, "fig04_latent_dim")
    return dict(dims=dims)


def fig05_nmse_rate(lam_main: float):
    e1, base = load_agg("e1"), load_agg("baselines")
    if not e1:
        return None
    fig, ax = style.figure(height_ratio=0.8)
    lams = [l for l in load_config()["privacy"]["lambda_list"] if f"lam{fmt(l)}" in e1]
    tags = [f"lam{fmt(l)}" for l in lams]
    def nmse(agg, t):  # linear scale, so that the representations with an NMSE near 0 dB stay apart
        return 10.0 ** (m(agg, t, "privacy.decoder.nmse_db") / 10.0)

    draw(ax, [nmse(e1, t) for t in tags], [m(e1, t, "utility.wsr") for t in tags], "pab", label=r"PAB-HBF ($\mu$ sweep)")
    singles, sweeps = _baseline_points(base)
    for s in singles:
        draw(ax, [nmse(base, s)], [m(base, s, "utility.wsr")], s, ls="none")
    for s, pts in sweeps.items():
        if pts:
            draw(ax, [nmse(base, t) for _, t in pts], [m(base, t, "utility.wsr") for _, t in pts], s, ls="--")
    ax.set_xlabel("CSI reconstruction NMSE of the attacker")
    ax.set_ylabel("Weighted sum rate (bit/s/Hz)")
    ax.legend(loc="best", fontsize=5.5)
    style.save(fig, "fig05_nmse_rate")
    return dict(tags=tags)


def fig07_array_size(lam_main: float):
    nts = [32, 64, 128, 256]
    nt_agg, e1, base = load_agg("nt_sweep"), load_agg("e1"), load_agg("baselines")
    prem = {}
    for nt, pat in ((32, "premise_mle_nt32p_*.json"), (64, "premise_mle_nt64_*.json"), (128, "premise_mle_nt128p_*.json"), (256, "premise_mle_nt256p_*.json")):
        files = sorted(glob.glob(str(RAW / "premise" / pat)))
        if files:
            d = json.loads(pathlib.Path(files[-1]).read_text())
            prem[nt] = {model: next(r["hit_prob"] for r in d["runs"] if r["model"] == model and r["attacker"] == "mle_fusion")
                        for model in ("near_field", "far_field")}  # one attacker for every array size, as in Fig. 6
    if len(prem) < len(nts) or not nt_agg or not e1:
        return None

    def ref(kind, nt):
        if nt == 256:
            return (e1, f"lam{fmt(lam_main)}") if kind == "pab" else (e1, "lam0") if kind == "pab0" else (base, "raw_csi")
        return (nt_agg, f"nt{nt}_lam{fmt(lam_main)}") if kind == "pab" else (nt_agg, f"nt{nt}_lam0") if kind == "pab0" else (nt_agg, f"nt{nt}_raw_csi")

    x = np.log2(nts)
    fig, (a, b) = style.figure(height_ratio=1.25, nrows=2)
    a.plot(x, [prem[n]["near_field"] for n in nts], color=PALETTE[0], marker="o", ls="-", label="Near field, raw CSI, model-based attacker")
    a.plot(x, [prem[n]["far_field"] for n in nts], color=PALETTE[0], marker="s", ls="--", label="Plane wave, raw CSI, model-based attacker")
    # the array-size runs use seed 1 only, so the Nt = 256 points use seed 1 as well
    for kind in ("pab", "pab0", "raw_csi"):
        draw(a, x, [seed1(*ref(kind, n), LEAK) for n in nts], kind)
        draw(b, x, [seed1(*ref(kind, n), "utility.wsr") for n in nts], kind)
    draw(b, x, [seed1(*ref("pab0", n), "utility.teacher_wsr") for n in nts], "teacher", ls="--")
    a.set_ylabel(r"Leakage $\Lambda_{\rho}$")
    b.set_ylabel("Weighted sum rate (bit/s/Hz)")
    for ax, lab in ((a, "(a)"), (b, "(b)")):
        style.swept_axis(ax, x, [str(n) for n in nts])
        ax.set_xlabel(r"Number of antennas $N_{\mathrm{t}}$")
        ax.legend(loc="best", fontsize=5.5)
        panel_label(ax, lab)
    fig.subplots_adjust(hspace=0.55)
    style.save(fig, "fig07_array_size")
    return dict(nts=nts)


def _per_snr(exp: str, agg: dict, tag: str, snrs, n_drops: int):
    """Mean weighted sum rate per SNR over the first n_drops test drops, averaged over the seeds of a tag."""
    vals = []
    for name in agg.get(tag, {}).get("files", []):
        npz = RAW / exp / (pathlib.Path(name).stem + ".npz")
        if npz.exists():
            d = np.load(npz)
            vals.append([float(d[f"wsr_{fmt(s)}"][:n_drops].mean()) for s in snrs])
    return np.mean(vals, axis=0) if vals else None


def fig08_snr(lam_main: float):
    sweep_file = AGG / "teacher_sweep_default.json"
    if not sweep_file.exists():
        return None
    ts = json.loads(sweep_file.read_text())
    snrs, n = ts["snr_db"], ts["n_drops"]
    e1, base = load_agg("e1"), load_agg("baselines")
    fig, ax = style.figure(height_ratio=0.8)
    draw(ax, snrs, ts["teacher_wsr"], "teacher")
    draw(ax, snrs, ts["strongest_wsr"], "strongest", ls="--")
    for exp, agg, tag, s in (("e1", e1, f"lam{fmt(lam_main)}", "pab"), ("e1", e1, "lam0", "pab0"),
                             ("baselines", base, "raw_csi", "raw_csi"), ("baselines", base, "pca", "pca"),
                             ("baselines", base, "autoencoder", "autoencoder")):
        y = _per_snr(exp, agg, tag, snrs, n)
        if y is not None:
            draw(ax, snrs, y, s)
    style.swept_axis(ax, snrs)
    ax.set_xlabel("Reference SNR (dB)")
    ax.set_ylabel("Weighted sum rate (bit/s/Hz)")
    ax.legend(loc="upper left", fontsize=5.5)
    style.save(fig, "fig08_snr")
    return dict(snrs=snrs, n_drops=n)


def fig09_mismatch(lam_main: float):
    mm, e1, base = load_agg("mismatch"), load_agg("e1"), load_agg("baselines")
    if not mm:
        return None
    scen = [("nominal", None), ("range", "mm_range"), ("channel", "mm_channel")]
    pos = np.arange(len(scen))
    fig, (a, b) = style.figure(height_ratio=1.25, nrows=2)
    schemes = (("pab", f"lam{fmt(lam_main)}", e1), ("pab0", "lam0", e1), ("raw_csi", "raw_csi", base),
               ("pca", "pca", base), ("autoencoder", "autoencoder", base))
    for i, (s, tag, agg0) in enumerate(schemes):
        refs = [(agg0, tag) if suffix is None else (mm, f"{tag}_{suffix}") for _, suffix in scen]
        # the scenarios are categories, so every scheme gets separate markers without connecting lines, shifted
        # sideways to avoid overlaps; the mismatch evaluations use the seed-1 checkpoints, and so do the nominal points
        dx = (i - (len(schemes) - 1) / 2) * 0.1
        draw(a, pos + dx, [seed1(agg, t, "utility.ratio") for agg, t in refs], s, ls="none")
        draw(b, pos + dx, [seed1(agg, t, LEAK) for agg, t in refs], s, ls="none")
    a.set_ylabel("Rate ratio to the teacher")
    b.set_ylabel(r"Leakage $\Lambda_{\rho}$")
    labels = ["Nominal", "Range\nmismatch", "Channel\nmismatch"]
    for ax, lab in ((a, "(a)"), (b, "(b)")):
        ax.set_xlim(-0.5, len(scen) - 0.5)
        ax.set_xticks(pos)
        ax.set_xticklabels(labels)
        panel_label(ax, lab, y=-0.38)
    a.legend(loc="best", fontsize=5.5)
    fig.subplots_adjust(hspace=0.65)
    style.save(fig, "fig09_mismatch")
    return dict(scenarios=[s for s, _ in scen])


def fig10_overhead(lam_main: float):
    e2, e1, base = load_agg("e2"), load_agg("e1"), load_agg("baselines")
    files = sorted(glob.glob(str(RAW / "e13_agentic" / "*.json")))
    if not e2 or not files:
        return None
    fig, (a, b) = style.figure(height_ratio=1.25, nrows=2)
    # (a) utility against the signaling payload, seed 1 as in Fig. 4 (Fig. 4 shows the privacy side of the same runs)
    dims = [4, 8, 16, 32, 64]
    x = np.log2([4 * d for d in dims])
    for s, refs in e2_series(lam_main, e2, e1, base, dims).items():
        draw(a, x, [seed1(agg, t, "utility.ratio") for agg, t in refs], s)
    style.swept_axis(a, x, [str(4 * d) for d in dims])
    a.set_xlabel("Payload per user (bits)")
    a.set_ylabel("Rate ratio to the teacher")
    a.legend(loc="lower right", fontsize=5.5)
    # (b) planners: latency against rate ratio, with the feedback bits in the legend
    ag = json.loads(pathlib.Path(files[-1]).read_text())
    names = {"direct": "Direct", "rule": "Rule-based", "search2": "Search, $C=2$", "search4": "Search, $C=4$"}
    fit = ag["learned_fit"]
    points = [(names.get(k, f"Learned ({fmt(fit['mu_latency'])}, {fmt(fit['nu_bits'])})"), v) for k, v in ag["planners"].items()]
    for f in sorted(glob.glob(str(RAW / "e13_agentic_costs" / "*.json"))):
        d = json.loads(pathlib.Path(f).read_text())
        fc = d["learned_fit"]
        points.append((f"Learned ({fmt(fc['mu_latency'])}, {fmt(fc['nu_bits'])})", d["planners"]["learned"]))
    for i, (label, v) in enumerate(points):
        b.plot(v["latency_ms_per_drop"], v["ratio"], ls="none", marker=style.MARKERS[i % len(style.MARKERS)],
               color=PALETTE[(i + 1) % len(PALETTE)], label=f"{label}, {v['exposure_bits_per_drop']:.1f} bits")
    b.set_xlabel("Latency per interval (ms)")
    b.set_ylabel("Rate ratio to the teacher")
    b.legend(loc="upper center", bbox_to_anchor=(0.5, -0.33), ncol=2, fontsize=5.5)  # below the axis label, where it hides no point
    panel_label(a, "(a)")
    panel_label(b, "(b)", y=-0.74)
    fig.subplots_adjust(hspace=0.55)
    style.save(fig, "fig10_overhead")
    return dict(planners=[p for p, _ in points])


FIGURES = (fig02_privacy_weight, fig03_pareto, fig04_latent_dim, fig05_nmse_rate, fig07_array_size, fig08_snr,
           fig09_mismatch, fig10_overhead)
