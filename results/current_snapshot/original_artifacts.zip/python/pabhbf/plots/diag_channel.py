"""Task 3 diagnostics: phase profiles across the array and near-field beam-focusing gain versus range."""
from __future__ import annotations

import pathlib

import matplotlib

matplotlib.use("Agg")
import matplotlib.pyplot as plt
import numpy as np

from pabhbf.data import channel as ch
from pabhbf.utils.config import ROOT, load_config, system_params

OUT = ROOT / "results" / "diagnostics"


def main():
    OUT.mkdir(parents=True, exist_ok=True)
    p = system_params(load_config())
    th = np.deg2rad(20.0)
    n = np.arange(1, p.Nt + 1)
    lin = 2 * np.pi / p.lam * ch.antenna_offsets(p.Nt) * p.d * np.sin(th)
    fig, ax = plt.subplots(1, 2, figsize=(8.0, 3.0))
    for r in (3.0, 10.0, 20.0):
        ph = np.unwrap(np.angle(ch.nf_response(r, th, p.Nt, p.lam))) - lin
        ax[0].plot(n, ph - ph[p.Nt // 2], marker="o", markersize=2, label=f"near field, r = {r:g} m")
    ax[0].plot(n, np.zeros_like(n, dtype=float), marker="s", markersize=2, label="far field")
    ax[0].set_xlabel("Antenna index n")
    ax[0].set_ylabel("Phase minus linear term (rad)")
    ax[0].set_xlim(1, p.Nt)
    ax[0].legend(fontsize=7)
    ranges = np.linspace(1.0, 60.0, 600)
    for nt in (64, 256):
        for r0 in (3.0, 10.0):
            b0 = ch.nf_response(r0, 0.0, nt, p.lam)
            bs = ch.nf_response(ranges, np.zeros_like(ranges), nt, p.lam)
            gain = np.abs(bs @ b0.conj()) ** 2 / (np.linalg.norm(bs, axis=1) ** 2 * np.linalg.norm(b0) ** 2)
            ax[1].plot(ranges, gain, label=f"Nt = {nt}, focus at {r0:g} m")
    ax[1].set_xlabel("Range r (m)")
    ax[1].set_ylabel("Normalized beamforming gain")
    ax[1].set_xlim(ranges[0], ranges[-1])
    ax[1].legend(fontsize=7)
    fig.tight_layout()
    for ext in ("pdf", "png"):
        fig.savefig(OUT / f"diag_channel.{ext}", dpi=200)
    print("saved", OUT / "diag_channel.pdf")


if __name__ == "__main__":
    main()
