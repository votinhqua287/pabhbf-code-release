"""Fig. 6: tolerance-region hit probability against user distance.

Curves: raw near-field and far-field CSI under the MLE fusion attacker for Nt = 256 and Nt = 64 (premise study), and,
when the evaluations exist, the PAB-HBF representation at the main privacy weight and without privacy (strongest
evaluation attacker, seed 1).

  python -m pabhbf.plots.fig06_nf_ff [--lam-main 1]
"""
from __future__ import annotations

import argparse
import glob
import json

import numpy as np

from ..utils.config import ROOT
from . import style


def latest(pattern: str):
    files = sorted(glob.glob(str(ROOT / pattern)))
    return (json.loads(open(files[-1], encoding="utf-8").read()), files[-1]) if files else (None, None)


def main(argv=None):
    ap = argparse.ArgumentParser()
    ap.add_argument("--lam-main", default="1")
    args = ap.parse_args(argv)
    curves, sources = [], []
    for nt, pat in ((256, "results/raw/premise/premise_mle_nt256p_*.json"), (64, "results/raw/premise/premise_mle_nt64_*.json")):
        d, f = latest(pat)
        if d is None:
            continue
        sources.append(f)
        for model, label, ls in (("near_field", "Near field", "-"), ("far_field", "Plane wave", "--")):
            run = next(r for r in d["runs"] if r["model"] == model and r["attacker"] == "mle_fusion")
            curves.append((rf"{label}, raw CSI, $N_{{\mathrm{{t}}}}={nt}$", run["bins"], ls))
    for tag, label in ((f"lam{args.lam_main}", rf"PAB-HBF, $\mu={args.lam_main}$"), ("lam0", r"PAB-HBF, $\mu=0$")):
        d, f = latest(f"results/raw/e1/{tag}_s1_*.json")
        if d is not None and d.get("privacy"):
            sources.append(f)
            curves.append((label + r", $N_{\mathrm{t}}=256$", d["privacy"]["summary"]["bins_best"], ":"))
    edges = np.asarray(curves[0][1]["edges"])
    centers = 0.5 * (edges[1:] + edges[:-1])
    fig, ax = style.figure(height_ratio=0.78)
    for i, (label, bins, ls) in enumerate(curves):
        style.line(ax, centers, bins["hit_prob"], i, label, ls=ls)
    style.swept_axis(ax, centers, [f"{c:.1f}" for c in centers])
    ax.set_ylim(0.0, 1.0)
    ax.set_xlabel("User distance (m), bin centers")
    ax.set_ylabel(r"Hit probability within $\rho=1$ m")
    ax.legend(loc="upper center", bbox_to_anchor=(0.5, -0.2), ncol=2, fontsize=6)
    style.save(fig, "fig06_nf_ff")
    (style.FIG_DIR / "fig06_nf_ff.sources.json").write_text(json.dumps(sources, indent=1))
    print("sources:", sources)


if __name__ == "__main__":
    main()
