"""Polar-domain and DFT codebooks, and angular beam groups (Task 4)."""
from __future__ import annotations

from dataclasses import dataclass

import numpy as np
from scipy.optimize import brentq
from scipy.special import fresnel

from ..data.channel import ff_response, nf_response
from ..utils.config import SystemParams


def fresnel_correlation(beta):
    """|G(beta)| = |C(beta) + j S(beta)| / beta, the Fresnel-approximation correlation of two same-angle responses."""
    beta = np.asarray(beta, float)
    s, c = fresnel(beta)
    with np.errstate(invalid="ignore", divide="ignore"):
        out = np.hypot(c, s) / beta
    return np.where(beta > 0, out, 1.0)


def beta_delta(level: float) -> float:
    if not 0.0 < level < 1.0:
        raise ValueError("correlation level must lie in (0, 1)")
    grid = np.linspace(1e-4, 10.0, 100001)
    below = np.flatnonzero(fresnel_correlation(grid) <= level)
    hi = grid[below[0]]
    return brentq(lambda b: float(fresnel_correlation(b)) - level, 1e-4, hi)


def tau_delta(nt: int, lam: float, level: float) -> float:
    d = lam / 2
    return 2.0 * beta_delta(level) ** 2 * lam / (nt**2 * d**2)


def quantize_phase(w: np.ndarray, bits: int | None) -> np.ndarray:
    """Project entries onto the constant-modulus set with 2^bits phases (bits=None: continuous phases)."""
    nt = w.shape[-1]
    ph = np.angle(w)
    if bits is not None:
        step = 2.0 * np.pi / 2**bits
        ph = step * np.round(ph / step)
    return np.exp(1j * ph) / np.sqrt(nt)


@dataclass
class Codebook:
    W: np.ndarray        # (M, Nt) constant-modulus codewords
    u: np.ndarray        # (M,) sampled sin(theta)
    tau: np.ndarray      # (M,) sampled cos^2(theta)/r (0 for the far-field ring)
    group: np.ndarray    # (M,) beam-group index in {0, ..., G-1}
    G: int
    u_edges: np.ndarray  # (G+1,) group boundaries in u

    @property
    def M(self) -> int:
        return self.W.shape[0]


def group_of_u(u, u_edges) -> np.ndarray:
    G = len(u_edges) - 1
    return np.clip(np.digitize(u, u_edges) - 1, 0, G - 1)


def polar_codebook(p: SystemParams, level: float | None = None, bits: int | None = "cfg", G: int | None = None,
                   far_field_only: bool = False) -> Codebook:
    level = p.delta_cb if level is None else level
    bits = p.phase_bits if bits == "cfg" else bits
    G = p.G if G is None else G
    nt = p.Nt
    u_all = (2 * np.arange(nt) - nt + 1) / nt
    u_max = np.sin(p.theta_max) + 1.0 / nt
    u_sel = u_all[np.abs(u_all) <= u_max]
    td = tau_delta(nt, p.lam, level)
    Ws, us, taus = [], [], []
    for u in u_sel:
        th = np.arcsin(u)
        s = 0
        while True:
            if s == 0:
                w = ff_response(th, nt, p.lam)
                tau = 0.0
            else:
                tau = s * td
                r = (1 - u**2) / tau
                if r < p.r_min or far_field_only:
                    break
                w = nf_response(r, th, nt, p.lam)
            Ws.append(quantize_phase(w, bits))
            us.append(u)
            taus.append(tau)
            s += 1
    W = np.array(Ws)
    # remove exact duplicates created by coarse phase quantization (for example, mirror angles with 1-bit phases)
    _, keep = np.unique(np.round(W * np.sqrt(nt), 8).view(np.float64).reshape(len(W), -1), axis=0, return_index=True)
    keep = np.sort(keep)
    u_edges = np.linspace(-u_max, u_max, G + 1)
    u_arr, tau_arr = np.array(us)[keep], np.array(taus)[keep]
    return Codebook(W=W[keep], u=u_arr, tau=tau_arr, group=group_of_u(u_arr, u_edges), G=G, u_edges=u_edges)


def dft_codebook(p: SystemParams, bits: int | None = "cfg", G: int | None = None) -> Codebook:
    return polar_codebook(p, bits=bits, G=G, far_field_only=True)
