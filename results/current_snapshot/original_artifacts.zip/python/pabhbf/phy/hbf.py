"""Trusted beamforming tools and rate metrics (Task 4). All functions are batched over drops.

Shapes: n drops, K candidate users, S = Ns scheduled users, Nt antennas, M codewords.
Normalization: Pmax = 1 and sigma^2 = 1/SNR, where SNR is the reference SNR at the cell edge.
"""
from __future__ import annotations

import numpy as np

from .codebook import Codebook


def gather_users(X: np.ndarray, idx: np.ndarray) -> np.ndarray:
    """X (n, K, ...) and idx (n, S) -> (n, S, ...)."""
    return X[np.arange(X.shape[0])[:, None], idx]


def codeword_gains(Hc: np.ndarray, cb: Codebook) -> np.ndarray:
    """|c_m^H h|^2 for all users and codewords: (n, K, Nt) -> (n, K, M) (batched BLAS product)."""
    return np.abs(np.matmul(Hc, cb.W.conj().T)) ** 2


def best_groups(Hhat: np.ndarray, cb: Codebook) -> np.ndarray:
    """Beam group of the codeword with the largest estimated gain, for every user: (n, K)."""
    return cb.group[np.argmax(codeword_gains(Hhat, cb), axis=2)]


def beam_assignment(gains_S: np.ndarray, groups: np.ndarray, powers: np.ndarray, cb: Codebook) -> np.ndarray:
    """Assign one distinct codeword per scheduled user, processing users in decreasing power order.

    gains_S: (n, S, M) estimated codeword gains of the scheduled users; groups: (n, S); powers: (n, S).
    A user takes the unassigned codeword with the largest gain in its own group. If that group is exhausted, the
    nearest group with an unassigned codeword is used. Returns codeword indices (n, S) aligned with the users.
    """
    n, S, M = gains_S.shape
    order = np.argsort(-powers + 1e-12 * np.arange(S)[None, :], axis=1, kind="stable")
    assigned = np.zeros((n, M), bool)
    out = np.empty((n, S), int)
    rows = np.arange(n)
    gmax = gains_S.max(axis=2, keepdims=True) + 1e-300
    for j in range(S):
        user = order[:, j]
        dist = np.abs(cb.group[None, :] - groups[rows, user][:, None])
        score = np.where(assigned, -np.inf, -dist * 10.0 + gains_S[rows, user] / gmax[rows, user])
        pick = np.argmax(score, axis=1)
        out[rows, user] = pick
        assigned[rows, pick] = True
    return out


def effective_channel(Hc_S: np.ndarray, FRF: np.ndarray) -> np.ndarray:
    """Hbar = H_S^H F_RF with shape (n, S, S)."""
    return np.matmul(Hc_S.conj(), FRF)


def rzf_directions(Hbar: np.ndarray, reg) -> np.ndarray:
    """Fbar = Hbar^H (Hbar Hbar^H + reg I)^{-1}; reg is a scalar or an (n,) array (reg = 0 gives zero forcing)."""
    n, S, _ = Hbar.shape
    reg = np.broadcast_to(np.asarray(reg, float), (n,))
    A = Hbar @ Hbar.conj().transpose(0, 2, 1) + reg[:, None, None] * np.eye(S)[None]
    return Hbar.conj().transpose(0, 2, 1) @ np.linalg.inv(A)


def power_scaling(FRF: np.ndarray, Fbar: np.ndarray, shares: np.ndarray) -> np.ndarray:
    col = np.linalg.norm(FRF @ Fbar, axis=1)
    if np.any(col <= 0) or not np.all(np.isfinite(col)):
        raise FloatingPointError("degenerate precoder column")
    return Fbar * (np.sqrt(shares) / col)[:, None, :]


def sinr(H_S: np.ndarray, FRF: np.ndarray, FBB: np.ndarray, sigma2) -> np.ndarray:
    n = H_S.shape[0]
    sigma2 = np.broadcast_to(np.asarray(sigma2, float), (n,))
    if np.any(sigma2 <= 0):
        raise ValueError("noise variance must be positive")
    Gm = np.matmul(np.matmul(H_S.conj(), FRF), FBB)
    P = np.abs(Gm) ** 2
    sig = np.diagonal(P, axis1=1, axis2=2)
    out = sig / (P.sum(axis=2) - sig + sigma2[:, None])
    if not np.all(np.isfinite(out)):
        raise FloatingPointError("non-finite SINR")
    return out


def coupling_matrix(Hc_S: np.ndarray, FRF: np.ndarray, Fbar: np.ndarray) -> np.ndarray:
    """a[k, j] = |h_k^H F_RF fbar_j|^2 / ||F_RF fbar_j||^2, so that gamma_k = p_k a_kk / (sum_{j!=k} p_j a_kj + sigma^2)."""
    X = np.matmul(np.matmul(Hc_S.conj(), FRF), Fbar)
    col = np.linalg.norm(FRF @ Fbar, axis=1) ** 2
    return np.abs(X) ** 2 / col[:, None, :]


def sinr_from_shares(A: np.ndarray, shares: np.ndarray, sigma2) -> np.ndarray:
    n = A.shape[0]
    sigma2 = np.broadcast_to(np.asarray(sigma2, float), (n,))
    sig = np.diagonal(A, axis1=1, axis2=2) * shares
    tot = np.einsum("nkj,nj->nk", A, shares)
    return sig / (tot - sig + sigma2[:, None])


def build_precoders(Hhat: np.ndarray, sched: np.ndarray, groups: np.ndarray, shares: np.ndarray, cb: Codebook,
                    snr_lin, precoder: str = "rzf", gains: np.ndarray | None = None):
    """Beam assignment, digital directions and power scaling from the estimates."""
    n, S = sched.shape
    if np.any(shares < -1e-12) or not np.allclose(shares.sum(axis=1), 1.0, atol=1e-6):
        raise ValueError("power shares must lie on the simplex")
    snr = np.broadcast_to(np.asarray(snr_lin, float), (n,))
    Hhat_S = gather_users(Hhat, sched)
    gains_S = codeword_gains(Hhat_S, cb) if gains is None else gather_users(gains, sched)
    idx = beam_assignment(gains_S, groups, shares, cb)
    FRF = cb.W[idx].transpose(0, 2, 1)
    Hbar = effective_channel(Hhat_S, FRF)
    if precoder == "rzf":
        Fbar = rzf_directions(Hbar, S / snr)
    elif precoder == "zf":
        Fbar = rzf_directions(Hbar, 0.0)
    else:
        raise ValueError(precoder)
    return idx, FRF, Fbar


def apply_tools(H: np.ndarray, Hhat: np.ndarray, sched: np.ndarray, groups: np.ndarray, shares: np.ndarray,
                cb: Codebook, snr_lin, precoder: str = "rzf", return_all: bool = False, gains: np.ndarray | None = None):
    """Execute an action with the trusted tools (estimates) and evaluate the rates with the channels H."""
    n = sched.shape[0]
    snr = np.broadcast_to(np.asarray(snr_lin, float), (n,))
    idx, FRF, Fbar = build_precoders(Hhat, sched, groups, shares, cb, snr, precoder, gains)
    FBB = power_scaling(FRF, Fbar, shares)
    g = sinr(gather_users(H, sched), FRF, FBB, 1.0 / snr)
    rates = np.log2(1.0 + g)
    if return_all:
        return rates, dict(idx=idx, FRF=FRF, FBB=FBB, Fbar=Fbar, sinr=g)
    return rates
