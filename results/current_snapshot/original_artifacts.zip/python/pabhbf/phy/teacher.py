"""Oracle teacher actions from the estimated CSI (Task 5).

1. Beam group of each user: group of its best codeword.
2. Scheduling: greedy weighted-sum-rate maximization with equal power, evaluated with the estimates.
3. Power shares: Adam on the softmax parametrization of the estimated weighted sum rate, with the beams and the
   RZF directions fixed. The better of the optimized and the equal shares is kept.
The realized rates are evaluated with the true channels through the trusted tools.
"""
from __future__ import annotations

from itertools import combinations

import numpy as np
import torch

from .codebook import Codebook
from .hbf import (apply_tools, best_groups, build_precoders, codeword_gains, coupling_matrix, gather_users,
                  sinr_from_shares)


def estimated_wsr_equal_power(Hhat, gains, w, snr, sets, groups_all, cb):
    """Estimated weighted sum rate of the user sets (n, S) with equal power shares."""
    n, S = sets.shape
    shares = np.full((n, S), 1.0 / S)
    groups = gather_users(groups_all, sets)
    idx, FRF, Fbar = build_precoders(Hhat, sets, groups, shares, cb, snr, gains=gains)
    A = coupling_matrix(gather_users(Hhat, sets), FRF, Fbar)
    g = sinr_from_shares(A, shares, 1.0 / snr)
    return np.sum(gather_users(w, sets) * np.log2(1.0 + g), axis=1)


def greedy_schedule(Hhat, w, snr, cb: Codebook, Ns: int, groups_all=None, gains=None, chunk: int = 500):
    n, K, _ = Hhat.shape
    gains = codeword_gains(Hhat, cb) if gains is None else gains
    groups_all = best_groups(Hhat, cb) if groups_all is None else groups_all
    snr = np.broadcast_to(np.asarray(snr, float), (n,))
    selected = np.zeros((n, 0), int)
    for t in range(Ns):
        best_val = np.full(n, -np.inf)
        best_k = np.zeros(n, int)
        for k in range(K):
            valid = ~np.any(selected == k, axis=1)
            if not valid.any():
                continue
            rows = np.flatnonzero(valid)
            vals = np.empty(len(rows))
            for c0 in range(0, len(rows), chunk):
                r = rows[c0:c0 + chunk]
                sets = np.concatenate([selected[r], np.full((len(r), 1), k)], axis=1)
                vals[c0:c0 + chunk] = estimated_wsr_equal_power(Hhat[r], gains[r], w[r], snr[r], sets, groups_all[r], cb)
            better = vals > best_val[rows]
            best_val[rows[better]] = vals[better]
            best_k[rows[better]] = k
        selected = np.concatenate([selected, best_k[:, None]], axis=1)
    return np.sort(selected, axis=1)


def exhaustive_schedule(Hhat, w, snr, cb: Codebook, Ns: int):
    """Exact search over all user sets with equal power (small K only)."""
    n, K, _ = Hhat.shape
    gains, groups_all = codeword_gains(Hhat, cb), best_groups(Hhat, cb)
    snr = np.broadcast_to(np.asarray(snr, float), (n,))
    combos = np.array(list(combinations(range(K), Ns)))
    vals = np.stack([estimated_wsr_equal_power(Hhat, gains, w, snr, np.tile(c, (n, 1)), groups_all, cb) for c in combos], axis=1)
    return combos[np.argmax(vals, axis=1)], vals.max(axis=1)


def optimize_shares(A: np.ndarray, w_S: np.ndarray, sigma2: np.ndarray, iters: int = 120, lr: float = 0.1) -> np.ndarray:
    At = torch.as_tensor(A, dtype=torch.float64)
    wt = torch.as_tensor(w_S, dtype=torch.float64)
    s2 = torch.as_tensor(np.broadcast_to(sigma2, (A.shape[0],)).copy(), dtype=torch.float64)
    theta = torch.zeros(w_S.shape, dtype=torch.float64, requires_grad=True)
    opt = torch.optim.Adam([theta], lr=lr)

    def wsr(p):
        diag = torch.diagonal(At, dim1=1, dim2=2)
        sig = diag * p
        tot = torch.einsum("nkj,nj->nk", At, p)
        return (wt * torch.log2(1 + sig / (tot - sig + s2[:, None]))).sum(1)

    for _ in range(iters):
        opt.zero_grad()
        loss = -wsr(torch.softmax(theta, dim=1)).sum()
        loss.backward()
        opt.step()
    with torch.no_grad():
        p_opt = torch.softmax(theta, dim=1)
        p_eq = torch.full_like(p_opt, 1.0 / p_opt.shape[1])
        keep = wsr(p_opt) >= wsr(p_eq)
        p = torch.where(keep[:, None], p_opt, p_eq)
    return p.numpy()


def teacher_actions(H, Hhat, w, snr, cb: Codebook, Ns: int, power_iters: int = 120):
    n = H.shape[0]
    snr = np.broadcast_to(np.asarray(snr, float), (n,))
    gains = codeword_gains(Hhat, cb)
    groups_all = cb.group[np.argmax(gains, axis=2)]
    sched = greedy_schedule(Hhat, w, snr, cb, Ns, groups_all, gains)
    groups_S = gather_users(groups_all, sched)
    equal = np.full((n, Ns), 1.0 / Ns)
    _, FRF, Fbar = build_precoders(Hhat, sched, groups_S, equal, cb, snr, gains=gains)
    A = coupling_matrix(gather_users(Hhat, sched), FRF, Fbar)
    w_S = gather_users(w, sched)
    shares = optimize_shares(A, w_S, 1.0 / snr, iters=power_iters)
    rates_true = apply_tools(H, Hhat, sched, groups_S, shares, cb, snr, gains=gains)
    rates_est = apply_tools(Hhat, Hhat, sched, groups_S, shares, cb, snr, gains=gains)
    return dict(sched=sched, groups_all=groups_all, groups_S=groups_S, shares=shares,
                rates_true=rates_true, wsr_true=np.sum(w_S * rates_true, axis=1),
                wsr_est=np.sum(w_S * rates_est, axis=1))


def random_actions(rng: np.random.Generator, n: int, K: int, Ns: int, G: int):
    sched = np.sort(np.argsort(rng.random((n, K)), axis=1)[:, :Ns], axis=1)
    groups = rng.integers(0, G, (n, Ns))
    return sched, groups, np.full((n, Ns), 1.0 / Ns)


def strongest_users_actions(Hhat, w, cb: Codebook, Ns: int):
    """Heuristic: schedule the Ns users with the largest weighted estimated channel norm, best groups, equal power."""
    n = Hhat.shape[0]
    score = w * np.sum(np.abs(Hhat) ** 2, axis=2)
    sched = np.sort(np.argsort(-score, axis=1)[:, :Ns], axis=1)
    groups = gather_users(best_groups(Hhat, cb), sched)
    return sched, groups, np.full((n, Ns), 1.0 / Ns)
