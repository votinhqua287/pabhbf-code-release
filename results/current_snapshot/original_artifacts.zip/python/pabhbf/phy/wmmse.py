"""WMMSE refinement of the digital precoder for a fixed analog precoder (trusted tool for Task 13).

For the effective channel g_k^H = h_hat_k^H F_RF and the transmit covariance constraint ||F_RF F_BB||_F^2 <= P, the
weighted-MMSE iteration of Shi et al. (IEEE TSP 2011) alternates
    u_k = g_k^H v_k / (sum_j |g_k^H v_j|^2 + sigma^2),   w_k = 1 / (1 - conj(u_k) g_k^H v_k),
    V = (Phi + mu A)^{-1} B,   Phi = sum_k a_k w_k |u_k|^2 g_k g_k^H,   B = [a_k w_k u_k g_k]_k,   A = F_RF^H F_RF,
with mu >= 0 the smallest value that meets the power constraint (bisection on a generalized eigen-decomposition).
All operations are batched over drops and use the estimated channels only.
"""
from __future__ import annotations

import numpy as np


def _power(C, lam, mu):
    return np.sum(C / (lam + mu[:, None]) ** 2, axis=1)


def wmmse_digital(Hhat_S: np.ndarray, FRF: np.ndarray, FBB0: np.ndarray, alpha: np.ndarray, sigma2, P: float = 1.0,
                  iters: int = 10, bisection: int = 60) -> np.ndarray:
    """Hhat_S (n, S, Nt), FRF (n, Nt, S), FBB0 (n, S, S) feasible initial precoder, alpha (n, S) priority weights."""
    n, S, _ = Hhat_S.shape
    sigma2 = np.broadcast_to(np.asarray(sigma2, float), (n,))
    G = np.einsum("nst,ntr->nsr", Hhat_S.conj(), FRF)          # rows g_k^H
    A = FRF.conj().transpose(0, 2, 1) @ FRF
    L = np.linalg.cholesky(A)                                    # A = L L^H
    Linv = np.linalg.inv(L)
    V = FBB0.copy()
    for _ in range(iters):
        GV = G @ V
        tot = np.sum(np.abs(GV) ** 2, axis=2) + sigma2[:, None]
        d = np.diagonal(GV, axis1=1, axis2=2)
        u = d / tot
        w = 1.0 / np.maximum(np.real(1.0 - np.conj(u) * d), 1e-12)
        c = alpha * w * np.abs(u) ** 2
        Phi = np.einsum("nk,nki,nkj->nij", c, G.conj(), G)      # sum_k c_k g_k g_k^H with g_k = conj(row k)
        B = G.conj().transpose(0, 2, 1) * (alpha * w * u)[:, None, :]
        # generalized problem through A = L L^H: V = L^{-H} (Phi_t + mu I)^{-1} L^{-1} B with Phi_t = L^{-1} Phi L^{-H}
        Phi_t = Linv @ Phi @ Linv.conj().transpose(0, 2, 1)
        lam, Q = np.linalg.eigh(Phi_t)
        lam = np.maximum(lam, 0.0)
        QB = Q.conj().transpose(0, 2, 1) @ (Linv @ B)
        C = np.sum(np.abs(QB) ** 2, axis=2)                       # power(mu) = sum_i C_i / (lam_i + mu)^2
        mu = np.zeros(n)
        with np.errstate(divide="ignore", invalid="ignore"):  # a zero eigenvalue already forces mu > 0 through the first term
            need = (lam.min(axis=1) <= 1e-12) | (_power(C, lam, mu) > P)
        if need.any():
            lo, hi = np.zeros(n), np.ones(n)
            for _ in range(200):
                grow = need & (_power(C, lam, hi) > P)
                if not grow.any():
                    break
                hi[grow] *= 2.0
            for _ in range(bisection):
                mid = 0.5 * (lo + hi)
                over = _power(C, lam, mid) > P
                lo = np.where(need & over, mid, lo)
                hi = np.where(need & ~over, mid, hi)
            mu = np.where(need, hi, 0.0)
        V = Linv.conj().transpose(0, 2, 1) @ (Q @ (QB / (lam + mu[:, None])[:, :, None]))
    scale = np.sqrt(P / np.maximum(np.linalg.norm(FRF @ V, axis=(1, 2)) ** 2, 1e-300))
    return V * np.minimum(scale, 1.0)[:, None, None]
