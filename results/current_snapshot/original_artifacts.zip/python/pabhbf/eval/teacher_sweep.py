"""B0 teacher and the strongest-user heuristic on the test drops at every reference SNR (Task 14, E6 and E9).

  python -m pabhbf.eval.teacher_sweep --prefix default
  python -m pabhbf.eval.teacher_sweep --prefix default --phase-bits 2 --stored-snr
Writes results/aggregated/teacher_sweep_{prefix}[_bits{b}][_stored].json (means) and .npz (per-drop weighted sum rates).
With --stored-snr, every drop keeps the reference SNR stored in the split, as in the evaluation of the trained controllers.
"""
from __future__ import annotations

import argparse
import json
import time

import numpy as np

from ..data.dataset import load_split
from ..phy import codebook as cbm
from ..phy import hbf, teacher
from ..utils.config import ROOT, load_config, system_params


def main():
    ap = argparse.ArgumentParser()
    ap.add_argument("--prefix", default="default")
    ap.add_argument("--config", nargs="*", default=[])
    ap.add_argument("--override", default="{}")
    ap.add_argument("--phase-bits", default=None, help="evaluate the tools with this phase resolution (int or 'ideal')")
    ap.add_argument("--n-drops", type=int, default=None, help="first n test drops (all by default)")
    ap.add_argument("--snr-list", type=float, nargs="*", default=None)
    ap.add_argument("--stored-snr", action="store_true", help="use the stored reference SNR of every drop instead of the SNR list")
    args = ap.parse_args()
    over = json.loads(args.override)
    cfg = load_config(*args.config, overrides=over)
    p = system_params(cfg)
    bits = "cfg" if args.phase_bits is None else (None if args.phase_bits == "ideal" else int(args.phase_bits))
    cb = cbm.polar_codebook(p, bits=bits)
    d = load_split(f"{args.prefix}_test", {"H", "Hhat", "w", "snr_db", "teacher_wsr_true"})
    n = len(d["w"]) if args.n_drops is None else min(args.n_drops, len(d["w"]))
    H, Hh, w = d["H"][:n, 0].astype(np.complex128), d["Hhat"][:n, 0].astype(np.complex128), d["w"][:n]
    if args.snr_list:
        cfg["snr_db_list"] = args.snr_list
    if args.stored_snr:
        points = [("stored", 10.0 ** (np.asarray(d["snr_db"][:n], float) / 10.0))]
    else:
        points = [(s, 10.0 ** (s / 10.0)) for s in cfg["snr_db_list"]]
    out = dict(prefix=args.prefix, phase_bits=args.phase_bits, stored_snr=args.stored_snr, n_drops=n,
               created=time.strftime("%Y-%m-%d %H:%M:%S"), snr_db=[], teacher_wsr=[], teacher_sum_rate=[], strongest_wsr=[],
               teacher_stored_snr_wsr=float(d["teacher_wsr_true"][:n].mean()))
    per_drop = {}
    for s, snr in points:
        t0 = time.time()
        res = teacher.teacher_actions(H, Hh, w, snr, cb, p.Ns)
        s2, g2, sh2 = teacher.strongest_users_actions(Hh, w, cb, p.Ns)
        wsr_str = np.sum(hbf.gather_users(w, s2) * hbf.apply_tools(H, Hh, s2, g2, sh2, cb, snr), axis=1)
        out["snr_db"].append(s)
        out["teacher_wsr"].append(float(res["wsr_true"].mean()))
        out["teacher_sum_rate"].append(float(res["rates_true"].sum(1).mean()))
        out["strongest_wsr"].append(float(wsr_str.mean()))
        per_drop[f"teacher_{s}"] = res["wsr_true"].astype(np.float32)
        per_drop[f"strongest_{s}"] = wsr_str.astype(np.float32)
        per_drop[f"sched_{s}"] = res["sched"].astype(np.int8)
        per_drop[f"groups_{s}"] = res["groups_all"].astype(np.int8)
        per_drop[f"shares_{s}"] = res["shares"].astype(np.float32)
        print(f"SNR {s}: teacher {out['teacher_wsr'][-1]:.2f}, strongest {out['strongest_wsr'][-1]:.2f} ({time.time() - t0:.0f} s)", flush=True)
    if args.stored_snr and args.phase_bits is None:
        # with the configured phases the recomputed teacher must reproduce the stored labels
        out["max_rel_dev_from_stored_labels"] = float(np.max(np.abs(per_drop["teacher_stored"] - d["teacher_wsr_true"][:n]) / d["teacher_wsr_true"][:n]))
    suffix = ("" if args.phase_bits is None else f"_bits{args.phase_bits}") + ("_stored" if args.stored_snr else "")
    base = ROOT / "results" / "aggregated" / f"teacher_sweep_{args.prefix}{suffix}"
    base.parent.mkdir(parents=True, exist_ok=True)
    base.with_suffix(".json").write_text(json.dumps(out, indent=1))
    np.savez(base.with_suffix(".npz"), **per_drop)
    print("saved", base)


if __name__ == "__main__":
    main()
