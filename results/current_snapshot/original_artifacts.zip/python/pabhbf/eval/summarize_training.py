"""Summaries of PAB-HBF training logs (per-epoch validation metrics).

  python -m pabhbf.eval.summarize_training --pattern "probe_lam*" --last 3 --name probe

For every run whose tag matches the pattern (newest log per tag and seed), the summary lists the privacy weight, the rate
ratio to the teacher, the hit probability and cell information of the training adversary, and the group and schedule
accuracies, at the last epoch and averaged over the last k adversarial epochs. The adversary here is the weak training
adversary, so these values place the lambda grid but are not the reported leakage. Writes
results/aggregated/training_summary_<name>.json.
"""
from __future__ import annotations

import argparse
import json

import numpy as np

from ..utils.config import ROOT

LOG_DIR = ROOT / "results" / "raw" / "train_logs" / "pabhbf"


def load_runs(pattern: str) -> dict:
    runs = {}
    for path in sorted(LOG_DIR.glob(f"{pattern}_s*_*.json")):
        d = json.loads(path.read_text())
        runs[(d["tag"], d["seed"])] = (path.name, d)  # file names end with a timestamp, so the newest log wins
    return runs


def summarize(d: dict, last: int) -> dict:
    hist = d["history"]
    adv = [h for h in hist if h["phase"] == "adversarial"] or hist
    tail = adv[-last:]

    def mean(key):
        return float(np.mean([h["val"][key] for h in tail]))

    return dict(epochs=len(hist), adversarial_epochs=sum(h["phase"] == "adversarial" for h in hist), lam=hist[-1]["lam"],
                ratio_last=hist[-1]["val"]["ratio"], ratio_tail=mean("ratio"), ratio_min_adversarial=min(h["val"]["ratio"] for h in adv),
                hit_last=hist[-1]["val"]["adv_hit"], hit_tail=mean("adv_hit"), mi_bits_tail=mean("adv_mi_bits"),
                group_acc_tail=mean("group_acc"), sched_overlap_tail=mean("sched_overlap"),
                median_epoch_s=float(np.median([h["epoch_s"] for h in hist])), init_checkpoint=d.get("init_checkpoint"))


def main(argv=None):
    ap = argparse.ArgumentParser()
    ap.add_argument("--pattern", required=True)
    ap.add_argument("--last", type=int, default=3)
    ap.add_argument("--name", default=None)
    args = ap.parse_args(argv)
    runs = load_runs(args.pattern)
    out = {f"{tag}_s{seed}": dict(file=name, **summarize(d, args.last)) for (tag, seed), (name, d) in runs.items()}
    rows = sorted(out.items(), key=lambda kv: kv[1]["lam"])
    print(f"{'run':<22}{'lam':>8}{'ratio':>8}{'ratio_t':>9}{'min':>7}{'hit':>7}{'hit_t':>7}{'bits_t':>8}{'group_t':>9}")
    for key, s in rows:
        print(f"{key:<22}{s['lam']:>8.3g}{s['ratio_last']:>8.3f}{s['ratio_tail']:>9.3f}{s['ratio_min_adversarial']:>7.3f}"
              f"{s['hit_last']:>7.3f}{s['hit_tail']:>7.3f}{s['mi_bits_tail']:>8.2f}{s['group_acc_tail']:>9.3f}")
    path = ROOT / "results" / "aggregated" / f"training_summary_{args.name or args.pattern.replace('*', '')}.json"
    path.parent.mkdir(parents=True, exist_ok=True)
    path.write_text(json.dumps(out, indent=1))
    print("saved", path)
    return out


if __name__ == "__main__":
    main()
