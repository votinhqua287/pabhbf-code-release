"""Evaluation of a trained controller and its representation (Tasks 10 and 14).

  python -m pabhbf.eval.evaluate --ckpt "results/checkpoints/pabhbf/lam1_s1_*.pt" --exp e1_lambda

Utility: realized weighted sum rate on the test drops at their stored SNR and at every reference SNR.
Privacy: attacker suite trained on representations of the attacker split, early-stopped on the validation split and
tested on the test split. Runtime: encoder per user, controller per drop and trusted tools per drop.
Results: results/raw/{exp}/{tag}_s{seed}_{stamp}.json and a .npz with per-drop weighted sum rates.
"""
from __future__ import annotations

import argparse
import glob
import json
import time

import numpy as np
import torch
from threadpoolctl import threadpool_limits

from ..attacks.suite import LOCATION_ATTACKERS, run_suite
from ..models.controller import SetController
from ..models.representations import csi_features
from ..phy import codebook as cbm
from ..train.common import controller_actions, encode_all, evaluate_controller, realized_wsr, run_metadata
from ..train.data import angle_domain_features, load_task_data
from ..train.pabhbf import build_encoder
from ..utils.config import ROOT, system_params


def resolve(pattern: str) -> str:
    paths = sorted(glob.glob(pattern) or glob.glob(str(ROOT / pattern)))
    if not paths:
        raise FileNotFoundError(pattern)
    return paths[-1]


class Method:
    def __init__(self, ckpt: dict, p):
        self.ckpt, self.p, self.kind = ckpt, p, ckpt["kind"]
        self.ctrl = SetController(**ckpt["controller_cfg"])
        self.ctrl.load_state_dict(ckpt["controller"])
        self.ctrl.eval()
        self.payload_bits = ckpt["payload_bits"]
        if self.kind == "pabhbf":
            self.enc = build_encoder(ckpt["encoder_cfg"], p.Nt)
            self.enc.load_state_dict(ckpt["encoder"])
            self.enc.eval()
        else:
            self.rep = ckpt["rep"]

    def represent(self, Hhat: np.ndarray, rng: np.random.Generator) -> torch.Tensor:
        n, K = Hhat.shape[:2]
        if self.kind == "pabhbf":
            source = self.ckpt["encoder_cfg"]["input"]
            if source == "angle_domain":
                X, _ = angle_domain_features(Hhat, self.p, self.ckpt["input_stats"])
            else:
                X = torch.as_tensor(csi_features(Hhat, self.p, "antenna" if source == "antenna" else "beam").reshape(n, K, -1))
            return encode_all(self.enc, X)
        return torch.as_tensor(self.rep.transform(Hhat, rng).reshape(n, K, -1))


def main(argv=None):
    ap = argparse.ArgumentParser()
    ap.add_argument("--ckpt", required=True)
    ap.add_argument("--exp", required=True)
    ap.add_argument("--prefix", default=None, help="data prefix of the val/attack splits (default: training prefix)")
    ap.add_argument("--test-prefix", default=None, help="data prefix of the test split (mismatch tests)")
    ap.add_argument("--attack-prefix", default=None)
    ap.add_argument("--phase-bits", default=None, help="phase resolution of the tools at evaluation (int or 'ideal')")
    ap.add_argument("--no-privacy", action="store_true")
    ap.add_argument("--no-decoder", action="store_true")
    ap.add_argument("--no-snr-sweep", action="store_true")
    ap.add_argument("--attackers", nargs="*", default=list(LOCATION_ATTACKERS))
    ap.add_argument("--epochs-att", type=int, default=40)
    ap.add_argument("--keep-predictions", action="store_true")
    ap.add_argument("--seed-eval", type=int, default=0)
    ap.add_argument("--threads", type=int, default=16)
    ap.add_argument("--label", default=None)
    args = ap.parse_args(argv)
    torch.set_num_threads(args.threads)
    blas_limit = threadpool_limits(limits=args.threads)  # noqa: F841  (kept alive for the whole evaluation)
    path = resolve(args.ckpt)
    ckpt = torch.load(path, weights_only=False)
    cfg = ckpt["config"]
    p = system_params(cfg)
    cb = cbm.polar_codebook(p)
    bits = "cfg" if args.phase_bits is None else (None if args.phase_bits == "ideal" else int(args.phase_bits))
    cb_eval = cb if args.phase_bits is None else cbm.polar_codebook(p, bits=bits)
    prefix = args.prefix or ckpt["args"]["prefix"]
    test_prefix, attack_prefix = args.test_prefix or prefix, args.attack_prefix or prefix
    method = Method(ckpt, p)
    rng = np.random.default_rng(args.seed_eval)
    t_start = time.time()

    te = load_task_data(f"{test_prefix}_test", p, cb)
    idx = np.arange(te.n)
    Zte = method.represent(te.Hhat, rng)
    utility, wsr_drop = evaluate_controller(method.ctrl, Zte, te, cb_eval, p, idx)
    per_drop = dict(wsr_stored_snr=wsr_drop.astype(np.float32))
    per_snr = {}
    if not args.no_snr_sweep:
        for s in cfg["snr_db_list"]:
            res, w_s = evaluate_controller(method.ctrl, Zte, te, cb_eval, p, idx, snr_db=s)
            per_snr[str(s)] = res
            per_drop[f"wsr_{s}"] = w_s.astype(np.float32)
    utility["per_snr"] = per_snr

    n_rt = min(1000, te.n)
    t0 = time.time()
    method.represent(te.Hhat[:n_rt], rng)
    enc_ms = 1e3 * (time.time() - t0) / (n_rt * p.K)
    t0 = time.time()
    sched, groups, shares = controller_actions(method.ctrl, Zte[:n_rt], te.w[:n_rt], te.snr_db[:n_rt], p.Ns)
    ctrl_ms = 1e3 * (time.time() - t0) / n_rt
    t0 = time.time()
    realized_wsr(te.H[:n_rt], te.Hhat[:n_rt], te.w[:n_rt].numpy().astype(float), sched, groups, shares, cb_eval, te.snr_db[:n_rt].numpy())
    tools_ms = 1e3 * (time.time() - t0) / n_rt
    runtime = dict(encoder_ms_per_user=enc_ms, controller_ms_per_drop=ctrl_ms, tools_ms_per_drop=tools_ms, threads=args.threads)

    privacy = None
    if not args.no_privacy:
        va = load_task_data(f"{prefix}_val", p, cb, teacher=False, with_true=False)
        at = load_task_data(f"{attack_prefix}_attack", p, cb, teacher=False, with_true=False)
        Z = dict(attack=method.represent(at.Hhat, rng), val=method.represent(va.Hhat, rng), test=Zte)
        d = Zte.shape[-1]
        Z = {k: v.reshape(-1, d).numpy() for k, v in Z.items()}
        xy = dict(attack=at.xy, val=va.xy, test=te.xy)
        csi = None if args.no_decoder else dict(attack=at.X.reshape(-1, at.X.shape[-1]).numpy(),
                                                val=va.X.reshape(-1, va.X.shape[-1]).numpy(),
                                                test=te.X.reshape(-1, te.X.shape[-1]).numpy())
        privacy = run_suite(Z, xy, p, cfg, attackers=tuple(args.attackers), csi=csi, seed=args.seed_eval,
                            epochs=args.epochs_att, keep_predictions=args.keep_predictions,
                            grid_cell=cfg["privacy"].get("attack_grid_cell_m", 0.5), n_jobs=args.threads)
        if args.keep_predictions:
            for k, v in privacy.pop("predictions").items():
                per_drop[f"pred_{k}"] = v
            per_drop["xy_test"] = te.xy.reshape(-1, 2).astype(np.float32)

    label = args.label or f"{ckpt['tag']}_s{ckpt['seed']}"
    out_dir = ROOT / "results" / "raw" / args.exp
    out_dir.mkdir(parents=True, exist_ok=True)
    stamp = time.strftime("%Y%m%d-%H%M%S")
    result = dict(label=label, group=args.label or ckpt["tag"], kind=ckpt["kind"], tag=ckpt["tag"], seed=ckpt["seed"], checkpoint=path,
                  rep_name=ckpt.get("rep_name", "pabhbf"), train_args=ckpt["args"], eval_args=vars(args),
                  payload_bits=method.payload_bits, lam_final=ckpt.get("lam_final"), test_prefix=test_prefix,
                  attack_prefix=attack_prefix, utility=utility, privacy=privacy, runtime=runtime,
                  eval_s=time.time() - t_start, meta=run_metadata())
    (out_dir / f"{label}_{stamp}.json").write_text(json.dumps(result, indent=1))
    np.savez(out_dir / f"{label}_{stamp}.npz", **per_drop)
    summary = privacy["summary"] if privacy else {}
    print(f"{label}: wsr {utility['wsr']:.2f} ratio {utility.get('ratio', float('nan')):.4f} "
          f"leakage {summary.get('leakage', float('nan')):.3f} ({summary.get('leakage_attacker', '-')}) "
          f"rmse {summary.get('rmse_min_m', float('nan')):.2f} m, nmse {privacy['decoder']['nmse_db'] if privacy and 'decoder' in privacy else float('nan'):.2f} dB",
          flush=True)
    return result


if __name__ == "__main__":
    main()
