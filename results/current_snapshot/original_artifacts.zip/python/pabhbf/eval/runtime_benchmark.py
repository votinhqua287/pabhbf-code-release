"""Latency of every scheme of Table III, timed back to back in one process on the same test drops.

  python -m pabhbf.eval.runtime_benchmark --lam-main 0.03 --n-drops 1000 --threads 5 --repeats 3

eval/evaluate.py records the encoder, controller and tool times during each evaluation, but different evaluations share
the machine with different jobs. This benchmark loads the seed-1 checkpoint of every scheme, times the same three steps on
the same drops, repeats each measurement and keeps the median. The teacher is timed by eval/runtime_teacher.py.
"""
from __future__ import annotations

import argparse
import json
import time

import numpy as np
import torch
from threadpoolctl import threadpool_limits

from ..phy import codebook as cbm
from ..train.common import controller_actions, realized_wsr, run_metadata
from ..train.data import load_task_data
from ..utils.config import ROOT, load_config, system_params
from .evaluate import Method, resolve
from .runtime_teacher import teacher_latency

BASELINES = ("raw_csi", "pca", "random_projection", "scalar_quant", "gaussian_pca_0.2", "gaussian_pca_0.8", "top_m_beams",
             "autoencoder", "angle_domain", "laplace_pca_100", "laplace_pca_10")


def scheme_latency(method: Method, p, cb, te, n: int, rng: np.random.Generator) -> dict:
    t0 = time.perf_counter()
    Z = method.represent(te.Hhat[:n], rng)
    enc = 1e3 * (time.perf_counter() - t0) / (n * p.K)
    t0 = time.perf_counter()
    sched, groups, shares = controller_actions(method.ctrl, Z, te.w[:n], te.snr_db[:n], p.Ns)
    ctrl = 1e3 * (time.perf_counter() - t0) / n
    t0 = time.perf_counter()
    realized_wsr(te.H[:n], te.Hhat[:n], te.w[:n].numpy().astype(float), sched, groups, shares, cb, te.snr_db[:n].numpy())
    tools = 1e3 * (time.perf_counter() - t0) / n
    return dict(encoder_ms_per_user=enc, controller_ms_per_drop=ctrl, tools_ms_per_drop=tools)


def main(argv=None):
    ap = argparse.ArgumentParser()
    ap.add_argument("--lam-main", type=float, required=True)
    ap.add_argument("--seed", type=int, default=1)
    ap.add_argument("--n-drops", type=int, default=1000)
    ap.add_argument("--threads", type=int, default=5)
    ap.add_argument("--repeats", type=int, default=3)
    args = ap.parse_args(argv)
    torch.set_num_threads(args.threads)
    blas_limit = threadpool_limits(limits=args.threads)  # noqa: F841  (kept alive for the whole run)
    cfg = load_config()
    p = system_params(cfg)
    cb = cbm.polar_codebook(p)
    te = load_task_data("default_test", p, cb)
    n = min(args.n_drops, te.n)
    targets = [("pabhbf", f"lam{args.lam_main:g}"), ("pabhbf", "lam0")] + [("baselines", b) for b in BASELINES]
    out = dict(n_drops=n, threads=args.threads, repeats=args.repeats, lam_main=args.lam_main, seed=args.seed, schemes={})
    for kind, tag in targets:
        try:
            path = resolve(f"results/checkpoints/{kind}/{tag}_s{args.seed}_*.pt")
        except FileNotFoundError:
            print(f"{tag}: no checkpoint, skipped", flush=True)
            continue
        method = Method(torch.load(path, weights_only=False), p)
        reps = [scheme_latency(method, p, cb, te, n, np.random.default_rng(r)) for r in range(args.repeats)]
        med = {k: float(np.median([r[k] for r in reps])) for k in reps[0]}
        med["latency_ms_per_drop"] = p.K * med["encoder_ms_per_user"] + med["controller_ms_per_drop"] + med["tools_ms_per_drop"]
        out["schemes"][tag] = dict(checkpoint=path, **med)
        print(tag, json.dumps(med), flush=True)
    reps = [teacher_latency(te, p, cb, n) for _ in range(args.repeats)]
    out["teacher"] = {k: float(np.median([r[k] for r in reps])) for k in ("decision_ms_per_drop", "tools_ms_per_drop", "teacher_ms_per_drop")}
    print("teacher", json.dumps(out["teacher"]), flush=True)
    out.update(created=time.strftime("%Y-%m-%d %H:%M:%S"), meta=run_metadata())
    path = ROOT / "results" / "aggregated" / "runtime_benchmark.json"
    path.parent.mkdir(parents=True, exist_ok=True)
    path.write_text(json.dumps(out, indent=1))
    return out


if __name__ == "__main__":
    main()
