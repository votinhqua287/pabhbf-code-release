"""Task 13 evaluation: direct action network versus tool-orchestrating planners on the same representations.

  python -m pabhbf.eval.agentic --ckpt "results/checkpoints/pabhbf/<tag>_s1_*.pt"
Reports, per planner, the realized weighted sum rate and its ratio to the teacher, the latency per drop (controller plus
tools), the tool calls per drop and the exposure bits per drop returned to the planner.
"""
from __future__ import annotations

import argparse
import json
import time

import numpy as np
import torch

from ..agents.planner import DirectAction, LearnedToolPolicy, RulePlanner, SearchPlanner, TrustedToolbox
from ..phy import codebook as cbm
from ..phy import hbf
from ..train.data import load_task_data
from ..train.common import run_metadata
from ..utils.config import ROOT, system_params
from .evaluate import Method, resolve


@torch.no_grad()
def controller_logits(method, data, rows, batch=512):
    Z = method.represent(data.Hhat[rows], np.random.default_rng(0))
    out = [method.ctrl(Z[i:i + batch], data.w[rows][i:i + batch], data.snr_db[rows][i:i + batch]) for i in range(0, len(rows), batch)]
    return tuple(torch.cat([o[j] for o in out]).numpy().astype(np.float64) for j in range(3))


def main(argv=None):
    ap = argparse.ArgumentParser()
    ap.add_argument("--ckpt", required=True)
    ap.add_argument("--n-test", type=int, default=2000)
    ap.add_argument("--n-fit", type=int, default=2000)
    ap.add_argument("--mu-latency", type=float, default=0.02)
    ap.add_argument("--nu-bits", type=float, default=0.02)
    ap.add_argument("--threads", type=int, default=8)
    ap.add_argument("--exp", default="e13_agentic")
    args = ap.parse_args(argv)
    from threadpoolctl import threadpool_limits

    torch.set_num_threads(args.threads)
    blas_limit = threadpool_limits(limits=args.threads)  # noqa: F841  (kept alive for the whole run)
    path = resolve(args.ckpt)
    ckpt = torch.load(path, weights_only=False)
    cfg = ckpt["config"]
    p = system_params(cfg)
    cb = cbm.polar_codebook(p)
    method = Method(ckpt, p)
    prefix = ckpt["args"]["prefix"]
    te = load_task_data(f"{prefix}_test", p, cb)
    va = load_task_data(f"{prefix}_val", p, cb)

    def realized(data):
        def fn(sched, FRF, FBB, rows):
            g = hbf.sinr(hbf.gather_users(data.H[rows], sched), FRF, FBB, 10.0 ** (-data.snr_db[rows].numpy() / 10.0))
            return np.sum(hbf.gather_users(data.w[rows].numpy().astype(float), sched) * np.log2(1.0 + g), axis=1)
        return fn

    rows_fit = np.arange(min(args.n_fit, va.n))
    L_fit = controller_logits(method, va, rows_fit)
    box_fit = TrustedToolbox(va.Hhat[rows_fit], va.w[rows_fit].numpy().astype(float), va.snr_db[rows_fit].numpy(), cb)
    chains = [DirectAction(), RulePlanner(), SearchPlanner(4)]
    learned = LearnedToolPolicy(chains, args.mu_latency, args.nu_bits).fit(
        L_fit, box_fit, np.arange(len(rows_fit)), lambda s, F1, F2, r: realized(va)(s, F1, F2, rows_fit[r]),
        va.teacher["wsr_teacher"][rows_fit].numpy(), p.Ns)

    rows = np.arange(min(args.n_test, te.n))
    t0 = time.time()
    L = controller_logits(method, te, rows)
    ctrl_ms = 1e3 * (time.time() - t0) / len(rows)
    teacher = te.teacher["wsr_teacher"][rows].numpy()
    out = dict(checkpoint=path, n_test=len(rows), controller_ms_per_drop=ctrl_ms, learned_fit=dict(
        label_counts=learned.label_counts, chain_costs=learned.chain_costs, mu_latency=args.mu_latency, nu_bits=args.nu_bits),
        planners={})
    for planner in (DirectAction(), RulePlanner(), SearchPlanner(2), SearchPlanner(4), learned):
        t0 = time.time()
        box = TrustedToolbox(te.Hhat[rows], te.w[rows].numpy().astype(float), te.snr_db[rows].numpy(), cb)
        sched, FRF, FBB = planner.run(L, box, np.arange(len(rows)), p.Ns)
        ms = 1e3 * (time.time() - t0) / len(rows)
        wsr = realized(te)(sched, FRF, FBB, rows)
        out["planners"][planner.name] = dict(
            wsr=float(wsr.mean()), ratio=float(wsr.mean() / teacher.mean()), tools_ms_per_drop=ms,
            latency_ms_per_drop=ms + ctrl_ms, calls_per_drop={k: v / len(rows) for k, v in box.calls.items()},
            exposure_bits_per_drop=box.exposure_bits / len(rows),
            choice_counts=getattr(planner, "last_choice_counts", None))
        print(planner.name, json.dumps(out["planners"][planner.name]), flush=True)
    out["meta"] = run_metadata()
    out_dir = ROOT / "results" / "raw" / args.exp
    out_dir.mkdir(parents=True, exist_ok=True)
    (out_dir / f"{ckpt['tag']}_s{ckpt['seed']}_{time.strftime('%Y%m%d-%H%M%S')}.json").write_text(json.dumps(out, indent=1))
    return out


if __name__ == "__main__":
    main()
