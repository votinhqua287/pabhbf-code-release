"""MATLAB/Python cross-check of the channel model and the trusted tools (Tasks 3-4).

  python -m pabhbf.eval.crosscheck_matlab export   -> data/metadata/crosscheck_in.mat
  matlab -batch "addpath('matlab/tests'); crosscheck_python('data/metadata/crosscheck_in.mat','data/metadata/crosscheck_out.mat')"
  python -m pabhbf.eval.crosscheck_matlab compare  -> prints the maximum deviations and writes a JSON report
"""
from __future__ import annotations

import json
import sys

import numpy as np
from scipy.io import loadmat, savemat

from ..data import channel as ch
from ..data.dataset import draw_gains
from ..phy import codebook as cbm
from ..phy import hbf, teacher
from ..utils.config import ROOT, load_config, system_params

META = ROOT / "data" / "metadata"


def export(n: int = 20, seed: int = 99):
    p = system_params(load_config())
    cb = cbm.polar_codebook(p)
    rng = np.random.default_rng(seed)
    g = ch.sample_geometry(rng, n, p)
    alpha = draw_gains(rng, g.beta, p)
    resp = ch.path_responses(g, p)
    H = np.sqrt(p.Nt) * np.einsum("nkl,nklm->nkm", alpha, resp)
    Hh = ch.estimate_channels(rng, H, p.sigma_est2)
    w = rng.choice([1.0, 2.0], size=(n, p.K))
    snr = 10 ** (rng.choice([-5.0, 5.0, 15.0], size=n) / 10)
    out = teacher.teacher_actions(H, Hh, w, snr, cb, p.Ns, power_iters=40)
    rates, info = hbf.apply_tools(H, Hh, out["sched"], out["groups_S"], out["shares"], cb, snr, return_all=True)
    META.mkdir(parents=True, exist_ok=True)
    savemat(META / "crosscheck_in.mat", dict(
        Nt=p.Nt, lam=p.lam, alpha=alpha,
        r_paths=np.concatenate([g.r[..., None], g.r_sc], -1), theta_paths=np.concatenate([g.theta[..., None], g.theta_sc], -1),
        Hhat=Hh, W=cb.W, idx=info["idx"], sched=out["sched"], shares=out["shares"], snr=snr, H_py=H, rates_py=rates))
    print("exported", META / "crosscheck_in.mat")


def compare():
    a = loadmat(META / "crosscheck_in.mat")
    b = loadmat(META / "crosscheck_out.mat")
    dH = float(np.max(np.abs(a["H_py"] - b["H"])) / np.max(np.abs(a["H_py"])))
    dR = float(np.max(np.abs(a["rates_py"] - b["rates"])))
    report = dict(relative_max_channel_deviation=dH, max_rate_deviation_bits=dR, passed=bool(dH < 1e-10 and dR < 1e-9))
    (META / "crosscheck_report.json").write_text(json.dumps(report, indent=2))
    print(report)


if __name__ == "__main__":
    {"export": export, "compare": compare}[sys.argv[1]]()
