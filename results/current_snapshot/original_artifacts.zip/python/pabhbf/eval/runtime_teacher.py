"""Latency of the teacher (B0) per drop, measured like the controller latencies of eval/evaluate.py (Table III).

  python -m pabhbf.eval.runtime_teacher --n-drops 1000 --threads 5

The decision time covers the steps of phy/teacher.teacher_actions that choose the action: codeword gains, greedy
schedule, precoders and coupling matrix of the chosen set, and the power optimization. The tool time executes the chosen
actions with train/common.realized_wsr, which is the call that eval/evaluate.py times for the learned controllers.
"""
from __future__ import annotations

import argparse
import json
import time

import numpy as np
import torch
from threadpoolctl import threadpool_limits

from ..phy import codebook as cbm
from ..phy.hbf import build_precoders, codeword_gains, coupling_matrix, gather_users
from ..phy.teacher import greedy_schedule, optimize_shares
from ..train.common import realized_wsr, run_metadata
from ..train.data import load_task_data
from ..utils.config import ROOT, load_config, system_params


def teacher_latency(te, p, cb, n: int, power_iters: int = 120) -> dict:
    """Decision and tool times per drop of the teacher on the first n drops of a loaded split with teacher labels."""
    Hh = te.Hhat[:n].astype(np.complex128)
    w = te.w[:n].numpy().astype(float)
    snr_db = te.snr_db[:n].numpy().astype(float)
    snr = 10.0 ** (snr_db / 10.0)

    t0 = time.perf_counter()
    gains = codeword_gains(Hh, cb)
    groups_all = cb.group[np.argmax(gains, axis=2)]
    sched = greedy_schedule(Hh, w, snr, cb, p.Ns, groups_all, gains)
    groups_S = gather_users(groups_all, sched)
    _, FRF, Fbar = build_precoders(Hh, sched, groups_S, np.full((n, p.Ns), 1.0 / p.Ns), cb, snr, gains=gains)
    A = coupling_matrix(gather_users(Hh, sched), FRF, Fbar)
    shares = optimize_shares(A, gather_users(w, sched), 1.0 / snr, iters=power_iters)
    decision_ms = 1e3 * (time.perf_counter() - t0) / n

    t0 = time.perf_counter()
    wsr, _ = realized_wsr(te.H[:n], te.Hhat[:n], w, sched, groups_S, shares, cb, snr_db)
    tools_ms = 1e3 * (time.perf_counter() - t0) / n

    stored = te.teacher["wsr_teacher"][:n].numpy().astype(float)
    return dict(decision_ms_per_drop=decision_ms, tools_ms_per_drop=tools_ms, teacher_ms_per_drop=decision_ms + tools_ms,
                wsr_mean=float(wsr.mean()), stored_teacher_wsr_mean=float(stored.mean()),
                max_rel_dev_from_stored=float(np.max(np.abs(wsr - stored) / stored)))


def main(argv=None):
    ap = argparse.ArgumentParser()
    ap.add_argument("--prefix", default="default")
    ap.add_argument("--n-drops", type=int, default=1000)
    ap.add_argument("--threads", type=int, default=5)
    ap.add_argument("--power-iters", type=int, default=120)
    args = ap.parse_args(argv)
    torch.set_num_threads(args.threads)
    blas_limit = threadpool_limits(limits=args.threads)  # noqa: F841  (kept alive for the whole run)
    cfg = load_config()
    p = system_params(cfg)
    cb = cbm.polar_codebook(p)
    te = load_task_data(f"{args.prefix}_test", p, cb)
    n = min(args.n_drops, te.n)
    out = dict(prefix=args.prefix, n_drops=n, threads=args.threads, **teacher_latency(te, p, cb, n, args.power_iters),
               created=time.strftime("%Y-%m-%d %H:%M:%S"), meta=run_metadata())
    path = ROOT / "results" / "aggregated" / "runtime_teacher.json"
    path.parent.mkdir(parents=True, exist_ok=True)
    path.write_text(json.dumps(out, indent=1))
    print(json.dumps({k: v for k, v in out.items() if k != "meta"}, indent=1))
    return out


if __name__ == "__main__":
    main()
