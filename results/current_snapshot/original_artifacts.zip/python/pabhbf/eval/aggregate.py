"""Aggregation of evaluation results over training seeds (Task 17).

  python -m pabhbf.eval.aggregate --exp e1_lambda
Reads results/raw/{exp}/*.json, keeps the newest result for every (label), groups labels by tag, and writes
results/aggregated/{exp}.json with the mean, the sample standard deviation and the half-width of a 95 % Student-t
confidence interval of every scalar metric over the seeds of a tag.
"""
from __future__ import annotations

import argparse
import json
from collections import defaultdict

import numpy as np
from scipy import stats

from ..utils.config import ROOT

COMMON_ATTACKERS = ("mlp_xy", "knn", "grid_map", "grid_mean")


def flatten(res: dict) -> dict:
    out = {"payload_bits": res.get("payload_bits")}
    u = res.get("utility") or {}
    for k in ("wsr", "ratio", "sum_rate", "sched_overlap", "group_acc", "teacher_wsr"):
        if k in u:
            out[f"utility.{k}"] = u[k]
    for s, v in (u.get("per_snr") or {}).items():
        out[f"utility.per_snr.{s}.wsr"] = v["wsr"]
        out[f"utility.per_snr.{s}.sum_rate"] = v["sum_rate"]
    pr = res.get("privacy") or {}
    for k, v in (pr.get("summary") or {}).items():
        if isinstance(v, (int, float)):
            out[f"privacy.{k}"] = v
    attackers = pr.get("attackers") or {}
    for name, a in attackers.items():
        for k in ("hit_prob", "rmse_m", "median_err_m", "range_mae_m", "angle_mae_deg", "r2", "mi_lower_bound_bits"):
            if k in a:
                out[f"privacy.{name}.{k}"] = a[k]
    common = [attackers[a] for a in COMMON_ATTACKERS if a in attackers]
    if common:  # attackers run for every seed, so that averages over seeds use the same suite
        out["privacy.leakage_common"] = max(a["hit_prob"] for a in common)
        out["privacy.rmse_common_m"] = min(a["rmse_m"] for a in common)
    if "decoder" in pr:
        out["privacy.decoder.nmse_db"] = pr["decoder"]["nmse_db"]
    for k, v in (res.get("runtime") or {}).items():
        out[f"runtime.{k}"] = v
    if res.get("lam_final") is not None:
        out["lam_final"] = res["lam_final"]
    return {k: v for k, v in out.items() if isinstance(v, (int, float)) and v is not None}


def summarize(values) -> dict:
    x = np.asarray(values, float)
    n = len(x)
    sd = float(x.std(ddof=1)) if n > 1 else 0.0
    half = float(stats.t.ppf(0.975, n - 1) * sd / np.sqrt(n)) if n > 1 else float("nan")
    return dict(mean=float(x.mean()), std=sd, ci95=half, n=n, values=x.tolist())


def aggregate(exp: str) -> dict:
    newest = {}
    for path in sorted((ROOT / "results" / "raw" / exp).glob("*.json")):
        res = json.loads(path.read_text())
        if "label" not in res:
            continue
        newest[res["label"]] = (path.name, res)
    groups = defaultdict(list)
    for name, res in newest.values():
        groups[res.get("group", res["tag"])].append((name, res))
    out = {}
    for tag, items in sorted(groups.items()):
        metrics = defaultdict(list)
        for _, res in items:
            for k, v in flatten(res).items():
                metrics[k].append(v)
        out[tag] = dict(files=[n for n, _ in items], seeds=[r["seed"] for _, r in items],
                        rep_name=items[0][1].get("rep_name"), train_args=items[0][1].get("train_args"),
                        metrics={k: summarize(v) for k, v in metrics.items()})
    path = ROOT / "results" / "aggregated" / f"{exp}.json"
    path.parent.mkdir(parents=True, exist_ok=True)
    path.write_text(json.dumps(out, indent=1))
    return out


def main():
    ap = argparse.ArgumentParser()
    ap.add_argument("--exp", nargs="+", required=True)
    for exp in ap.parse_args().exp:
        out = aggregate(exp)
        for tag, g in out.items():
            m = g["metrics"]
            print(f"{exp}/{tag}: n={len(g['seeds'])} ratio {m.get('utility.ratio', {}).get('mean', float('nan')):.4f} "
                  f"leakage {m.get('privacy.leakage', {}).get('mean', float('nan')):.3f}")


if __name__ == "__main__":
    main()
