"""Dataset generation with teacher labels (Task 5).

A split stores, for n drops (blocks) and T intervals:
- geometry: r, theta, xy, beta, shadow_db (n, K), scatterers (n, K, L)
- weights w (n, K) and reference SNR snr_db (n,)
- channels H and estimates Hhat (n, T, K, Nt) as complex64, for the near-field model and optionally the far-field
  twin, which shares the geometry, the path gains and the estimation noise
- teacher actions and rates for interval 0 (near-field model)
"""
from __future__ import annotations

import pathlib
import time

import numpy as np

from ..phy import codebook as cbm
from ..phy import teacher as tch
from ..utils.config import ROOT, SystemParams
from . import channel as ch

DATA_DIR = ROOT / "data" / "processed"


def draw_gains(rng: np.random.Generator, beta: np.ndarray, p: SystemParams) -> np.ndarray:
    n, K = beta.shape
    los = np.sqrt(p.kappa * beta / (p.kappa + 1.0)) * np.exp(1j * rng.uniform(0, 2 * np.pi, (n, K)))
    std = np.sqrt(beta / ((p.kappa + 1.0) * p.L))[..., None]
    nlos = std * (rng.standard_normal((n, K, p.L)) + 1j * rng.standard_normal((n, K, p.L))) / np.sqrt(2.0)
    return np.concatenate([los[..., None], nlos], axis=-1)


def generate_split(p: SystemParams, n: int, seed: int, snr_db, T: int = 1, far_field_twin: bool = False,
                   teacher: bool = True, weights=(1.0, 2.0), weight_probs=(0.5, 0.5), chunk: int = 2000,
                   verbose: bool = True) -> dict:
    rng = np.random.default_rng(seed)
    geom = ch.sample_geometry(rng, n, p)
    w = rng.choice(np.asarray(weights), size=(n, p.K), p=np.asarray(weight_probs))
    snr_db = np.asarray(snr_db, float)
    snr_drop = rng.choice(snr_db, size=n) if snr_db.ndim and snr_db.size > 1 else np.full(n, float(snr_db))
    H = np.empty((n, T, p.K, p.Nt), np.complex64)
    Hh = np.empty_like(H)
    Hff = np.empty_like(H) if far_field_twin else None
    Hhff = np.empty_like(H) if far_field_twin else None
    for c0 in range(0, n, chunk):
        sl = slice(c0, min(n, c0 + chunk))
        sub = ch.Geometry(geom.r[sl], geom.theta[sl], geom.r_sc[sl], geom.theta_sc[sl], geom.shadow_db[sl], geom.beta[sl])
        resp_nf = ch.path_responses(sub, p, "near_field")
        resp_ff = ch.path_responses(sub, p, "far_field") if far_field_twin else None
        for t in range(T):
            alpha = draw_gains(rng, sub.beta, p)
            noise = (rng.standard_normal(resp_nf.shape[:2] + (p.Nt,)) + 1j * rng.standard_normal(resp_nf.shape[:2] + (p.Nt,))) * np.sqrt(p.sigma_est2 / 2)
            h = np.sqrt(p.Nt) * np.einsum("nkl,nklm->nkm", alpha, resp_nf)
            H[sl, t], Hh[sl, t] = h, h + noise
            if far_field_twin:
                hf = np.sqrt(p.Nt) * np.einsum("nkl,nklm->nkm", alpha, resp_ff)
                Hff[sl, t], Hhff[sl, t] = hf, hf + noise
    out = dict(r=geom.r, theta=geom.theta, xy=geom.xy(), beta=geom.beta, shadow_db=geom.shadow_db,
               r_sc=geom.r_sc, theta_sc=geom.theta_sc, w=w, snr_db=snr_drop, H=H, Hhat=Hh)
    if far_field_twin:
        out.update(H_ff=Hff, Hhat_ff=Hhff)
    if teacher:
        cb = cbm.polar_codebook(p)
        t0 = time.time()
        keys = ("sched", "groups_all", "groups_S", "shares", "rates_true", "wsr_true", "wsr_est")
        acc = {k: [] for k in keys}
        for c0 in range(0, n, chunk):
            sl = slice(c0, min(n, c0 + chunk))
            res = tch.teacher_actions(H[sl, 0].astype(np.complex128), Hh[sl, 0].astype(np.complex128), w[sl],
                                      10 ** (snr_drop[sl] / 10), cb, p.Ns)
            for k in keys:
                acc[k].append(res[k])
            if verbose:
                print(f"  teacher {sl.stop}/{n} drops, {time.time() - t0:.1f} s", flush=True)
        out.update({f"teacher_{k}": np.concatenate(v) for k, v in acc.items()})
    return out


def save_split(data: dict, name: str, meta: dict) -> pathlib.Path:
    DATA_DIR.mkdir(parents=True, exist_ok=True)
    path = DATA_DIR / f"{name}.npz"
    np.savez(path, **data, meta=np.array(repr(meta)))
    return path


def load_split(name: str, keys=None) -> dict:
    """Load a split; keys restricts the arrays read from disk (all arrays by default)."""
    with np.load(DATA_DIR / f"{name}.npz", allow_pickle=False) as f:
        return {k: f[k] for k in f.files if keys is None or k in keys}
