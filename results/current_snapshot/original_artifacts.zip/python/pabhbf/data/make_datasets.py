"""Command-line entry point for dataset generation (Task 5).

Example:
  python -m pabhbf.data.make_datasets --config smoke.yaml --splits train val test
"""
from __future__ import annotations

import argparse
import json
import platform
import time

import numpy as np

from ..utils.config import load_config, system_params
from .dataset import generate_split, save_split


def main():
    ap = argparse.ArgumentParser()
    ap.add_argument("--config", nargs="*", default=[])
    ap.add_argument("--splits", nargs="+", default=["train", "val", "test"])
    ap.add_argument("--prefix", default="default")
    ap.add_argument("--T", type=int, default=None)
    ap.add_argument("--far-field-twin", action="store_true")
    ap.add_argument("--no-teacher", action="store_true")
    ap.add_argument("--override", default="{}", help="JSON dictionary merged into the configuration")
    ap.add_argument("--chunk", type=int, default=2000, help="drops per generation chunk (reduce for large arrays)")
    args = ap.parse_args()
    cfg = load_config(*args.config, overrides=json.loads(args.override))
    p = system_params(cfg)
    seeds = {"train": 1, "val": 2, "test": 3, "attack": 4}
    sizes = {"train": cfg["dataset"]["num_train_drops"], "val": cfg["dataset"]["num_val_drops"],
             "test": cfg["dataset"]["num_test_drops"],
             "attack": cfg["dataset"].get("num_attack_drops", cfg["dataset"]["num_train_drops"])}
    T = args.T or cfg["dataset"]["intervals_per_block"]
    for split in args.splits:
        t0 = time.time()
        snr = cfg["snr_db_list"]
        data = generate_split(p, sizes[split], cfg["seed"] + seeds[split], snr, T=T,
                              far_field_twin=args.far_field_twin, teacher=not args.no_teacher,
                              weights=cfg["weights"]["classes"], weight_probs=cfg["weights"]["probs"], chunk=args.chunk)
        meta = dict(config=cfg, split=split, T=T, seed=cfg["seed"] + seeds[split], python=platform.python_version(),
                    numpy=np.__version__, created=time.strftime("%Y-%m-%d %H:%M:%S"))
        path = save_split(data, f"{args.prefix}_{split}", meta)
        print(f"{split}: saved {path} in {time.time() - t0:.1f} s", flush=True)


if __name__ == "__main__":
    main()
