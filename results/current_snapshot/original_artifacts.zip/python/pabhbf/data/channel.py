"""Near-field (non-uniform spherical wave) and far-field channel generators (Task 3).

Conventions (docs/SYSTEM_MODEL.md):
- ULA on the y-axis, centered at the origin, broadside along +x; delta_n = n - (Nt + 1)/2, n = 1..Nt.
- Point p(r, theta) = [r cos(theta), r sin(theta)], theta in (-pi/2, pi/2).
- Near-field response [b]_n = (r / r_n) exp(-j 2 pi (r_n - r) / lam) / sqrt(Nt), reference = array center.
- Far-field response [b_ff]_n = exp(+j 2 pi delta_n d sin(theta) / lam) / sqrt(Nt).
- h = sqrt(Nt) * sum_l alpha_l b(r_l, theta_l), alpha_0 = sqrt(kappa beta/(kappa+1)) e^{j chi},
  alpha_l ~ CN(0, beta/((kappa+1) L)), beta = (r/r_ref)^(-eta) 10^(zeta/10).
"""
from __future__ import annotations

from dataclasses import dataclass

import numpy as np

from ..utils.config import SystemParams


def antenna_offsets(nt: int) -> np.ndarray:
    return np.arange(1, nt + 1) - (nt + 1) / 2


def distances(r, theta, nt: int, d: float) -> np.ndarray:
    dn = antenna_offsets(nt) * d
    r = np.asarray(r, float)[..., None]
    th = np.asarray(theta, float)[..., None]
    return np.sqrt(r**2 + dn**2 - 2.0 * r * dn * np.sin(th))


def nf_response(r, theta, nt: int, lam: float) -> np.ndarray:
    d = lam / 2
    rr = np.asarray(r, float)[..., None]
    dist = distances(r, theta, nt, d)
    return ((rr / dist) * np.exp(-1j * 2.0 * np.pi / lam * (dist - rr)) / np.sqrt(nt)).astype(np.complex128)


def ff_response(theta, nt: int, lam: float) -> np.ndarray:
    d = lam / 2
    th = np.asarray(theta, float)[..., None]
    return (np.exp(1j * 2.0 * np.pi / lam * antenna_offsets(nt) * d * np.sin(th)) / np.sqrt(nt)).astype(np.complex128)


def response(model: str, r, theta, nt: int, lam: float) -> np.ndarray:
    if model == "near_field":
        return nf_response(r, theta, nt, lam)
    if model == "far_field":
        out = ff_response(theta, nt, lam)
        return np.broadcast_to(out, np.broadcast(np.asarray(r)[..., None], out).shape).copy()
    raise ValueError(model)


def sample_positions(rng: np.random.Generator, shape, p: SystemParams):
    """Uniform in area over the sector region (default), or with the range uniform on [r_min, r_max]."""
    if p.r_dist == "area":
        r = np.sqrt(rng.uniform(p.r_min**2, p.r_max**2, size=shape))
    elif p.r_dist == "range":
        r = rng.uniform(p.r_min, p.r_max, size=shape)
    else:
        raise ValueError(p.r_dist)
    theta = rng.uniform(-p.theta_max, p.theta_max, size=shape)
    return r, theta


def in_region(r, theta, p: SystemParams) -> np.ndarray:
    return (r >= p.r_min) & (r <= p.r_max) & (np.abs(theta) <= p.theta_max)


def sample_scatterers(rng: np.random.Generator, r, theta, p: SystemParams, max_iter: int = 200):
    """L scatterers per user, uniform inside the region within distance r_sc of the user (rejection sampling)."""
    shape = np.shape(r) + (p.L,)
    x0 = np.broadcast_to((np.asarray(r) * np.cos(theta))[..., None], shape)
    y0 = np.broadcast_to((np.asarray(r) * np.sin(theta))[..., None], shape)
    rs = np.empty(shape)
    ts = np.empty(shape)
    todo = np.ones(shape, bool)
    for _ in range(max_iter):
        n = int(todo.sum())
        if n == 0:
            break
        rad = p.r_sc * np.sqrt(rng.uniform(size=n))
        ang = rng.uniform(0, 2 * np.pi, size=n)
        x = x0[todo] + rad * np.cos(ang)
        y = y0[todo] + rad * np.sin(ang)
        cand_r, cand_t = np.hypot(x, y), np.arctan2(y, x)
        ok = in_region(cand_r, cand_t, p)
        idx = np.flatnonzero(todo)
        rs.flat[idx[ok]] = cand_r[ok]
        ts.flat[idx[ok]] = cand_t[ok]
        todo.flat[idx[ok]] = False
    if todo.any():
        raise RuntimeError("scatterer rejection sampling did not converge")
    return rs, ts


@dataclass
class Geometry:
    r: np.ndarray          # (n, K) user ranges
    theta: np.ndarray      # (n, K) user angles
    r_sc: np.ndarray       # (n, K, L) scatterer ranges
    theta_sc: np.ndarray   # (n, K, L) scatterer angles
    shadow_db: np.ndarray  # (n, K)
    beta: np.ndarray       # (n, K) large-scale gain

    def xy(self) -> np.ndarray:
        return np.stack([self.r * np.cos(self.theta), self.r * np.sin(self.theta)], axis=-1)


def sample_geometry(rng: np.random.Generator, n: int, p: SystemParams, K: int | None = None) -> Geometry:
    K = p.K if K is None else K
    r, th = sample_positions(rng, (n, K), p)
    rs, ts = sample_scatterers(rng, r, th, p)
    zeta = p.shadow_std_db * rng.standard_normal((n, K))
    beta = (r / p.r_ref) ** (-p.eta) * 10.0 ** (zeta / 10.0)
    return Geometry(r=r, theta=th, r_sc=rs, theta_sc=ts, shadow_db=zeta, beta=beta)


def path_responses(geom: Geometry, p: SystemParams, model: str | None = None) -> np.ndarray:
    """(n, K, L+1, Nt) responses of the LoS path (index 0) and the scatterer paths."""
    model = p.model if model is None else model
    r = np.concatenate([geom.r[..., None], geom.r_sc], axis=-1)
    th = np.concatenate([geom.theta[..., None], geom.theta_sc], axis=-1)
    return response(model, r, th, p.Nt, p.lam)


def draw_channels(rng: np.random.Generator, geom: Geometry, responses: np.ndarray, p: SystemParams) -> np.ndarray:
    """One interval of small-scale fading: returns H with shape (n, K, Nt)."""
    n, K = geom.r.shape
    beta = geom.beta
    los = np.sqrt(p.kappa * beta / (p.kappa + 1.0)) * np.exp(1j * rng.uniform(0, 2 * np.pi, (n, K)))
    nlos_std = np.sqrt(beta / ((p.kappa + 1.0) * p.L))[..., None]
    nlos = nlos_std * (rng.standard_normal((n, K, p.L)) + 1j * rng.standard_normal((n, K, p.L))) / np.sqrt(2.0)
    alpha = np.concatenate([los[..., None], nlos], axis=-1)
    H = np.sqrt(p.Nt) * np.einsum("nkl,nklm->nkm", alpha, responses)
    if not np.all(np.isfinite(H)):
        raise FloatingPointError("non-finite channel coefficients")
    return H


def estimate_channels(rng: np.random.Generator, H: np.ndarray, sigma_est2: float) -> np.ndarray:
    """Least-squares estimate with white error CN(0, sigma_est2 I)."""
    if sigma_est2 < 0:
        raise ValueError("error variance must be non-negative")
    noise = (rng.standard_normal(H.shape) + 1j * rng.standard_normal(H.shape)) * np.sqrt(sigma_est2 / 2.0)
    return H + noise
