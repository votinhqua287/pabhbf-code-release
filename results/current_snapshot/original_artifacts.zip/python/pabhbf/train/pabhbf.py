"""PAB-HBF training (Tasks 9, 11 and 12).

Modes
  task         communication loss only; a monitoring adversary is trained on detached latents
  adversarial  fixed privacy weight lambda in the adversarial epochs
  dual         lambda <- [lambda + eta (Lambda_hat - epsilon)]_+ after every adversarial epoch, where Lambda_hat is the
               disc hit probability of the training adversary on validation drops
Schedule: epochs_pre epochs of the communication loss, adversary warm-up on frozen latents, then epochs_adv epochs of
alternating updates with attacker_steps adversary steps per encoder-controller step. The task mode trains for the same
total number of epochs.

  python -m pabhbf.train.pabhbf --mode adversarial --lam 1.0 --seed 1 --tag lam1
"""
from __future__ import annotations

import argparse
import json
import time
from collections import defaultdict

import numpy as np
import torch
import torch.nn.functional as F
from threadpoolctl import threadpool_limits

from ..attacks.models import MLPRegressor
from ..losses import privacy as priv
from ..losses.task import communication_loss
from ..models.controller import SetController
from ..models.encoder import CNNEncoder, MLPEncoder
from ..models.representations import csi_features
from ..phy import codebook as cbm
from ..utils.config import ROOT, load_config, system_params
from .common import encode_all, evaluate_controller, grad_norm, minibatches, run_metadata
from .data import angle_domain_features, load_task_data

CKPT_DIR = ROOT / "results" / "checkpoints" / "pabhbf"
LOG_DIR = ROOT / "results" / "raw" / "train_logs" / "pabhbf"


def parse_args(argv=None):
    ap = argparse.ArgumentParser()
    ap.add_argument("--config", nargs="*", default=[])
    ap.add_argument("--prefix", default="default")
    ap.add_argument("--mode", choices=["task", "adversarial", "dual"], default="adversarial")
    ap.add_argument("--lam", type=float, default=1.0, help="privacy weight (initial value in the dual mode)")
    ap.add_argument("--eps", type=float, default=0.1, help="leakage budget of the dual mode")
    ap.add_argument("--dual-lr", type=float, default=5.0)
    ap.add_argument("--d-z", type=int, default=None)
    ap.add_argument("--bits", default=None, help="bits per latent entry, or 'none' for a continuous latent")
    ap.add_argument("--arch", choices=["mlp", "cnn"], default="mlp")
    ap.add_argument("--kind", choices=["det", "vib"], default="det")
    ap.add_argument("--beta-kl", type=float, default=0.0)
    ap.add_argument("--noise-std", type=float, default=0.0)
    ap.add_argument("--input", choices=["beam", "antenna", "angle_domain"], default="beam",
                    help="encoder input: aligned beam-domain CSI (default), antenna-domain CSI, or DFT gains only")
    ap.add_argument("--privacy-loss", choices=["maxent", "reversal"], default="maxent")
    ap.add_argument("--epochs-pre", type=int, default=None, help="default: training.epochs_pretrain")
    ap.add_argument("--epochs-adv", type=int, default=None, help="default: training.epochs_adversarial")
    ap.add_argument("--warmup-epochs", type=int, default=2)
    ap.add_argument("--attacker-steps", type=int, default=None)
    ap.add_argument("--adv-cell", type=float, default=None, help="default: privacy.adversary_cell_m")
    ap.add_argument("--adv-lr", type=float, default=1e-3)
    ap.add_argument("--lr", type=float, default=None)
    ap.add_argument("--batch", type=int, default=None)
    ap.add_argument("--width", type=int, default=128)
    ap.add_argument("--layers", type=int, default=3)
    ap.add_argument("--w-sched", type=float, default=1.0)
    ap.add_argument("--w-group", type=float, default=1.0)
    ap.add_argument("--w-power", type=float, default=0.1)
    ap.add_argument("--w-rate", type=float, default=1.0)
    ap.add_argument("--seed", type=int, default=1)
    ap.add_argument("--tag", default=None)
    ap.add_argument("--threads", type=int, default=8)
    ap.add_argument("--val-drops", type=int, default=1000)
    ap.add_argument("--init-ckpt", default=None,
                    help="checkpoint (path or glob, newest match) whose encoder, controller and adversary initialize this run")
    ap.add_argument("--pretrain-only", action="store_true",
                    help="run only the pretraining epochs and save the checkpoint (shared start of the lambda sweep)")
    return ap.parse_args(argv)


def resolve_checkpoint(pattern: str) -> str:
    import glob

    paths = sorted(glob.glob(pattern) or glob.glob(str(ROOT / pattern)))
    if not paths:
        raise FileNotFoundError(pattern)
    return paths[-1]


def build_encoder(enc_cfg: dict, nt: int) -> torch.nn.Module:
    if enc_cfg["arch"] == "mlp":
        return MLPEncoder(enc_cfg["in_dim"], enc_cfg["d_z"], enc_cfg["bits"], kind=enc_cfg["kind"], noise_std=enc_cfg["noise_std"])
    if enc_cfg["input"] not in ("beam", "antenna"):
        raise ValueError("the CNN encoder needs CSI input")
    return CNNEncoder(nt, enc_cfg["d_z"], enc_cfg["bits"], kind=enc_cfg["kind"], noise_std=enc_cfg["noise_std"])


def warm_up_adversary(enc, adv, opt_a, X, cells, epochs, rng, batch):
    Z = encode_all(enc, X).reshape(-1, enc.d_z)
    c = cells.reshape(-1)
    adv.train()
    for _ in range(epochs):
        for j in minibatches(len(Z), batch, rng):
            opt_a.zero_grad()
            priv.adversary_loss(adv(Z[j]), c[j]).backward()
            opt_a.step()


@torch.no_grad()
def latent_stats(Z: torch.Tensor, bits) -> dict:
    Zf = Z.reshape(-1, Z.shape[-1])
    sd = Zf.std(0)
    out = dict(latent_std_mean=float(sd.mean()), latent_std_min=float(sd.min()))
    if bits:
        out["levels_used_frac"] = float(np.mean([len(torch.unique(Zf[:, j])) for j in range(Zf.shape[1])]) / 2**bits)
    return out


def train(args) -> dict:
    torch.set_num_threads(args.threads)
    blas_limit = threadpool_limits(limits=args.threads)  # noqa: F841  (NumPy BLAS threads, kept for the whole run)
    torch.manual_seed(args.seed)
    cfg = load_config(*args.config)
    p = system_params(cfg)
    cb = cbm.polar_codebook(p)
    rc = cfg["representation"]
    d_z = args.d_z or rc["latent_dim"]
    bits = rc["bits_per_entry"] if args.bits is None else (None if args.bits == "none" else int(args.bits))
    Ta = cfg["privacy"]["attacker_steps_per_update"] if args.attacker_steps is None else args.attacker_steps
    lr = args.lr or cfg["training"]["learning_rate"]
    B = args.batch or cfg["training"]["batch_size"]
    rho = cfg["privacy"]["tolerance_radius_m"]
    if args.epochs_pre is None:
        args.epochs_pre = cfg["training"]["epochs_pretrain"]
    if args.epochs_adv is None:
        args.epochs_adv = cfg["training"]["epochs_adversarial"]
    if args.adv_cell is None:
        args.adv_cell = cfg["privacy"].get("adversary_cell_m", 1.0)
    tag = args.tag or args.mode
    stamp = time.strftime("%Y%m%d-%H%M%S")

    t_load = time.time()
    tr = load_task_data(f"{args.prefix}_train", p, cb)
    va = load_task_data(f"{args.prefix}_val", p, cb)
    print(f"[{tag} s{args.seed}] data loaded in {time.time() - t_load:.0f} s", flush=True)
    input_stats = None
    if args.input == "angle_domain":
        tr.X, input_stats = angle_domain_features(tr.Hhat, p)
        va.X, _ = angle_domain_features(va.Hhat, p, input_stats)
    elif args.input == "antenna":
        for data in (tr, va):
            data.X = torch.as_tensor(csi_features(data.Hhat, p, "antenna").reshape(data.n, p.K, -1))
    K, in_dim = p.K, tr.X.shape[-1]
    grid = priv.make_grid(tr.xy, args.adv_cell, rho, p.r_max, p.theta_max)
    cell_tr = torch.as_tensor(grid.index(tr.xy).reshape(tr.n, K))
    val_idx = np.arange(min(args.val_drops, va.n))
    cell_va = torch.as_tensor(grid.index(va.xy[val_idx]))
    xy_va = va.xy[val_idx].reshape(-1, 2)
    log_prior = torch.log(torch.as_tensor(grid.prior, dtype=torch.float32))

    enc_cfg = dict(arch=args.arch, d_z=d_z, bits=bits, kind=args.kind, noise_std=args.noise_std, in_dim=in_dim, input=args.input)
    enc = build_encoder(enc_cfg, p.Nt)
    ctrl_cfg = dict(d_in=d_z, G=p.G, width=args.width, layers=args.layers)
    ctrl = SetController(**ctrl_cfg)
    adv = MLPRegressor(d_z, grid.C, hidden=(256, 256))
    init_path = None
    if args.init_ckpt:
        init_path = resolve_checkpoint(args.init_ckpt)
        init = torch.load(init_path, weights_only=False)
        if init["encoder_cfg"] != enc_cfg or init["controller_cfg"] != ctrl_cfg or init["adversary_cell"] != args.adv_cell:
            raise ValueError(f"{init_path} does not match the architecture of this run")
        enc.load_state_dict(init["encoder"])
        ctrl.load_state_dict(init["controller"])
        adv.load_state_dict(init["adversary"])
        print(f"[{tag} s{args.seed}] initialized from {init_path}", flush=True)
    if args.pretrain_only:
        args.epochs_adv = 0
    params = list(enc.parameters()) + list(ctrl.parameters())
    opt = torch.optim.AdamW(params, lr=lr, weight_decay=1e-5)
    opt_a = torch.optim.Adam(adv.parameters(), lr=args.adv_lr)
    weights = dict(sched=args.w_sched, group=args.w_group, power=args.w_power, rate=args.w_rate)
    lam = 0.0 if args.mode == "task" else args.lam
    rng = np.random.default_rng(args.seed)
    E = args.epochs_pre + args.epochs_adv
    history, t_start = [], time.time()
    for ep in range(E):
        adv_phase = args.mode != "task" and ep >= args.epochs_pre
        if adv_phase and ep == args.epochs_pre and args.warmup_epochs > 0:
            warm_up_adversary(enc, adv, opt_a, tr.X, cell_tr, args.warmup_epochs, rng, B * K)
        enc.train()
        ctrl.train()
        adv.train()
        acc, steps, t0 = defaultdict(float), 0, time.time()
        for idx in minibatches(tr.n, B, rng):
            b = tr.batch(idx)
            nb = len(idx)
            Z, kl = enc(b["X"].reshape(-1, in_dim))
            out = ctrl(Z.view(nb, K, d_z), b["w"], b["snr_db"])
            l_comm, parts = communication_loss(out, b, weights)
            cells = cell_tr[idx].reshape(-1)
            zd = Z.detach()
            for _ in range(Ta):
                opt_a.zero_grad()
                la = priv.adversary_loss(adv(zd), cells)
                la.backward()
                opt_a.step()
            loss = l_comm + args.beta_kl * kl.mean()
            if adv_phase and lam > 0:
                lp = priv.privacy_loss(adv(Z), cells, log_prior, args.privacy_loss)
                loss = loss + lam * lp
                acc["privacy_loss"] += float(lp.detach())
            opt.zero_grad()
            loss.backward()
            acc["grad_norm_encoder"] += grad_norm(enc)
            torch.nn.utils.clip_grad_norm_(params, 5.0)
            opt.step()
            acc["loss"] += float(loss.detach())
            acc["adversary_ce"] += float(la.detach())
            acc["kl"] += float(kl.mean().detach())
            for k, v in parts.items():
                acc[k] += v
            steps += 1
        Zva = encode_all(enc, va.X[val_idx])
        adv.eval()
        with torch.no_grad():
            logits = adv(Zva.reshape(-1, d_z)).double()
            ce = float(F.cross_entropy(logits, cell_va))
            probs = torch.softmax(logits, 1).numpy()
        hit = float(np.mean(np.linalg.norm(priv.disc_map(probs, grid) - xy_va, axis=1) <= rho))
        util, _ = evaluate_controller(ctrl, Zva, va, cb, p, val_idx)
        rec = dict(epoch=ep + 1, phase="adversarial" if adv_phase else "pretrain", lam=lam,
                   train={k: v / steps for k, v in acc.items()},
                   val=dict(**util, adv_hit=hit, adv_ce=ce, adv_mi_bits=max(0.0, (grid.entropy_nats - ce) / np.log(2.0)),
                            **latent_stats(Zva, bits)),
                   epoch_s=time.time() - t0)
        if args.mode == "dual" and adv_phase:
            lam = max(0.0, lam + args.dual_lr * (hit - args.eps))
            rec["lam_next"] = lam
        history.append(rec)
        print(f"[{tag} s{args.seed}] ep {ep + 1}/{E} {rec['phase']} lam {rec['lam']:.3g} ratio {util['ratio']:.4f} "
              f"overlap {util['sched_overlap']:.3f} group {util['group_acc']:.3f} adv_hit {hit:.3f} "
              f"mi {rec['val']['adv_mi_bits']:.2f} bits ({rec['epoch_s']:.0f} s)", flush=True)

    CKPT_DIR.mkdir(parents=True, exist_ok=True)
    LOG_DIR.mkdir(parents=True, exist_ok=True)
    ckpt_path = CKPT_DIR / f"{tag}_s{args.seed}_{stamp}.pt"
    torch.save(dict(kind="pabhbf", tag=tag, seed=args.seed, args=vars(args), encoder_cfg=enc_cfg, encoder=enc.state_dict(),
                    controller_cfg=ctrl_cfg, controller=ctrl.state_dict(), adversary=adv.state_dict(),
                    adversary_cell=args.adv_cell, input_stats=input_stats, lam_final=lam, config=cfg,
                    payload_bits=d_z * (bits or 32), init_checkpoint=init_path, meta=run_metadata()), ckpt_path)
    log = dict(tag=tag, seed=args.seed, args=vars(args), history=history, train_s=time.time() - t_start,
               checkpoint=str(ckpt_path), init_checkpoint=init_path, meta=run_metadata())
    (LOG_DIR / f"{tag}_s{args.seed}_{stamp}.json").write_text(json.dumps(log, indent=1))
    print("saved", ckpt_path, flush=True)
    return log


if __name__ == "__main__":
    train(parse_args())
