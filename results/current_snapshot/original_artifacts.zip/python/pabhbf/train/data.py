"""Tensors for controller training and evaluation (Tasks 9-12)."""
from __future__ import annotations

from dataclasses import dataclass

import numpy as np
import torch

from ..data.dataset import load_split
from ..losses.task import wsr_from_shares
from ..models.representations import csi_features
from ..phy import codebook as cbm
from ..phy import hbf
from ..phy.codebook import Codebook
from ..utils.config import SystemParams


def angle_domain_features(Hhat: np.ndarray, p: SystemParams, stats=None):
    """Encoder input for the range-feature ablation: standardized log10 gains of the far-field (DFT) beams, (n, K, A).

    stats = (mean, std) fitted on the training split and reused for every other split.
    """
    cb = cbm.dft_codebook(p, bits=None)
    n, K, nt = Hhat.shape
    g = np.log10(np.abs(Hhat.reshape(-1, nt) @ cb.W.conj().T) ** 2 + 1e-6).astype(np.float32)
    if stats is None:
        stats = (g.mean(0), g.std(0) + 1e-6)
    return torch.as_tensor(((g - stats[0]) / stats[1]).reshape(n, K, -1)), stats


@dataclass
class TaskData:
    name: str
    n: int
    X: torch.Tensor      # (n, K, 2Nt) scaled real CSI features (interval 0)
    w: torch.Tensor      # (n, K)
    snr_db: torch.Tensor  # (n,)
    xy: np.ndarray       # (n, K, 2)
    Hhat: np.ndarray     # (n, K, Nt) complex64 as stored
    H: np.ndarray | None  # (n, K, Nt) complex64, or None when only the estimates are needed
    teacher: dict | None

    def batch(self, idx) -> dict:
        b = dict(X=self.X[idx], w=self.w[idx], snr_db=self.snr_db[idx])
        if self.teacher is not None:
            b.update({k: v[idx] for k, v in self.teacher.items()})
        return b


def load_task_data(name: str, p: SystemParams, cb: Codebook, teacher: bool = True, far_field: bool = False,
                   with_true: bool = True, chunk: int = 1000) -> TaskData:
    hkey, Hkey = ("Hhat_ff", "H_ff") if far_field else ("Hhat", "H")
    keys = {hkey, "w", "snr_db", "xy"} | ({Hkey} if (with_true or teacher) else set())
    if teacher:
        keys |= {"teacher_sched", "teacher_groups_all", "teacher_shares", "teacher_wsr_true"}
    d = load_split(name, keys)
    # kept in the stored single precision to halve the memory; every numerical tool promotes its chunk to double
    Hh = np.ascontiguousarray(d[hkey][:, 0])
    H = np.ascontiguousarray(d[Hkey][:, 0]) if Hkey in d else None
    if Hh.shape[-1] != p.Nt:
        raise ValueError(f"{name} has Nt = {Hh.shape[-1]}, the configuration has Nt = {p.Nt}")
    n, K, nt = Hh.shape
    out = TaskData(name=name, n=n, X=torch.as_tensor(csi_features(Hh, p).reshape(n, K, 2 * nt)),
                   w=torch.as_tensor(d["w"], dtype=torch.float32), snr_db=torch.as_tensor(d["snr_db"], dtype=torch.float32),
                   xy=d["xy"], Hhat=Hh, H=H, teacher=None)
    if not (teacher and "teacher_sched" in d) or far_field:
        return out
    sched, groups_all, shares = d["teacher_sched"], d["teacher_groups_all"], d["teacher_shares"]
    groups_S = hbf.gather_users(groups_all, sched)
    snr = 10.0 ** (d["snr_db"] / 10.0)
    A = np.empty((n, p.Ns, p.Ns))
    for c0 in range(0, n, chunk):
        sl = slice(c0, min(n, c0 + chunk))
        Hh_c, H_c = Hh[sl].astype(np.complex128), H[sl].astype(np.complex128)
        _, FRF, Fbar = hbf.build_precoders(Hh_c, sched[sl], groups_S[sl], shares[sl], cb, snr[sl])
        A[sl] = hbf.coupling_matrix(hbf.gather_users(H_c, sched[sl]), FRF, Fbar)
    w_S = hbf.gather_users(d["w"], sched)
    check = wsr_from_shares(torch.as_tensor(A), torch.as_tensor(shares), torch.as_tensor(w_S), torch.as_tensor(1.0 / snr)).numpy()
    dev = float(np.max(np.abs(check - d["teacher_wsr_true"]) / d["teacher_wsr_true"]))
    if dev > 1e-6:
        raise AssertionError(f"{name}: coupling-matrix rate deviates from the stored teacher rate by {dev:.2e}")
    label = np.zeros((n, K), np.float32)
    np.put_along_axis(label, sched, 1.0, axis=1)
    out.teacher = dict(
        sched_label=torch.as_tensor(label), groups_all=torch.as_tensor(groups_all, dtype=torch.long),
        sched=torch.as_tensor(sched, dtype=torch.long), shares=torch.as_tensor(shares, dtype=torch.float32),
        A=torch.as_tensor(A, dtype=torch.float32), w_S=torch.as_tensor(w_S, dtype=torch.float32),
        sigma2=torch.as_tensor(1.0 / snr, dtype=torch.float32),
        wsr_teacher=torch.as_tensor(d["teacher_wsr_true"], dtype=torch.float32))
    return out
