"""Shared helpers for controller training and evaluation (Tasks 9-14)."""
from __future__ import annotations

import platform
import subprocess

import numpy as np
import torch

from ..losses.task import action_metrics
from ..models.controller import decode_actions
from ..phy import hbf
from ..utils.config import ROOT


def run_metadata() -> dict:
    try:
        proc = subprocess.run(["git", "rev-parse", "--verify", "--quiet", "HEAD"], capture_output=True, text=True, cwd=ROOT, timeout=10)
        commit = proc.stdout.strip() if proc.returncode == 0 else ""
    except Exception:  # git missing
        commit = ""
    return dict(python=platform.python_version(), numpy=np.__version__, torch=torch.__version__,
                git_commit=commit or "no commit")


def minibatches(n: int, batch: int, rng: np.random.Generator):
    perm = rng.permutation(n)
    for i in range(0, n, batch):
        yield torch.as_tensor(perm[i:i + batch])


def grad_norm(module: torch.nn.Module) -> float:
    return float(sum(float(prm.grad.detach().pow(2).sum()) for prm in module.parameters() if prm.grad is not None) ** 0.5)


@torch.no_grad()
def encode_all(enc: torch.nn.Module, X: torch.Tensor, batch: int = 512) -> torch.Tensor:
    """X (n, K, D) -> Z (n, K, d_z) with the encoder in evaluation mode (a VIB encoder still samples)."""
    enc.eval()
    n, K, D = X.shape
    return torch.cat([enc(X[i:i + batch].reshape(-1, D))[0].view(-1, K, enc.d_z) for i in range(0, n, batch)])


@torch.no_grad()
def controller_actions(ctrl, Z: torch.Tensor, w: torch.Tensor, snr_db: torch.Tensor, Ns: int, batch: int = 1024):
    ctrl.eval()
    S, G, P = [], [], []
    for i in range(0, Z.shape[0], batch):
        s, g, q = decode_actions(*ctrl(Z[i:i + batch], w[i:i + batch], snr_db[i:i + batch]), Ns)
        S.append(s)
        G.append(g)
        P.append(q)
    shares = torch.cat(P).double().numpy()
    return torch.cat(S).numpy(), torch.cat(G).numpy(), shares / shares.sum(1, keepdims=True)


def realized_wsr(H, Hhat, w, sched, groups, shares, cb, snr_db, chunk: int = 2000):
    """Weighted sum rate and sum rate of actions executed by the trusted tools, evaluated with the true channels."""
    n = len(sched)
    snr_db = np.broadcast_to(np.asarray(snr_db, float), (n,))
    wsr, sr = np.empty(n), np.empty(n)
    for c0 in range(0, n, chunk):
        sl = slice(c0, min(n, c0 + chunk))
        rates = hbf.apply_tools(H[sl].astype(np.complex128), Hhat[sl].astype(np.complex128), sched[sl], groups[sl],
                                shares[sl], cb, 10.0 ** (snr_db[sl] / 10.0))
        wsr[sl] = np.sum(hbf.gather_users(w[sl], sched[sl]) * rates, axis=1)
        sr[sl] = rates.sum(1)
    return wsr, sr


def evaluate_controller(ctrl, Z_idx: torch.Tensor, data, cb, p, idx: np.ndarray, snr_db: float | None = None):
    """Decoded actions on drops idx (Z_idx aligned with idx) at the stored SNR, or at a fixed reference SNR."""
    snr = data.snr_db[idx] if snr_db is None else torch.full((len(idx),), float(snr_db))
    w = data.w[idx]
    sched, groups, shares = controller_actions(ctrl, Z_idx, w, snr, p.Ns)
    wsr, sr = realized_wsr(data.H[idx], data.Hhat[idx], w.numpy().astype(float), sched, groups, shares, cb, snr.numpy())
    res = dict(wsr=float(wsr.mean()), sum_rate=float(sr.mean()))
    if data.teacher is not None and snr_db is None:
        t = data.teacher
        res["teacher_wsr"] = float(t["wsr_teacher"][idx].mean())
        res["ratio"] = res["wsr"] / res["teacher_wsr"]
        res.update(action_metrics(torch.as_tensor(sched), torch.as_tensor(groups), t["sched"][idx], t["groups_all"][idx]))
    return res, wsr
