"""Controllers on fixed representations: baselines B1-B9 (Tasks 7 and 8).

  python -m pabhbf.train.baselines --rep pca --seed 1
  python -m pabhbf.train.baselines --rep gaussian_pca --sigma 0.3 --seed 1 --tag gaussian_pca_0.3
  python -m pabhbf.train.baselines --rep autoencoder --seed 1

The controller architecture, losses, optimizer and epochs match PAB-HBF. Stochastic representations draw fresh noise in
every epoch.
"""
from __future__ import annotations

import argparse
import json
import time

import numpy as np
import torch
from threadpoolctl import threadpool_limits

from ..losses.task import communication_loss
from ..models.autoencoder import AERepresentation
from ..models.controller import SetController
from ..models.representations import make_representation
from ..phy import codebook as cbm
from ..utils.config import ROOT, load_config, system_params
from .common import evaluate_controller, minibatches, run_metadata
from .data import load_task_data

CKPT_DIR = ROOT / "results" / "checkpoints" / "baselines"
LOG_DIR = ROOT / "results" / "raw" / "train_logs" / "baselines"


def parse_args(argv=None):
    ap = argparse.ArgumentParser()
    ap.add_argument("--config", nargs="*", default=[])
    ap.add_argument("--prefix", default="default")
    ap.add_argument("--rep", required=True, choices=["raw_csi", "pca", "random_projection", "scalar_quant", "gaussian_pca",
                                                     "top_m_beams", "angle_domain", "laplace_pca", "autoencoder"])
    ap.add_argument("--sigma", type=float, default=None)
    ap.add_argument("--epsilon", type=float, default=None)
    ap.add_argument("--d-z", type=int, default=None)
    ap.add_argument("--bits", default=None)
    ap.add_argument("--epochs", type=int, default=None, help="default: epochs_pretrain + epochs_adversarial")
    ap.add_argument("--ae-epochs", type=int, default=40)
    ap.add_argument("--lr", type=float, default=None)
    ap.add_argument("--batch", type=int, default=None)
    ap.add_argument("--width", type=int, default=128)
    ap.add_argument("--layers", type=int, default=3)
    ap.add_argument("--w-power", type=float, default=0.1)
    ap.add_argument("--w-rate", type=float, default=1.0)
    ap.add_argument("--seed", type=int, default=1)
    ap.add_argument("--tag", default=None)
    ap.add_argument("--threads", type=int, default=8)
    ap.add_argument("--val-drops", type=int, default=1000)
    return ap.parse_args(argv)


def train(args) -> dict:
    torch.set_num_threads(args.threads)
    blas_limit = threadpool_limits(limits=args.threads)  # noqa: F841  (NumPy BLAS threads, kept for the whole run)
    torch.manual_seed(args.seed)
    cfg = load_config(*args.config)
    p = system_params(cfg)
    cb = cbm.polar_codebook(p)
    rc = cfg["representation"]
    d_z = args.d_z or rc["latent_dim"]
    bits = rc["bits_per_entry"] if args.bits is None else (None if args.bits == "none" else int(args.bits))
    lr = args.lr or cfg["training"]["learning_rate"]
    B = args.batch or cfg["training"]["batch_size"]
    if args.epochs is None:
        args.epochs = cfg["training"]["epochs_pretrain"] + cfg["training"]["epochs_adversarial"]
    tag = args.tag or args.rep
    stamp = time.strftime("%Y%m%d-%H%M%S")
    t_load = time.time()
    tr = load_task_data(f"{args.prefix}_train", p, cb)
    va = load_task_data(f"{args.prefix}_val", p, cb)
    print(f"[{tag} s{args.seed}] data loaded in {time.time() - t_load:.0f} s", flush=True)
    val_idx = np.arange(min(args.val_drops, va.n))

    t0 = time.time()
    fit_rng = np.random.default_rng(1000 + args.seed)
    if args.rep == "autoencoder":
        rep = AERepresentation(d_z, bits, epochs=args.ae_epochs, seed=args.seed).fit(tr.Hhat, p, fit_rng, Hhat_val=va.Hhat)
    else:
        kw = dict(d=d_z, bits=bits)
        if args.sigma is not None:
            kw["sigma"] = args.sigma
        if args.epsilon is not None:
            kw["epsilon"] = args.epsilon
        rep = make_representation(args.rep, cfg, **kw).fit(tr.Hhat, p, fit_rng)
    fit_s = time.time() - t0
    noise_rng = np.random.default_rng(2000 + args.seed)

    def features(H):
        return torch.as_tensor(rep.transform(H, noise_rng).reshape(H.shape[0], p.K, -1))

    Ztr, Zva = features(tr.Hhat), features(va.Hhat[val_idx])
    ctrl_cfg = dict(d_in=rep.dim, G=p.G, width=args.width, layers=args.layers)
    ctrl = SetController(**ctrl_cfg)
    flat = Ztr.reshape(-1, rep.dim)
    ctrl.set_input_stats(flat.mean(0), flat.std(0))
    opt = torch.optim.AdamW(ctrl.parameters(), lr=lr, weight_decay=1e-5)
    weights = dict(sched=1.0, group=1.0, power=args.w_power, rate=args.w_rate)
    rng = np.random.default_rng(args.seed)
    history = []
    for ep in range(args.epochs):
        if rep.stochastic and ep > 0:
            Ztr = features(tr.Hhat)
        ctrl.train()
        t1, total, steps = time.time(), 0.0, 0
        for idx in minibatches(tr.n, B, rng):
            b = tr.batch(idx)
            loss, _ = communication_loss(ctrl(Ztr[idx], b["w"], b["snr_db"]), b, weights)
            opt.zero_grad()
            loss.backward()
            torch.nn.utils.clip_grad_norm_(ctrl.parameters(), 5.0)
            opt.step()
            total += float(loss.detach())
            steps += 1
        util, _ = evaluate_controller(ctrl, Zva, va, cb, p, val_idx)
        history.append(dict(epoch=ep + 1, loss=total / steps, val=util, epoch_s=time.time() - t1))
        print(f"[{tag} s{args.seed}] ep {ep + 1}/{args.epochs} loss {total / steps:.4f} ratio {util['ratio']:.4f} "
              f"overlap {util['sched_overlap']:.3f} group {util['group_acc']:.3f} ({time.time() - t1:.0f} s)", flush=True)
    CKPT_DIR.mkdir(parents=True, exist_ok=True)
    LOG_DIR.mkdir(parents=True, exist_ok=True)
    ckpt_path = CKPT_DIR / f"{tag}_s{args.seed}_{stamp}.pt"
    torch.save(dict(kind="baseline", tag=tag, seed=args.seed, rep_name=args.rep, rep=rep, controller_cfg=ctrl_cfg,
                    controller=ctrl.state_dict(), payload_bits=int(rep.estimated_bits()), config=cfg, args=vars(args),
                    meta=run_metadata()), ckpt_path)
    log = dict(tag=tag, seed=args.seed, args=vars(args), fit_s=fit_s, payload_bits=int(rep.estimated_bits()),
               rep_log=getattr(rep, "log", None), history=history, checkpoint=str(ckpt_path), meta=run_metadata())
    (LOG_DIR / f"{tag}_s{args.seed}_{stamp}.json").write_text(json.dumps(log, indent=1))
    print("saved", ckpt_path, flush=True)
    return log


if __name__ == "__main__":
    train(parse_args())
