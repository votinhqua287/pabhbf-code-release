"""Privacy encoders f_phi of PAB-HBF (Task 9).

Per-user MLP or 1-D CNN over the antenna axis, a bounded latent (tanh), an optional Gaussian sampling layer (variational
information bottleneck, kind="vib"), optional additive noise, and a b_z-bit uniform quantizer with a straight-through
gradient. The encoder runs at the base station on the raw estimate; only the quantized latent leaves it.
"""
from __future__ import annotations

import torch
import torch.nn as nn

from .quantizer import quantize_ste


def mlp(dims, act=nn.GELU) -> nn.Sequential:
    layers = []
    for a, b in zip(dims[:-1], dims[1:]):
        layers += [nn.Linear(a, b), act()]
    return nn.Sequential(*layers)


class Bottleneck(nn.Module):
    def __init__(self, feat_dim: int, d_z: int, bits: int | None, kind: str = "det", noise_std: float = 0.0):
        super().__init__()
        if kind not in ("det", "vib"):
            raise ValueError(kind)
        self.kind, self.bits, self.noise_std, self.d_z = kind, bits, noise_std, d_z
        self.mu = nn.Linear(feat_dim, d_z)
        self.logvar = nn.Linear(feat_dim, d_z) if kind == "vib" else None

    def forward(self, h):
        mu = self.mu(h)
        if self.kind == "vib":
            logvar = self.logvar(h).clamp(-10.0, 4.0)
            pre = mu + torch.exp(0.5 * logvar) * torch.randn_like(mu)
            kl = 0.5 * (mu**2 + logvar.exp() - logvar - 1.0).sum(-1)
        else:
            pre, kl = mu, torch.zeros(mu.shape[0], device=mu.device)
        z = torch.tanh(pre)
        if self.noise_std > 0:
            z = z + self.noise_std * torch.randn_like(z)
        return quantize_ste(z, self.bits), kl


class MLPEncoder(nn.Module):
    def __init__(self, in_dim: int, d_z: int, bits: int | None = 4, hidden=(256, 256), kind: str = "det",
                 noise_std: float = 0.0):
        super().__init__()
        self.body = mlp((in_dim,) + tuple(hidden))
        self.head = Bottleneck(hidden[-1], d_z, bits, kind, noise_std)
        self.d_z, self.bits = d_z, bits

    def forward(self, x):
        return self.head(self.body(x))


class CNNEncoder(nn.Module):
    """1-D convolutions over the antenna index with [Re, Im] channels."""

    def __init__(self, nt: int, d_z: int, bits: int | None = 4, channels=(32, 64, 64), kind: str = "det",
                 noise_std: float = 0.0):
        super().__init__()
        layers, c_in, length = [], 2, nt
        for i, c in enumerate(channels):
            k = 7 if i == 0 else 5
            layers += [nn.Conv1d(c_in, c, k, stride=2, padding=k // 2), nn.GELU()]
            c_in, length = c, (length + 2 * (k // 2) - k) // 2 + 1
        self.conv = nn.Sequential(*layers)
        self.fc = nn.Sequential(nn.Flatten(), nn.Linear(c_in * length, 256), nn.GELU())
        self.head = Bottleneck(256, d_z, bits, kind, noise_std)
        self.nt, self.d_z, self.bits = nt, d_z, bits

    def forward(self, x):
        return self.head(self.fc(self.conv(x.view(-1, 2, self.nt))))


def make_encoder(arch: str, nt: int, d_z: int, bits, kind="det", noise_std=0.0) -> nn.Module:
    if arch == "mlp":
        return MLPEncoder(2 * nt, d_z, bits, kind=kind, noise_std=noise_std)
    if arch == "cnn":
        return CNNEncoder(nt, d_z, bits, kind=kind, noise_std=noise_std)
    raise ValueError(arch)
