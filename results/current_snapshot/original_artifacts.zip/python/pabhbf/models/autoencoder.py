"""B7: reconstructive autoencoder (Task 8).

The encoder is the PAB-HBF MLP encoder with the same latent size and quantizer, so the only difference from PAB-HBF is
the training objective: per-sample normalized reconstruction error of the scaled CSI.
"""
from __future__ import annotations

import copy

import numpy as np
import torch
import torch.nn as nn

from .encoder import MLPEncoder, mlp
from .representations import Representation, csi_features


class Autoencoder(nn.Module):
    def __init__(self, in_dim: int, d_z: int, bits: int | None = 4, hidden=(256, 256)):
        super().__init__()
        self.encoder = MLPEncoder(in_dim, d_z, bits, hidden, "det")
        self.decoder = nn.Sequential(mlp((d_z,) + tuple(reversed(hidden))), nn.Linear(hidden[0], in_dim))

    def forward(self, x):
        z, _ = self.encoder(x)
        return z, self.decoder(z)


def nmse(x: torch.Tensor, xhat: torch.Tensor) -> torch.Tensor:
    return ((x - xhat) ** 2).sum(-1) / (x**2).sum(-1).clamp_min(1e-12)


def train_autoencoder(Xtr: np.ndarray, Xva: np.ndarray, d_z: int, bits, epochs: int = 40, lr: float = 1e-3,
                      batch: int = 1024, seed: int = 0, patience: int = 6):
    torch.manual_seed(seed)
    rng = np.random.default_rng(seed)
    model = Autoencoder(Xtr.shape[1], d_z, bits)
    opt = torch.optim.AdamW(model.parameters(), lr=lr, weight_decay=1e-5)
    sched = torch.optim.lr_scheduler.CosineAnnealingLR(opt, T_max=epochs)
    Xtr_t, Xva_t = torch.as_tensor(Xtr), torch.as_tensor(Xva)
    best, best_state, bad, hist = np.inf, None, 0, []
    for _ in range(epochs):
        model.train()
        perm = torch.as_tensor(rng.permutation(len(Xtr_t)))
        for i in range(0, len(perm), batch):
            xb = Xtr_t[perm[i:i + batch]]
            opt.zero_grad()
            nmse(xb, model(xb)[1]).mean().backward()
            opt.step()
        sched.step()
        model.eval()
        with torch.no_grad():
            va = float(torch.cat([nmse(Xva_t[i:i + 8192], model(Xva_t[i:i + 8192])[1]) for i in range(0, len(Xva_t), 8192)]).mean())
        hist.append(va)
        if va < best - 1e-7:
            best, best_state, bad = va, copy.deepcopy(model.state_dict()), 0
        else:
            bad += 1
            if bad >= patience:
                break
    model.load_state_dict(best_state)
    return model, dict(val_nmse=hist, best_val_nmse_db=float(10 * np.log10(best)), epochs_run=len(hist))


class AERepresentation(Representation):
    name = "autoencoder"

    def __init__(self, d: int = 32, bits: int | None = 4, epochs: int = 40, seed: int = 0):
        self.d, self.bits, self.epochs, self.seed, self.dim = d, bits, epochs, seed, d

    def fit(self, Hhat_train, p, rng, Hhat_val=None):
        self.p = p
        Xtr = csi_features(Hhat_train, p)
        Xva = csi_features(Hhat_val, p) if Hhat_val is not None else Xtr[: len(Xtr) // 10]
        self.model, self.log = train_autoencoder(Xtr, Xva, self.d, self.bits, self.epochs, seed=self.seed)
        return self

    @torch.no_grad()
    def transform(self, Hhat, rng=None):
        self.model.eval()
        X = torch.as_tensor(csi_features(Hhat, self.p))
        return torch.cat([self.model.encoder(X[i:i + 16384])[0] for i in range(0, len(X), 16384)]).numpy()

    def estimated_bits(self):
        return self.d * (self.bits if self.bits else 32)
