"""Wireless controller pi_omega (Task 9).

A permutation-equivariant transformer over the K user tokens (no positional encoding). Token k carries the received
representation z_k, log2 of the priority weight w_k and the reference SNR in units of 10 dB. Heads give a scheduling
score, beam-group logits and a power logit per user. Decoding takes the Ns largest scores, the arg-max group and a
softmax of the power logits over the scheduled users, so every decoded action is feasible by construction.
"""
from __future__ import annotations

import torch
import torch.nn as nn


class SetController(nn.Module):
    def __init__(self, d_in: int, G: int, width: int = 128, layers: int = 3, heads: int = 4):
        super().__init__()
        self.register_buffer("z_mean", torch.zeros(d_in))
        self.register_buffer("z_std", torch.ones(d_in))
        self.inp = nn.Sequential(nn.Linear(d_in + 2, width), nn.GELU(), nn.Linear(width, width))
        layer = nn.TransformerEncoderLayer(width, heads, 2 * width, dropout=0.0, activation="gelu", batch_first=True,
                                           norm_first=True)
        self.tf = nn.TransformerEncoder(layer, layers, enable_nested_tensor=False)
        self.norm = nn.LayerNorm(width)
        self.sched_head = nn.Linear(width, 1)
        self.group_head = nn.Linear(width, G)
        self.power_head = nn.Linear(width, 1)
        self.G = G

    def set_input_stats(self, mean, std):
        self.z_mean.copy_(torch.as_tensor(mean, dtype=torch.float32))
        self.z_std.copy_(torch.as_tensor(std, dtype=torch.float32).clamp_min(1e-6))

    def forward(self, Z, w, snr_db):
        B, K, _ = Z.shape
        ctx = torch.stack([torch.log2(w), (snr_db / 10.0)[:, None].expand(B, K)], dim=-1)
        h = self.inp(torch.cat([(Z - self.z_mean) / self.z_std, ctx], dim=-1))
        h = self.norm(self.tf(h))
        return self.sched_head(h).squeeze(-1), self.group_head(h), self.power_head(h).squeeze(-1)


@torch.no_grad()
def decode_actions(sched_logits, group_logits, power_logits, Ns: int):
    sched = torch.topk(sched_logits, Ns, dim=1).indices.sort(dim=1).values
    groups = torch.gather(group_logits, 1, sched[..., None].expand(-1, -1, group_logits.shape[-1])).argmax(-1)
    shares = torch.softmax(torch.gather(power_logits, 1, sched), dim=1)
    return sched, groups, shares
