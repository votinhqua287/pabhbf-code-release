"""Non-learned CSI representations for the baselines (Task 7).

Every representation maps per-user estimates h_hat (N, Nt) to real vectors z (N, d) and reports its payload:

    rep = make_representation("pca", cfg).fit(Hhat_train, p, rng)
    z = rep.transform(Hhat, rng)
    bits = rep.estimated_bits()

B1 raw CSI, B2 PCA, B3 random projection, B4 scalar quantization of the CSI entries, B5 PCA with Gaussian noise,
B6 top-M polar-codebook indices with quantized gains, B8 far-field (DFT) beam-domain magnitudes, B9 Laplace mechanism
on clipped PCA coefficients. B7 (autoencoder) lives in models/autoencoder.py. All fits use training data only.
"""
from __future__ import annotations

import math

import numpy as np

from ..phy import codebook as cbm
from ..utils.config import SystemParams
from .quantizer import quantize_np

FIT_ROWS = 100_000


def csi_scale(p: SystemParams) -> float:
    """1/sqrt(beta(r_min)) without shadowing (docs/SYSTEM_MODEL.md)."""
    return float(np.sqrt((p.r_min / p.r_ref) ** p.eta))


def dft_basis(nt: int) -> np.ndarray:
    """Unitary matrix whose columns are the far-field responses at u_m = (2m - Nt + 1)/Nt (half-wavelength ULA)."""
    u = (2 * np.arange(nt) - nt + 1) / nt
    n = np.arange(1, nt + 1) - (nt + 1) / 2
    return np.exp(1j * np.pi * n[:, None] * u[None, :]) / np.sqrt(nt)


def csi_features(Hhat: np.ndarray, p: SystemParams, domain: str = "beam", chunk: int = 65536) -> np.ndarray:
    """Real-valued CSI input of the encoders and of B1-B5 and B9, scaled by 1/sqrt(beta(r_min)).

    beam (default): beam-domain coefficients x = U^H h_hat with the unitary DFT basis U, rotated so that the strongest
    coefficient is real and positive, then [Re x; Im x]. The rotation removes the common phase, which is uniform and
    independent of the location, so the map keeps all location and rate information.
    antenna: [Re h_hat; Im h_hat].
    """
    x = Hhat.reshape(-1, Hhat.shape[-1])
    nt = x.shape[1]
    out = np.empty((len(x), 2 * nt), np.float32)
    U = dft_basis(nt).conj() if domain == "beam" else None
    if domain not in ("beam", "antenna"):
        raise ValueError(domain)
    for c0 in range(0, len(x), chunk):
        v = x[c0:c0 + chunk].astype(np.complex128)
        if U is not None:
            v = v @ U
            peak = v[np.arange(len(v)), np.argmax(np.abs(v), axis=1)]
            v = v * (np.conj(peak) / np.maximum(np.abs(peak), 1e-300))[:, None]
        out[c0:c0 + chunk] = np.concatenate([v.real, v.imag], axis=1) * csi_scale(p)
    return out


def _rows(n: int, rng: np.random.Generator) -> np.ndarray:
    return rng.choice(n, size=min(n, FIT_ROWS), replace=False)


class Representation:
    name = "base"
    stochastic = False
    dim = 0

    def fit(self, Hhat_train: np.ndarray, p: SystemParams, rng: np.random.Generator):
        self.p = p
        return self

    def transform(self, Hhat: np.ndarray, rng: np.random.Generator | None = None) -> np.ndarray:
        raise NotImplementedError

    def estimated_bits(self) -> int:
        raise NotImplementedError


class RawCSI(Representation):
    """B1: the scaled real-valued estimate, sent with raw_bits per real entry."""
    name = "raw_csi"

    def __init__(self, raw_bits: int = 16):
        self.raw_bits = raw_bits

    def fit(self, Hhat_train, p, rng):
        self.p, self.dim = p, 2 * p.Nt
        return self

    def transform(self, Hhat, rng=None):
        return csi_features(Hhat, self.p)

    def estimated_bits(self):
        return 2 * self.p.Nt * self.raw_bits


class PCA(Representation):
    """B2: projection on the d leading principal directions of the training CSI, scaled to about [-1, 1], quantized."""
    name = "pca"

    def __init__(self, d: int = 32, bits: int | None = 4):
        self.d, self.bits, self.dim = d, bits, d

    def _features(self, Hhat):
        return csi_features(Hhat, self.p)

    def _basis(self, Xc, rng):
        return np.linalg.svd(Xc, full_matrices=False)[2][: self.d].T

    def fit(self, Hhat_train, p, rng):
        self.p = p
        X = self._features(Hhat_train)
        X = X[_rows(len(X), rng)].astype(np.float64)
        self.mu = X.mean(axis=0)
        self.V = self._basis(X - self.mu, rng)
        self.c = 3.0 * ((X - self.mu) @ self.V).std(axis=0) + 1e-9
        return self

    def project(self, Hhat):
        return (((self._features(Hhat) - self.mu) @ self.V) / self.c).astype(np.float32)

    def transform(self, Hhat, rng=None):
        return quantize_np(self.project(Hhat), self.bits)

    def estimated_bits(self):
        return self.d * (self.bits if self.bits else 32)


class RandomProjection(PCA):
    """B3: fixed random orthonormal projection (drawn from the fit generator), scaled and quantized."""
    name = "random_projection"

    def _basis(self, Xc, rng):
        return np.linalg.qr(rng.standard_normal((Xc.shape[1], self.d)))[0]


class ScalarQuantCSI(Representation):
    """B4: uniform scalar quantization of the entries of the beam-domain input x_k at the same payload.

    With b = max(1, floor(B/(2Nt))) bits per real entry and as many evenly spaced coefficients as the payload allows,
    each sent as its real and imaginary part (64 of the 256 coefficients with 1 bit per real entry for B = 128).
    """
    name = "scalar_quant"

    def __init__(self, budget_bits: int = 128):
        self.budget = budget_bits

    def fit(self, Hhat_train, p, rng):
        self.p = p
        self.b = max(1, self.budget // (2 * p.Nt))
        n_ant = min(p.Nt, self.budget // (2 * self.b))
        ant = np.unique(np.round(np.linspace(0, p.Nt - 1, n_ant)).astype(int))
        self.cols = np.concatenate([ant, ant + p.Nt])
        X = csi_features(Hhat_train, p)[:, self.cols]
        self.c = 3.0 * X[_rows(len(X), rng)].std(axis=0) + 1e-9
        self.dim = len(self.cols)
        return self

    def transform(self, Hhat, rng=None):
        return quantize_np(csi_features(Hhat, self.p)[:, self.cols] / self.c, self.b)

    def estimated_bits(self):
        return self.dim * self.b


class GaussianPCA(PCA):
    """B5: scaled PCA coefficients plus N(0, sigma^2) noise, then quantized."""
    name = "gaussian_pca"
    stochastic = True

    def __init__(self, d=32, bits=4, sigma=0.2):
        super().__init__(d, bits)
        self.sigma = sigma

    def transform(self, Hhat, rng=None):
        y = self.project(Hhat)
        return quantize_np(y + self.sigma * rng.standard_normal(y.shape), self.bits)


class LaplacePCA(PCA):
    """B9: Laplace mechanism on PCA coefficients clipped to [-1, 1].

    The L1 sensitivity of the clipped vector is 2d, so noise Laplace(2d/epsilon) makes each released vector
    epsilon-locally differentially private per user and interval. Quantization is post-processing. The guarantee does
    not compose over intervals and says nothing about the utility.
    """
    name = "laplace_pca"
    stochastic = True

    def __init__(self, d=32, bits=4, epsilon=10.0):
        super().__init__(d, bits)
        self.epsilon = epsilon

    def transform(self, Hhat, rng=None):
        y = np.clip(self.project(Hhat), -1.0, 1.0)
        return quantize_np(y + rng.laplace(0.0, 2.0 * self.d / self.epsilon, y.shape), self.bits)


class TopMBeams(Representation):
    """B6: indices of the m strongest polar-codebook codewords with their quantized gains.

    Payload m (ceil(log2 M) + gain_bits) <= B. The controller receives the public codebook coordinates (u, tau) of each
    index, which encode the index losslessly, and the quantized gain in dB.
    """
    name = "top_m_beams"

    def __init__(self, budget_bits=128, gain_bits=4):
        self.budget, self.gain_bits = budget_bits, gain_bits

    def _gains_db(self, Hhat, chunk: int = 8192):
        x = Hhat.reshape(-1, Hhat.shape[-1])
        Wc = self.cb.W.conj().T
        out = np.empty((len(x), Wc.shape[1]))
        for c0 in range(0, len(x), chunk):  # (N, M) with M = 3566 at Nt = 256 would not fit at once
            out[c0:c0 + chunk] = 10.0 * np.log10(np.abs(x[c0:c0 + chunk].astype(np.complex128) @ Wc) ** 2 + 1e-12)
        return out

    def fit(self, Hhat_train, p, rng):
        self.p = p
        self.cb = cbm.polar_codebook(p)
        self.idx_bits = math.ceil(math.log2(self.cb.M))
        self.m = self.budget // (self.idx_bits + self.gain_bits)
        if self.m < 1:
            raise ValueError("payload too small for one codeword index")
        x = Hhat_train.reshape(-1, p.Nt)
        top = -np.sort(-self._gains_db(x[_rows(len(x), rng)]), axis=1)[:, : self.m]
        self.lo, self.hi = float(np.percentile(top[:, -1], 0.5)), float(np.percentile(top[:, 0], 99.5))
        self.u_max, self.tau_max = float(np.abs(self.cb.u).max()), float(max(self.cb.tau.max(), 1e-12))
        self.dim = 3 * self.m
        return self

    def transform(self, Hhat, rng=None):
        g = self._gains_db(Hhat)
        top = np.argpartition(-g, self.m - 1, axis=1)[:, : self.m]
        top = np.take_along_axis(top, np.argsort(-np.take_along_axis(g, top, 1), axis=1), 1)
        gq = quantize_np(2.0 * (np.take_along_axis(g, top, 1) - self.lo) / (self.hi - self.lo) - 1.0, self.gain_bits)
        u = self.cb.u[top] / self.u_max
        tau = 2.0 * self.cb.tau[top] / self.tau_max - 1.0
        return np.stack([u, tau, gq], axis=2).reshape(len(g), -1).astype(np.float32)

    def estimated_bits(self):
        return self.m * (self.idx_bits + self.gain_bits)


class AngleDomain(PCA):
    """B8: far-field (DFT) beam-domain gains in dB, compressed by PCA and quantized.

    The plane-wave codebook has no range dimension, so the representation drops the explicit range sampling of the
    polar codebook (the beam spread of near users and the path gain still depend on range).
    """
    name = "angle_domain"

    def fit(self, Hhat_train, p, rng):
        self.cb_ff = cbm.dft_codebook(p, bits=None)
        self.p = p
        return super().fit(Hhat_train, p, rng)

    def _features(self, Hhat, chunk: int = 32768):
        x = Hhat.reshape(-1, Hhat.shape[-1])
        Wc = self.cb_ff.W.conj().T
        out = np.empty((len(x), Wc.shape[1]), np.float32)
        for c0 in range(0, len(x), chunk):
            out[c0:c0 + chunk] = np.log10(np.abs(x[c0:c0 + chunk].astype(np.complex128) @ Wc) ** 2 + 1e-6)
        return out


def make_representation(name: str, cfg: dict, **kw) -> Representation:
    rc = cfg["representation"]
    d = kw.get("d", rc["latent_dim"])
    bits = kw["bits"] if "bits" in kw else rc["bits_per_entry"]
    budget = kw.get("budget_bits", d * (bits or 32))
    if name == "raw_csi":
        return RawCSI(rc["raw_csi_bits_per_entry"])
    if name == "pca":
        return PCA(d, bits)
    if name == "random_projection":
        return RandomProjection(d, bits)
    if name == "scalar_quant":
        return ScalarQuantCSI(budget)
    if name == "gaussian_pca":
        return GaussianPCA(d, bits, kw["sigma"])
    if name == "top_m_beams":
        return TopMBeams(budget, kw.get("gain_bits", bits))
    if name == "angle_domain":
        return AngleDomain(d, bits)
    if name == "laplace_pca":
        return LaplacePCA(d, bits, kw["epsilon"])
    raise ValueError(f"unknown representation {name}")
