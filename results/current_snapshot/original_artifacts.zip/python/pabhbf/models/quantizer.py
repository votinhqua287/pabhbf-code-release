"""Uniform scalar quantization of bounded representations (Tasks 7-9).

The mid-rise quantizer has 2^bits levels lo + (i + 1/2) step on [lo, hi]. Values outside [lo, hi] map to the end levels,
which is part of the mechanism (the payload is exactly bits per entry). The torch version passes the gradient straight
through.
"""
from __future__ import annotations

import numpy as np
import torch


def quantize_np(x: np.ndarray, bits: int | None, lo: float = -1.0, hi: float = 1.0) -> np.ndarray:
    if bits is None:
        return np.asarray(x, np.float32)
    levels = 2**bits
    step = (hi - lo) / levels
    idx = np.clip(np.floor((x - lo) / step), 0, levels - 1)
    return (lo + (idx + 0.5) * step).astype(np.float32)


def quantize_ste(x: torch.Tensor, bits: int | None, lo: float = -1.0, hi: float = 1.0) -> torch.Tensor:
    if bits is None:
        return x
    levels = 2**bits
    step = (hi - lo) / levels
    idx = torch.clamp(torch.floor((x - lo) / step), 0, levels - 1)
    return x + (lo + (idx + 0.5) * step - x).detach()
