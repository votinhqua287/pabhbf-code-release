"""Attack models and location metrics shared by the premise study, the baselines and the privacy evaluation."""
from __future__ import annotations

import copy
import time

import numpy as np
import torch
import torch.nn as nn


class MLPRegressor(nn.Module):
    def __init__(self, in_dim: int, out_dim: int, hidden=(512, 512, 256), dropout: float = 0.0):
        super().__init__()
        layers, d = [], in_dim
        for h in hidden:
            layers += [nn.Linear(d, h), nn.GELU()]
            if dropout:
                layers.append(nn.Dropout(dropout))
            d = h
        layers.append(nn.Linear(d, out_dim))
        self.net = nn.Sequential(*layers)

    def forward(self, x):
        return self.net(x)


class ResidualMLPRegressor(nn.Module):
    """Stronger attacker used only for evaluation (mismatched architecture)."""

    def __init__(self, in_dim: int, out_dim: int, width: int = 768, blocks: int = 4):
        super().__init__()
        self.inp = nn.Linear(in_dim, width)
        self.blocks = nn.ModuleList([nn.Sequential(nn.LayerNorm(width), nn.Linear(width, 2 * width), nn.GELU(),
                                                   nn.Linear(2 * width, width)) for _ in range(blocks)])
        self.out = nn.Sequential(nn.LayerNorm(width), nn.Linear(width, out_dim))

    def forward(self, x):
        h = self.inp(x)
        for b in self.blocks:
            h = h + b(h)
        return self.out(h)


def predict(model: nn.Module, X: np.ndarray, batch: int = 8192) -> np.ndarray:
    model.eval()
    out = []
    with torch.no_grad():
        for i in range(0, len(X), batch):
            out.append(model(torch.as_tensor(X[i:i + batch], dtype=torch.float32)).numpy())
    return np.concatenate(out)


def train_regressor(model: nn.Module, Xtr, Ytr, Xva, Yva, epochs: int = 40, lr: float = 1e-3, batch: int = 1024,
                    weight_decay: float = 1e-4, patience: int = 6, seed: int = 0, loss: str = "mse", verbose: bool = False):
    """Adam(W) training with a cosine schedule and early stopping on the validation loss. Returns the best model."""
    torch.manual_seed(seed)
    rng = np.random.default_rng(seed)
    ydtype = torch.long if loss == "ce" else torch.float32
    Xtr_t, Ytr_t = torch.as_tensor(Xtr, dtype=torch.float32), torch.as_tensor(Ytr, dtype=ydtype)
    Xva_t, Yva_t = torch.as_tensor(Xva, dtype=torch.float32), torch.as_tensor(Yva, dtype=ydtype)
    opt = torch.optim.AdamW(model.parameters(), lr=lr, weight_decay=weight_decay)
    sched = torch.optim.lr_scheduler.CosineAnnealingLR(opt, T_max=epochs)
    crit = {"mse": nn.MSELoss(), "huber": nn.SmoothL1Loss(beta=0.05), "ce": nn.CrossEntropyLoss()}[loss]
    best, best_state, bad, hist = np.inf, None, 0, []
    for ep in range(epochs):
        model.train()
        perm = torch.as_tensor(rng.permutation(len(Xtr)))
        t0 = time.time()
        for i in range(0, len(perm), batch):
            idx = perm[i:i + batch]
            opt.zero_grad()
            l = crit(model(Xtr_t[idx]), Ytr_t[idx])
            l.backward()
            opt.step()
        sched.step()
        model.eval()
        with torch.no_grad():
            va = float(np.mean([crit(model(Xva_t[i:i + 8192]), Yva_t[i:i + 8192]).item() for i in range(0, len(Xva_t), 8192)]))
        hist.append(va)
        if verbose:
            print(f"    epoch {ep + 1}: val {va:.5f} ({time.time() - t0:.1f} s)", flush=True)
        if va < best - 1e-6:
            best, best_state, bad = va, copy.deepcopy(model.state_dict()), 0
        else:
            bad += 1
            if bad >= patience:
                break
    model.load_state_dict(best_state)
    return model, dict(val_history=hist, best_val=best, epochs_run=len(hist))


def location_metrics(xy_true: np.ndarray, xy_pred: np.ndarray, rho: float = 1.0, r_bins=None) -> dict:
    err = np.linalg.norm(xy_true - xy_pred, axis=1)
    r_t, th_t = np.hypot(*xy_true.T), np.arctan2(xy_true[:, 1], xy_true[:, 0])
    r_p, th_p = np.hypot(*xy_pred.T), np.arctan2(xy_pred[:, 1], xy_pred[:, 0])
    r2 = 1.0 - np.sum(err**2) / np.sum((xy_true - xy_true.mean(0)) ** 2)
    out = dict(rmse_m=float(np.sqrt(np.mean(err**2))), hit_prob=float(np.mean(err <= rho)), r2=float(r2),
               median_err_m=float(np.median(err)), range_mae_m=float(np.mean(np.abs(r_t - r_p))),
               angle_mae_deg=float(np.rad2deg(np.mean(np.abs(th_t - th_p)))))
    if r_bins is not None:
        idx = np.digitize(r_t, r_bins) - 1
        out["bins"] = dict(edges=list(map(float, r_bins)),
                           rmse_m=[float(np.sqrt(np.mean(err[idx == b] ** 2))) if np.any(idx == b) else float("nan") for b in range(len(r_bins) - 1)],
                           hit_prob=[float(np.mean(err[idx == b] <= rho)) if np.any(idx == b) else float("nan") for b in range(len(r_bins) - 1)],
                           range_mae_m=[float(np.mean(np.abs(r_t - r_p)[idx == b])) if np.any(idx == b) else float("nan") for b in range(len(r_bins) - 1)])
    return out
