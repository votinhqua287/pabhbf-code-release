"""Task 6 addendum: model-based MLE attacker with learned fusion on raw CSI, and a line-of-sight check against the CRB.

  python -m pabhbf.attacks.premise_mle --prefix default --los-prefix los
"""
from __future__ import annotations

import argparse
import ast
import json
import time

import numpy as np
import torch

from ..data.dataset import load_split
from ..utils.config import ROOT, load_config, system_params
from .crb import location_crb
from .mle import direct_estimate, mle_features
from .models import MLPRegressor, location_metrics, predict, train_regressor


def main():
    ap = argparse.ArgumentParser()
    ap.add_argument("--prefix", default="default")
    ap.add_argument("--los-prefix", default="los")
    ap.add_argument("--fit-rows", type=int, default=60000)
    ap.add_argument("--threads", type=int, default=8)
    ap.add_argument("--override", default="{}", help="JSON dictionary merged into the configuration (for example the array size)")
    args = ap.parse_args()
    torch.set_num_threads(args.threads)
    cfg = load_config(overrides=json.loads(args.override))
    p = system_params(cfg)
    rho = cfg["privacy"]["tolerance_radius_m"]
    bins = np.linspace(p.r_min, p.r_max, 9)
    rng = np.random.default_rng(0)
    res = dict(rho=rho, runs=[], los_check=None)
    tr, te = load_split(f"{args.prefix}_train"), load_split(f"{args.prefix}_test")
    xy_tr, xy_te = tr["xy"].reshape(-1, 2), te["xy"].reshape(-1, 2)
    rows = rng.choice(len(xy_tr), args.fit_rows, replace=False)
    n_va = args.fit_rows // 10
    for model_name, key in (("near_field", "Hhat"), ("far_field", "Hhat_ff")):
        t0 = time.time()
        Ftr = mle_features(tr[key][:, 0].reshape(-1, p.Nt)[rows], p)
        Fte = mle_features(te[key][:, 0].reshape(-1, p.Nt), p)
        t_feat = time.time() - t0
        res["runs"].append(dict(model=model_name, attacker="mle_direct", feature_s=t_feat, **location_metrics(xy_te, direct_estimate(Fte, p), rho, bins)))
        print(model_name, "mle_direct", res["runs"][-1]["rmse_m"], res["runs"][-1]["hit_prob"], f"{t_feat:.0f} s", flush=True)
        mu, sd = Ftr.mean(0), Ftr.std(0) + 1e-9
        Str, Ste = ((Ftr - mu) / sd).astype(np.float32), ((Fte - mu) / sd).astype(np.float32)
        y = xy_tr[rows] / p.r_max
        net, hist = train_regressor(MLPRegressor(4, 2, hidden=(256, 256)), Str[n_va:], y[n_va:], Str[:n_va], y[:n_va], epochs=60, batch=512, patience=8)
        res["runs"].append(dict(model=model_name, attacker="mle_fusion", epochs_run=hist["epochs_run"],
                                **location_metrics(xy_te, predict(net, Ste) * p.r_max, rho, bins)))
        print(model_name, "mle_fusion", res["runs"][-1]["rmse_m"], res["runs"][-1]["hit_prob"], flush=True)
    if args.los_prefix == "none":
        out = ROOT / "results" / "raw" / "premise" / f"premise_mle_{args.prefix}_{time.strftime('%Y%m%d-%H%M%S')}.json"
        out.parent.mkdir(parents=True, exist_ok=True)
        out.write_text(json.dumps(res, indent=1))
        print("saved", out)
        return
    los = load_split(f"{args.los_prefix}_test")
    Hl, xy_l, r_l, th_l, beta_l = los["Hhat"][:, 0].reshape(-1, p.Nt), los["xy"].reshape(-1, 2), los["r"].ravel(), los["theta"].ravel(), los["beta"].ravel()
    kappa_los = 10 ** (float(ast.literal_eval(str(los["meta"]))["config"]["channel"]["rician_k_db"]) / 10)
    F = mle_features(Hl, p)
    est = direct_estimate(F, p)
    err2 = np.sum((est - xy_l) ** 2, axis=1)
    bound2 = np.empty(len(r_l))
    for i in range(len(r_l)):
        snr_los = kappa_los / (kappa_los + 1.0) * beta_l[i] / p.sigma_est2
        bound2[i] = np.trace(location_crb("near_field", r_l[i], th_l[i], p.Nt, p.lam, snr_los, False, p.eta, 0.0)[1])
    idx = np.digitize(r_l, bins) - 1
    res["los_check"] = dict(kappa_db=10 * np.log10(kappa_los), bins=bins.tolist(),
                            mle_rmse_m=[float(np.sqrt(err2[idx == b].mean())) for b in range(len(bins) - 1)],
                            crb_rmse_m=[float(np.sqrt(bound2[idx == b].mean())) for b in range(len(bins) - 1)],
                            mle_hit=[float(np.mean(err2[idx == b] <= rho**2)) for b in range(len(bins) - 1)])
    print("LoS check", json.dumps(res["los_check"], indent=1), flush=True)
    out = ROOT / "results" / "raw" / "premise" / f"premise_mle_{args.prefix}_{time.strftime('%Y%m%d-%H%M%S')}.json"
    out.parent.mkdir(parents=True, exist_ok=True)
    out.write_text(json.dumps(res, indent=1))
    print("saved", out)


if __name__ == "__main__":
    main()
