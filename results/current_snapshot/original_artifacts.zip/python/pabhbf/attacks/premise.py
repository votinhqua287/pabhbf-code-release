"""Task 6 (gate G1): location leakage of raw near-field CSI versus far-field CSI, large-scale gain only, and the prior.

  python -m pabhbf.attacks.premise --prefix default

Attackers:
- MLP (512-512-256), trained on each input variant
- kNN (k = 10) and a random forest (200 trees) on a 60k-sample training subset
Inputs:
- iq: [Re, Im] of the estimate
- magphase: norm- and phase-normalized estimate (removes the channel gain)
- gain: log channel gain only
Models: near-field CSI and the far-field twin (same geometry, gains and estimation noise).
"""
from __future__ import annotations

import argparse
import json
import time

import numpy as np
import torch
from sklearn.ensemble import RandomForestRegressor
from sklearn.neighbors import KNeighborsRegressor

from ..data.dataset import load_split
from ..models.representations import csi_features
from ..utils.config import ROOT, load_config, system_params
from ..utils.units import c2r
from .models import MLPRegressor, location_metrics, predict, train_regressor

OUT = ROOT / "results" / "raw" / "premise"


def features(Hhat: np.ndarray, variant: str, scale: float, p=None) -> np.ndarray:
    if variant == "beam":
        return csi_features(Hhat, p, "beam")
    x = Hhat.reshape(-1, Hhat.shape[-1]).astype(np.complex128)
    if variant == "iq":
        f = c2r(x) * scale
    elif variant == "magphase":
        x = x / np.linalg.norm(x, axis=1, keepdims=True)
        x = x * np.exp(-1j * np.angle(x[:, x.shape[1] // 2]))[:, None]
        f = c2r(x) * np.sqrt(x.shape[1])
    elif variant == "gain":
        f = np.log10(np.sum(np.abs(x) ** 2, axis=1, keepdims=True))
    else:
        raise ValueError(variant)
    return f.astype(np.float32)


def main():
    ap = argparse.ArgumentParser()
    ap.add_argument("--prefix", default="default")
    ap.add_argument("--config", nargs="*", default=[])
    ap.add_argument("--epochs", type=int, default=40)
    ap.add_argument("--seed", type=int, default=0)
    ap.add_argument("--threads", type=int, default=16)
    ap.add_argument("--skip-forest", action="store_true")
    ap.add_argument("--variants", nargs="+", default=["iq", "magphase", "gain", "beam"])
    ap.add_argument("--override", default="{}", help="JSON dictionary merged into the configuration")
    args = ap.parse_args()
    torch.set_num_threads(args.threads)
    cfg = load_config(*args.config, overrides=json.loads(args.override))
    p = system_params(cfg)
    rho = cfg["privacy"]["tolerance_radius_m"]
    scale = float(np.sqrt((p.r_min / p.r_ref) ** p.eta))  # 1/sqrt(beta(r_min)) without shadowing
    tr, va, te = (load_split(f"{args.prefix}_{s}") for s in ("train", "val", "test"))
    ytr, yva, yte = (d["xy"].reshape(-1, 2) for d in (tr, va, te))
    bins = np.linspace(p.r_min, p.r_max, 9)
    # config is the configuration of this process; the array size of the attacked data is recorded separately, because the
    # features depend only on the stored estimates and a prefix may hold another array size than the default configuration
    results = dict(config=cfg, data_Nt=int(tr["Hhat"].shape[-1]), rho=rho, lambda0_disc=float(np.pi * rho**2 / p.area), runs=[])
    prior = np.tile(ytr.mean(0), (len(yte), 1))
    results["runs"].append(dict(model="none", variant="prior_mean", attacker="constant", **location_metrics(yte, prior, rho, bins)))
    rng = np.random.default_rng(args.seed)
    sub = rng.choice(len(ytr), size=min(60000, len(ytr)), replace=False)
    for model_name, key in (("near_field", "Hhat"), ("far_field", "Hhat_ff")):
        for variant in args.variants:
            if variant == "gain" and model_name == "far_field":
                continue  # the gain is identical for both models
            Xtr, Xva, Xte = (features(d[key][:, 0], variant, scale, p) for d in (tr, va, te))
            t0 = time.time()
            mlp = MLPRegressor(Xtr.shape[1], 2)
            mlp, hist = train_regressor(mlp, Xtr, ytr / p.r_max, Xva, yva / p.r_max, epochs=args.epochs, seed=args.seed)
            pred = predict(mlp, Xte) * p.r_max
            results["runs"].append(dict(model=model_name, variant=variant, attacker="mlp", train_s=time.time() - t0,
                                        epochs_run=hist["epochs_run"], **location_metrics(yte, pred, rho, bins)))
            print(model_name, variant, "mlp", results["runs"][-1]["rmse_m"], results["runs"][-1]["hit_prob"], flush=True)
            t0 = time.time()
            knn = KNeighborsRegressor(n_neighbors=10, weights="distance", n_jobs=-1).fit(Xtr[sub], ytr[sub])
            pred = knn.predict(Xte)
            results["runs"].append(dict(model=model_name, variant=variant, attacker="knn", train_s=time.time() - t0,
                                        **location_metrics(yte, pred, rho, bins)))
            print(model_name, variant, "knn", results["runs"][-1]["rmse_m"], results["runs"][-1]["hit_prob"], flush=True)
            if not args.skip_forest:
                t0 = time.time()
                rf = RandomForestRegressor(n_estimators=200, min_samples_leaf=2, n_jobs=-1, random_state=args.seed).fit(Xtr[sub], ytr[sub])
                pred = rf.predict(Xte)
                results["runs"].append(dict(model=model_name, variant=variant, attacker="forest", train_s=time.time() - t0,
                                            **location_metrics(yte, pred, rho, bins)))
                print(model_name, variant, "forest", results["runs"][-1]["rmse_m"], results["runs"][-1]["hit_prob"], flush=True)
    OUT.mkdir(parents=True, exist_ok=True)
    stamp = time.strftime("%Y%m%d-%H%M%S")
    path = OUT / f"premise_{args.prefix}_{stamp}.json"
    path.write_text(json.dumps(results, indent=1))
    print("saved", path)


if __name__ == "__main__":
    main()
