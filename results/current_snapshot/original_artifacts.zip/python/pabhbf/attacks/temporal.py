"""Temporal attacker A4: pooling the representations of one user over T intervals of a block (Task 10).

  python -m pabhbf.attacks.temporal --ckpt "results/checkpoints/pabhbf/<tag>_s1_*.pt" --prefix defaultT4 --T 1 2 4

The splits {prefix}_attack, {prefix}_val and {prefix}_test hold T_max intervals per block (same location, scatterers
and shadowing, independent small-scale fading and estimation errors). The frozen encoder maps every interval, the
attacker receives the mean of the first T representations of each user, and the attacker suite runs on the pooled
vectors.
"""
from __future__ import annotations

import argparse
import json
import time

import numpy as np
import torch

from ..data.dataset import load_split
from ..train.common import run_metadata
from ..utils.config import ROOT, system_params
from .suite import run_suite
from ..eval.evaluate import Method, resolve


def pooled(method: Method, Hhat: np.ndarray, T: int, rng) -> np.ndarray:
    n, _, K, _ = Hhat.shape
    Z = [method.represent(Hhat[:, t].astype(np.complex128), rng).numpy() for t in range(T)]
    return np.mean(Z, axis=0).reshape(n * K, -1)


def main(argv=None):
    ap = argparse.ArgumentParser()
    ap.add_argument("--ckpt", required=True)
    ap.add_argument("--prefix", required=True)
    ap.add_argument("--T", type=int, nargs="+", default=[1, 2, 4])
    ap.add_argument("--attackers", nargs="+", default=["mlp_xy", "grid"])
    ap.add_argument("--epochs-att", type=int, default=40)
    ap.add_argument("--threads", type=int, default=12)
    ap.add_argument("--exp", default="e_temporal")
    args = ap.parse_args(argv)
    from threadpoolctl import threadpool_limits

    torch.set_num_threads(args.threads)
    blas_limit = threadpool_limits(limits=args.threads)  # noqa: F841  (kept alive for the whole run)
    path = resolve(args.ckpt)
    ckpt = torch.load(path, weights_only=False)
    cfg = ckpt["config"]
    p = system_params(cfg)
    method = Method(ckpt, p)
    rng = np.random.default_rng(0)
    splits = {s: load_split(f"{args.prefix}_{s}", {"Hhat", "xy"}) for s in ("attack", "val", "test")}
    out = dict(checkpoint=path, prefix=args.prefix, results={})
    for T in args.T:
        Z = {s: pooled(method, d["Hhat"], T, rng) for s, d in splits.items()}
        xy = {s: d["xy"] for s, d in splits.items()}
        res = run_suite(Z, xy, p, cfg, attackers=tuple(args.attackers), seed=0, epochs=args.epochs_att, n_jobs=args.threads)
        out["results"][str(T)] = res
        print(f"T={T}: leakage {res['summary']['leakage']:.3f} ({res['summary']['leakage_attacker']}), rmse {res['summary']['rmse_min_m']:.2f} m", flush=True)
    out["meta"] = run_metadata()
    out_dir = ROOT / "results" / "raw" / args.exp
    out_dir.mkdir(parents=True, exist_ok=True)
    (out_dir / f"{ckpt['tag']}_s{ckpt['seed']}_{time.strftime('%Y%m%d-%H%M%S')}.json").write_text(json.dumps(out, indent=1))
    return out


if __name__ == "__main__":
    main()
