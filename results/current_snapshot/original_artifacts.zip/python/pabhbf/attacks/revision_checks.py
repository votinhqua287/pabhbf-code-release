"""Numbers for statements revised after the internal review of the manuscript.

  python -m pabhbf.attacks.revision_checks   -> results/aggregated/revision_checks.json

1. Range bounds at r = 20 m for theta in {0, 30, 45, 60} deg and Nt in {32, 64, 128, 256}: the Cramer-Rao bound of the
   phase profile alone and the hybrid bound that adds the Fisher information of the received power.
2. Hexagonal disc covers: discs of radius rho' covering the (rho - rho')-neighborhood of the region, for the robust
   converse of Proposition 2 (rho = 1 m, rho' = 0.5 m), and discs of radius 1 m covering the region itself.
3. Hit probabilities within 0.5 m and 1 m of the direct MLE attacker on raw near-field CSI (Nt = 256 premise test split).
4. Range error of the direct MLE estimate on multipath channels without estimation error at r = 10 m and theta = 0,
   for Nt = 64 and Nt = 256, with a line-of-sight-only control.
"""
from __future__ import annotations

import json
import time

import numpy as np

from ..data import channel as ch
from ..data.dataset import load_split
from ..utils.config import ROOT, load_config, system_params
from .crb import location_crb
from .mle import mle_features


def range_bounds():
    rows = []
    for nt in (32, 64, 128, 256):
        p = system_params(load_config(overrides={"Nt": nt}))
        r = 20.0
        snr = p.kappa / (p.kappa + 1.0) * (r / p.r_ref) ** (-p.eta) / p.sigma_est2
        for deg in (0.0, 30.0, 45.0, 60.0):
            th = np.deg2rad(deg)
            phase = location_crb("near_field", r, th, nt, p.lam, snr, False, p.eta, 0.0)[0]
            hybrid = location_crb("near_field", r, th, nt, p.lam, snr, True, p.eta, p.shadow_std_db)[0]
            rows.append(dict(Nt=nt, r_m=r, theta_deg=deg, std_r_phase_m=float(np.sqrt(phase[0, 0])),
                             std_r_hybrid_m=float(np.sqrt(hybrid[0, 0]))))
    return rows


def distance_to_region(xy, p):
    r, th = np.hypot(xy[:, 0], xy[:, 1]), np.arctan2(xy[:, 1], xy[:, 0])
    inside_angle = np.abs(th) <= p.theta_max
    d_radial = np.maximum(np.maximum(p.r_min - r, r - p.r_max), 0.0)
    out = np.where(inside_angle, d_radial, np.inf)
    for sign in (1.0, -1.0):  # distance to the two straight edges of the sector
        u = np.array([np.cos(sign * p.theta_max), np.sin(sign * p.theta_max)])
        t = np.clip(xy @ u, p.r_min, p.r_max)
        out = np.minimum(out, np.linalg.norm(xy - t[:, None] * u[None, :], axis=1))
    return out


def hexagonal_cover(p, disc_radius, neighborhood, rng, trials=3000):
    """Discs of radius rho' centered on a triangular lattice of side sqrt(3) rho' cover the plane, so the discs whose centers
    lie within neighborhood + rho' of the region cover its neighborhood. Every lattice offset gives a valid cover, and the
    count is minimized over random offsets (no sampling of the region is involved)."""
    a = np.sqrt(3.0) * disc_radius
    h = a * np.sqrt(3.0) / 2
    ext = p.r_max + neighborhood + 2 * disc_radius
    ii, jj = np.meshgrid(np.arange(-int(ext / a) - 4, int(ext / a) + 5), np.arange(-int(ext / h) - 4, int(ext / h) + 5),
                         indexing="ij")
    base = np.stack([ii * a + (jj % 2) * a / 2, jj * h], -1).reshape(-1, 2)
    counts = [int(np.sum(distance_to_region(base + rng.uniform(0, [a, 2 * h], 2), p) <= neighborhood + disc_radius))
              for _ in range(trials)]
    best = min(counts)
    return dict(disc_radius_m=disc_radius, neighborhood_m=neighborhood, discs=best, bits=int(np.ceil(np.log2(best))),
                trials=trials, construction="triangular lattice, discs whose centers lie within neighborhood + radius of the region")


def mle_hits():
    p = system_params(load_config(overrides={"Nt": 256}))
    d = load_split("nt256p_test", {"Hhat", "xy"})
    F = mle_features(d["Hhat"][:, 0].reshape(-1, p.Nt), p)
    xy = d["xy"].reshape(-1, 2)
    theta = np.arcsin(np.clip(F[:, 0], -1, 1))
    r = np.clip(np.cos(theta) ** 2 / np.maximum(F[:, 1], 1e-6), p.r_min, p.r_max)
    err = np.linalg.norm(np.column_stack([r * np.cos(theta), r * np.sin(theta)]) - xy, axis=1)
    return dict(users=int(len(err)), hit_0p5=float(np.mean(err <= 0.5)), hit_1p0=float(np.mean(err <= 1.0)),
                median_err_m=float(np.median(err)))


def multipath_range_error(nt, kappa_db, n, rng):
    p = system_params(load_config(overrides={"Nt": nt, "channel": {"rician_k_db": kappa_db}}))
    r0 = np.full((n, 1), 10.0)
    th0 = np.zeros((n, 1))
    rs, ts = ch.sample_scatterers(rng, r0, th0, p)
    beta = (r0 / p.r_ref) ** (-p.eta)
    geom = ch.Geometry(r=r0, theta=th0, r_sc=rs, theta_sc=ts, shadow_db=np.zeros((n, 1)), beta=beta)
    H = ch.draw_channels(rng, geom, ch.path_responses(geom, p), p)
    F = mle_features(H.reshape(-1, p.Nt), p)
    theta = np.arcsin(np.clip(F[:, 0], -1, 1))
    tau = F[:, 1]
    r_hat = np.where(tau > 1e-5, np.cos(theta) ** 2 / np.maximum(tau, 1e-12), np.inf)
    e = np.abs(np.minimum(r_hat, 1e3) - 10.0)
    return dict(Nt=nt, kappa_db=kappa_db, users=n, median_abs_range_error_m=float(np.median(e)),
                p90_abs_range_error_m=float(np.percentile(e, 90)), frac_within_1m=float(np.mean(e <= 1.0)))


def main(argv=None):
    import argparse

    ap = argparse.ArgumentParser()
    ap.add_argument("--covers-only", action="store_true", help="recompute the disc covers and keep the other entries")
    args = ap.parse_args(argv)
    p = system_params(load_config())
    path = ROOT / "results" / "aggregated" / "revision_checks.json"
    t0 = time.time()
    out = json.loads(path.read_text()) if args.covers_only else dict(created=time.strftime("%Y-%m-%d %H:%M:%S"),
                                                                     range_bounds=range_bounds())
    cover_rng = np.random.default_rng(1)
    out["cover_region_1m"] = hexagonal_cover(p, 1.0, 0.0, cover_rng)
    out["cover_neighborhood_0p5m"] = hexagonal_cover(p, 0.5, 0.5, cover_rng)
    if args.covers_only:
        out["covers_updated"] = time.strftime("%Y-%m-%d %H:%M:%S")
    else:
        rng = np.random.default_rng(20260914)
        out["mle_hits_nt256"] = mle_hits()
        out["multipath_range_error"] = [multipath_range_error(nt, kdb, 3000, rng) for nt in (64, 256) for kdb in (10.0, 60.0)]
        out["runtime_s"] = time.time() - t0
    path.write_text(json.dumps(out, indent=1))
    print(json.dumps({k: v for k, v in out.items() if k.startswith("cover")}, indent=1))


if __name__ == "__main__":
    main()
