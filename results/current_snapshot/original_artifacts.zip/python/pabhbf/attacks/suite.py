"""Privacy attacker suite (Task 10).

Location attackers
- A1 mlp_xy: MLP regressor z -> (x, y)
- A2 mlp_rtheta: MLP regressor z -> (r, theta)
- A5 resmlp_xy: residual MLP with layer normalization and a Huber loss (architecture not used in training)
- knn: distance-weighted k-nearest neighbours
- grid: MLP classifier over 0.5 m cells, decoded by disc-MAP (grid_map) and by the posterior mean (grid_mean)
Reconstruction attacker
- A3 decoder: MLP z -> scaled [Re h_hat; Im h_hat], reported as NMSE
The attackers are trained after the representation is frozen, on representations of the attacker split (drops that no
encoder or controller saw), with early stopping on the validation split, and tested on the test split. The reported
leakage is the largest tolerance-region hit probability over the location attackers.
"""
from __future__ import annotations

import time

import numpy as np
from sklearn.neighbors import KNeighborsRegressor

from ..losses import privacy as priv
from .models import MLPRegressor, ResidualMLPRegressor, location_metrics, predict, train_regressor

LOCATION_ATTACKERS = ("mlp_xy", "mlp_rtheta", "resmlp_xy", "knn", "grid")


def _standardize(Ztr, *others):
    mu, sd = Ztr.mean(0), Ztr.std(0) + 1e-6
    return [((Z - mu) / sd).astype(np.float32) for Z in (Ztr,) + others]


def _softmax(logits: np.ndarray) -> np.ndarray:
    e = np.exp(logits - logits.max(1, keepdims=True))
    return e / e.sum(1, keepdims=True)


def run_suite(Z: dict, xy: dict, p, cfg, *, attackers=LOCATION_ATTACKERS, csi: dict | None = None, seed: int = 0,
              epochs: int = 40, knn_rows: int = 100_000, grid_cell: float = 0.5, keep_predictions: bool = False,
              n_jobs: int = -1, patience: int = 6) -> dict:
    """Z and xy map "attack", "val" and "test" to (N, d) representations and (N, 2) positions.

    epochs caps the training of every learned attacker, and patience is the number of epochs without a lower validation
    loss after which it stops (the defaults are those of all evaluations in the paper; attacks/scaling.py raises both).
    """
    rho = cfg["privacy"]["tolerance_radius_m"]
    bins = np.linspace(p.r_min, p.r_max, 9)
    Ztr, Zva, Zte = _standardize(Z["attack"], Z["val"], Z["test"])
    ytr, yva, yte = (np.asarray(xy[k], float).reshape(-1, 2) for k in ("attack", "val", "test"))
    d = Ztr.shape[1]
    runs, preds = {}, {}

    def record(name, pred, t0, extra=None):
        runs[name] = dict(train_s=time.time() - t0, **location_metrics(yte, pred, rho, bins), **(extra or {}))
        if keep_predictions:
            preds[name] = pred.astype(np.float32)

    if "mlp_xy" in attackers:
        t0 = time.time()
        m, h = train_regressor(MLPRegressor(d, 2), Ztr, ytr / p.r_max, Zva, yva / p.r_max, epochs=epochs, batch=2048,
                               lr=2e-3, seed=seed, patience=patience)
        record("mlp_xy", predict(m, Zte) * p.r_max, t0, dict(epochs_run=h["epochs_run"]))
    if "mlp_rtheta" in attackers:
        t0 = time.time()

        def polar(y):
            return np.stack([np.hypot(y[:, 0], y[:, 1]) / p.r_max, np.arctan2(y[:, 1], y[:, 0]) / p.theta_max], 1)

        m, h = train_regressor(MLPRegressor(d, 2), Ztr, polar(ytr), Zva, polar(yva), epochs=epochs, batch=2048, lr=2e-3,
                               seed=seed + 1, patience=patience)
        o = predict(m, Zte)
        r, th = o[:, 0] * p.r_max, o[:, 1] * p.theta_max
        record("mlp_rtheta", np.stack([r * np.cos(th), r * np.sin(th)], 1), t0, dict(epochs_run=h["epochs_run"]))
    if "resmlp_xy" in attackers:
        t0 = time.time()
        m, h = train_regressor(ResidualMLPRegressor(d, 2, width=384, blocks=3), Ztr, ytr / p.r_max, Zva, yva / p.r_max,
                               epochs=epochs, batch=2048, lr=1e-3, loss="huber", seed=seed + 2, patience=patience)
        record("resmlp_xy", predict(m, Zte) * p.r_max, t0, dict(epochs_run=h["epochs_run"]))
    if "knn" in attackers:
        t0 = time.time()
        rows = np.random.default_rng(seed).choice(len(Ztr), min(knn_rows, len(Ztr)), replace=False)
        knn = KNeighborsRegressor(n_neighbors=20, weights="distance", n_jobs=n_jobs).fit(Ztr[rows], ytr[rows])
        record("knn", knn.predict(Zte), t0)
    if "grid" in attackers:
        t0 = time.time()
        grid = priv.make_grid(ytr, grid_cell, rho, p.r_max, p.theta_max)
        clf, h = train_regressor(MLPRegressor(d, grid.C, hidden=(512, 512, 256)), Ztr, grid.index(ytr), Zva,
                                 grid.index(yva), epochs=epochs, batch=2048, lr=2e-3, loss="ce", seed=seed + 3, patience=patience)
        probs = _softmax(predict(clf, Zte).astype(np.float64))
        ce = float(-np.mean(np.log(probs[np.arange(len(probs)), grid.index(yte)] + 1e-12)))
        extra = dict(epochs_run=h["epochs_run"], cells=grid.C, ce_nats=ce, prior_entropy_nats=grid.entropy_nats,
                     mi_lower_bound_bits=max(0.0, (grid.entropy_nats - ce) / np.log(2.0)))
        record("grid_map", priv.disc_map(probs, grid), t0, extra)
        record("grid_mean", priv.posterior_mean(probs, grid), t0, extra)
    out = dict(attackers=runs)
    if runs:
        best = max(runs, key=lambda k: runs[k]["hit_prob"])
        out["summary"] = dict(leakage=runs[best]["hit_prob"], leakage_attacker=best,
                              rmse_min_m=min(v["rmse_m"] for v in runs.values()),
                              median_err_min_m=min(v["median_err_m"] for v in runs.values()),
                              range_mae_min_m=min(v["range_mae_m"] for v in runs.values()),
                              angle_mae_min_deg=min(v["angle_mae_deg"] for v in runs.values()),
                              r2_max=max(v["r2"] for v in runs.values()), bins_best=runs[best]["bins"],
                              prior_hit=float(np.pi * rho**2 / p.area))
    if csi is not None:
        t0 = time.time()
        m, h = train_regressor(MLPRegressor(d, csi["attack"].shape[1], hidden=(512, 512)), Ztr, csi["attack"], Zva,
                               csi["val"], epochs=epochs, batch=2048, lr=2e-3, seed=seed + 4, patience=patience)
        xhat = predict(m, Zte)
        nmse = np.sum((csi["test"] - xhat) ** 2, 1) / np.sum(csi["test"] ** 2, 1)
        out["decoder"] = dict(nmse_db=float(10 * np.log10(nmse.mean())), train_s=time.time() - t0, epochs_run=h["epochs_run"])
    if keep_predictions:
        out["predictions"] = preds
    return out
