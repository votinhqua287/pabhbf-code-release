"""Leakage versus the amount of attack data, with attackers trained to convergence (review item on attacker strength).

  python -m pabhbf.attacks.scaling --reps pabhbf:lam0.03 pabhbf:lam0 pabhbf:dz4_lam0 --sizes 5000 20000 80000 --threads 4
  python -m pabhbf.attacks.scaling --reps baselines:raw_csi --sizes 5000 20000 --threads 4

For every seed-1 representation, the attackers (MLP, kNN and the 0.5 m cell classifier) are trained on the first N drops
of an attack pool and tested on the default test split, with the default validation split for early stopping. The pool
is the default attack split (20,000 drops) extended by drops generated on the fly with the same channel model and fresh
seeds, so only the representations are kept in memory. The learned attackers train for up to --epochs epochs and stop
after --patience epochs without a lower validation loss. One JSON file per representation and size goes to --out
(results/raw/attack_scaling/ by default), and existing files are skipped.
"""
from __future__ import annotations

import argparse
import json
import pathlib
import time

import numpy as np
import torch
from threadpoolctl import threadpool_limits

from ..data.dataset import generate_split, load_split
from ..eval.evaluate import Method, resolve
from ..train.common import run_metadata
from ..utils.config import ROOT, load_config, system_params
from .suite import run_suite

OUT = ROOT / "results" / "raw" / "attack_scaling"
COMMON = ("mlp_xy", "knn", "grid_map", "grid_mean")


def features(method: Method, Hhat: np.ndarray, rng, chunk: int = 2000) -> np.ndarray:
    with torch.no_grad():
        parts = [method.represent(Hhat[i:i + chunk], rng).numpy() for i in range(0, len(Hhat), chunk)]
    Z = np.concatenate(parts)
    return Z.reshape(-1, Z.shape[-1]).astype(np.float32)


def main(argv=None):
    ap = argparse.ArgumentParser()
    ap.add_argument("--reps", nargs="+", required=True, help="kind:tag of seed-1 checkpoints, e.g. pabhbf:lam0.03 baselines:raw_csi")
    ap.add_argument("--sizes", type=int, nargs="+", default=[5000, 20000, 80000])
    ap.add_argument("--epochs", type=int, default=200)
    ap.add_argument("--patience", type=int, default=20)
    ap.add_argument("--threads", type=int, default=4)
    ap.add_argument("--extra-chunk", type=int, default=5000, help="drops per generated chunk beyond the stored attack split")
    ap.add_argument("--seed-offset", type=int, default=100, help="added to the configuration seed for the generated chunks")
    ap.add_argument("--stored-limit", type=int, default=0, help="use only the first drops of the stored attack split (smoke tests)")
    ap.add_argument("--out", default=str(OUT))
    args = ap.parse_args(argv)
    torch.set_num_threads(args.threads)
    blas_limit = threadpool_limits(limits=args.threads)  # noqa: F841  (kept alive for the whole run)
    cfg = load_config()
    p = system_params(cfg)
    out_dir = pathlib.Path(args.out)
    out_dir.mkdir(parents=True, exist_ok=True)
    rng = np.random.default_rng(0)

    splits = {s: load_split(f"default_{s}", {"Hhat", "xy"}) for s in ("attack", "val", "test")}
    if args.stored_limit:
        splits["attack"] = {k: v[:args.stored_limit] for k, v in splits["attack"].items()}
    stored = splits["attack"]["Hhat"].shape[0]

    for rep in args.reps:
        kind, tag = rep.split(":")
        todo = [n for n in args.sizes if not (out_dir / f"{tag}_n{n}.json").exists()]
        if not todo:
            print(f"{tag}: all sizes done", flush=True)
            continue
        path = resolve(f"results/checkpoints/{kind}/{tag}_s1_*.pt")
        method = Method(torch.load(path, weights_only=False), p)
        t0 = time.time()
        Z = {s: features(method, splits[s]["Hhat"][:, 0], rng) for s in ("val", "test")}
        xy = {s: splits[s]["xy"].reshape(-1, 2) for s in ("val", "test")}
        pool_Z, pool_xy = [features(method, splits["attack"]["Hhat"][:, 0], rng)], [splits["attack"]["xy"].reshape(-1, 2)]
        drops, i = stored, 0
        while drops < max(todo):
            data = generate_split(p, args.extra_chunk, cfg["seed"] + args.seed_offset + i, cfg["snr_db_list"], T=1,
                                  far_field_twin=False, teacher=False, weights=cfg["weights"]["classes"],
                                  weight_probs=cfg["weights"]["probs"], chunk=1000)
            pool_Z.append(features(method, data["Hhat"][:, 0], rng))
            pool_xy.append(np.asarray(data["xy"]).reshape(-1, 2))
            drops, i = drops + args.extra_chunk, i + 1
            del data
        pool_Z, pool_xy = np.concatenate(pool_Z), np.concatenate(pool_xy)
        print(f"{tag}: pool of {drops} drops ({i} generated chunks), dimension {pool_Z.shape[1]} ({time.time() - t0:.0f} s)", flush=True)
        for n in sorted(todo):
            rows = min(n, drops) * p.K
            Z["attack"], xy["attack"] = pool_Z[:rows], pool_xy[:rows]
            knn_rows = rows if pool_Z.shape[1] <= 64 else min(rows, 100_000)
            t1 = time.time()
            res = run_suite(Z, xy, p, cfg, attackers=("mlp_xy", "knn", "grid"), seed=0, epochs=args.epochs,
                            patience=args.patience, knn_rows=knn_rows, grid_cell=cfg["privacy"].get("attack_grid_cell_m", 0.5),
                            n_jobs=args.threads)
            runs = res["attackers"]
            out = dict(kind=kind, tag=tag, checkpoint=path, attack_drops=rows // p.K, attack_users=rows, knn_rows=knn_rows,
                       epochs=args.epochs, patience=args.patience, seed_offset=args.seed_offset, extra_chunk=args.extra_chunk,
                       leakage_common=max(runs[a]["hit_prob"] for a in COMMON if a in runs),
                       rmse_common_m=min(runs[a]["rmse_m"] for a in COMMON if a in runs),
                       attackers={a: {k: v for k, v in r.items() if k != "bins"} for a, r in runs.items()},
                       seconds=time.time() - t1, created=time.strftime("%Y-%m-%d %H:%M:%S"), meta=run_metadata())
            (out_dir / f"{tag}_n{n}.json").write_text(json.dumps(out, indent=1))
            epochs_run = {a: r.get("epochs_run") for a, r in runs.items() if a != "grid_mean"}
            print(f"{tag} n={n}: leakage {out['leakage_common']:.3f} rmse {out['rmse_common_m']:.2f} m epochs {epochs_run} ({out['seconds']:.0f} s)", flush=True)


if __name__ == "__main__":
    main()
