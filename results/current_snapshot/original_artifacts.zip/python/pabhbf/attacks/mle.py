"""Model-based near-field localization of raw CSI (Task 6 attacker).

Coarse-to-fine maximization of the normalized correlation |b(u, tau)^H h_hat| over the polar-domain parameters
u = sin(theta) and tau = cos^2(theta)/r with exact NUSW atoms. Under white estimation error and a single LoS path this
is the maximum-likelihood estimate of the LoS geometry. The features [u, tau, normalized peak, log10 ||h_hat||^2] also
feed a learned fusion regressor, which can combine the curvature estimate with the path gain.
"""
from __future__ import annotations

import numpy as np

from ..data.channel import nf_response
from ..utils.config import SystemParams

TAU_EPS = 1e-6


def atoms(u: np.ndarray, tau: np.ndarray, nt: int, lam: float) -> np.ndarray:
    """Unit-norm NUSW responses for arrays u and tau of equal shape; tau = TAU_EPS is the far-field limit."""
    u = np.clip(u, -0.999, 0.999)
    tau = np.maximum(tau, TAU_EPS)
    b = nf_response((1.0 - u**2) / tau, np.arcsin(u), nt, lam)
    return b / np.linalg.norm(b, axis=-1, keepdims=True)


def _search(h: np.ndarray, U: np.ndarray, T: np.ndarray, nt: int, lam: float):
    """h (n, Nt); U, T (n, A). Returns the best (u, tau) per row and the peak |b^H h|."""
    B = atoms(U, T, nt, lam)
    c = np.abs(np.matmul(B.conj(), h[:, :, None])[..., 0])
    i = np.argmax(c, axis=1)
    rows = np.arange(len(h))
    return U[rows, i], T[rows, i], c[rows, i]


def mle_features(Hhat: np.ndarray, p: SystemParams, chunk: int = 256) -> np.ndarray:
    x = Hhat.reshape(-1, p.Nt).astype(np.complex128)
    u_max = np.sin(p.theta_max) + 1.0 / p.Nt
    tau_max = 1.0 / p.r_min
    du, dt = 1.0 / (2 * p.Nt), tau_max / 34
    u_grid = np.arange(-u_max, u_max + 1e-12, du)
    t_grid = np.array([0.0, 0.02, 0.05, 0.1, 0.2, tau_max])
    U0, T0 = (g.ravel() for g in np.meshgrid(u_grid, t_grid, indexing="ij"))
    B0 = atoms(U0, T0, p.Nt, p.lam)
    out = np.empty((len(x), 4))
    for c0 in range(0, len(x), chunk):
        h = x[c0:c0 + chunk]
        n = len(h)
        i = np.argmax(np.abs(h @ B0.conj().T), axis=1)
        u = U0[i]
        # local angle, full range sweep
        su, st = du / 2, dt
        U = np.clip(u[:, None, None] + su * np.arange(-4, 5)[None, :, None], -u_max, u_max)
        T = np.broadcast_to(st * np.arange(0, 35)[None, None, :], (n, 9, 35))
        U = np.broadcast_to(U, (n, 9, 35))
        u, tau, peak = _search(h, U.reshape(n, -1), T.reshape(n, -1), p.Nt, p.lam)
        for _ in range(3):  # zoom by 4 per stage
            su, st = su / 4, st / 4
            off = np.arange(-4, 5)
            U = np.clip(u[:, None, None] + su * off[None, :, None], -u_max, u_max) + 0.0 * off[None, None, :]
            T = np.clip(tau[:, None, None] + st * off[None, None, :], 0.0, 1.2 * tau_max) + 0.0 * off[None, :, None]
            u, tau, peak = _search(h, U.reshape(n, -1), T.reshape(n, -1), p.Nt, p.lam)
        norm2 = np.sum(np.abs(h) ** 2, axis=1)
        out[c0:c0 + chunk] = np.stack([u, tau, peak / np.sqrt(norm2), np.log10(norm2)], axis=1)
    return out


def direct_estimate(F: np.ndarray, p: SystemParams) -> np.ndarray:
    theta = np.arcsin(np.clip(F[:, 0], -1.0, 1.0))
    r = np.clip(np.cos(theta) ** 2 / np.maximum(F[:, 1], TAU_EPS), p.r_min, p.r_max)
    return np.stack([r * np.cos(theta), r * np.sin(theta)], axis=1)
