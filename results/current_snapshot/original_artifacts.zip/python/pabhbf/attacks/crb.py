"""Cramer-Rao analysis of the location information in one line-of-sight estimate (Task 16, result A).

Model: h_hat = sqrt(Nt) alpha b(r, theta) + e, e ~ CN(0, sigma_est^2 I), with the complex LoS gain alpha a nuisance
parameter. The Fisher information of (r, theta) carried by the phase and amplitude profile across the array is
    J = (2 Nt |alpha|^2 / sigma_est^2) Re{D^H P_b^perp D},  D = [db/dr, db/dtheta],  P_b^perp = I - b b^H / ||b||^2.
An attacker who knows the path-loss law also reads range from the received power. With log-normal shadowing of standard
deviation sigma_zeta dB this adds J_gain = (10 eta / (sigma_zeta ln(10) r))^2 to the range entry.
The far-field response has db/dr = 0, so its range information comes from the power alone.

  python -m pabhbf.attacks.crb   -> results/aggregated/crb_location.json
"""
from __future__ import annotations

import json

import numpy as np

from ..data.channel import response
from ..utils.config import ROOT, load_config, system_params


def derivatives(model: str, r: float, theta: float, nt: int, lam: float):
    hr, ht = 1e-6 * r, 1e-7
    b = response(model, np.array([r]), np.array([theta]), nt, lam)[0]
    db_dr = (response(model, np.array([r + hr]), np.array([theta]), nt, lam)[0]
             - response(model, np.array([r - hr]), np.array([theta]), nt, lam)[0]) / (2 * hr)
    db_dt = (response(model, np.array([r]), np.array([theta + ht]), nt, lam)[0]
             - response(model, np.array([r]), np.array([theta - ht]), nt, lam)[0]) / (2 * ht)
    return b, np.stack([db_dr, db_dt], axis=1)


def location_crb(model: str, r: float, theta: float, nt: int, lam: float, snr_los: float, gain_info: bool,
                 eta: float, shadow_db: float):
    """Returns the CRB matrix of (r, theta) and the xy covariance bound."""
    b, D = derivatives(model, r, theta, nt, lam)
    P = np.eye(nt) - np.outer(b, b.conj()) / np.vdot(b, b).real
    J = 2.0 * nt * snr_los * np.real(D.conj().T @ P @ D)
    if gain_info and shadow_db > 0:
        J[0, 0] += (10.0 * eta / (shadow_db * np.log(10.0) * r)) ** 2
    crb = np.linalg.pinv(J) if np.linalg.cond(J) > 1e15 else np.linalg.inv(J)
    T = np.array([[np.cos(theta), -r * np.sin(theta)], [np.sin(theta), r * np.cos(theta)]])
    return crb, T @ crb @ T.T


def gaussian_hit_probability(cov: np.ndarray, rho: float, rng: np.random.Generator, n: int = 200000) -> float:
    w, V = np.linalg.eigh(cov)
    e = rng.standard_normal((n, 2)) * np.sqrt(np.maximum(w, 0.0))
    return float(np.mean(np.hypot(e[:, 0], e[:, 1]) <= rho))


def main():
    cfg = load_config()
    base = system_params(cfg)
    rng = np.random.default_rng(0)
    rho = cfg["privacy"]["tolerance_radius_m"]
    out = dict(rho=rho, pilot_snr_db=cfg["estimation"]["pilot_snr_db"], rician_k_db=cfg["channel"]["rician_k_db"], rows=[])
    for nt in (32, 64, 128, 256):
        p = system_params(load_config(overrides={"Nt": nt}))
        for model in ("near_field", "far_field"):
            for theta_deg in (0.0, 30.0):
                for r in (3.0, 4.0, 5.0, 6.0, 8.0, 10.0, 12.0, 15.0, 20.0):
                    beta = (r / p.r_ref) ** (-p.eta)
                    snr_los = p.kappa / (p.kappa + 1.0) * beta / p.sigma_est2
                    crb, cov = location_crb(model, r, np.deg2rad(theta_deg), nt, p.lam, snr_los, True, p.eta, p.shadow_std_db)
                    crb_ng, cov_ng = location_crb(model, r, np.deg2rad(theta_deg), nt, p.lam, snr_los, False, p.eta, 0.0) if model == "near_field" else (None, None)
                    row = dict(Nt=nt, model=model, theta_deg=theta_deg, r_m=r, rayleigh_m=p.rayleigh,
                               std_r_m=float(np.sqrt(crb[0, 0])), std_theta_deg=float(np.rad2deg(np.sqrt(crb[1, 1]))),
                               rmse_bound_m=float(np.sqrt(np.trace(cov))), hit_gaussian=gaussian_hit_probability(cov, rho, rng))
                    if crb_ng is not None:
                        row["std_r_phase_only_m"] = float(np.sqrt(crb_ng[0, 0]))
                    out["rows"].append(row)
    path = ROOT / "results" / "aggregated" / "crb_location.json"
    path.parent.mkdir(parents=True, exist_ok=True)
    path.write_text(json.dumps(out, indent=1))
    print(f"{'Nt':>4} {'model':>10} {'th':>4} {'r':>5} {'std_r':>8} {'std_r_ph':>9} {'rmse':>7} {'hit':>6}")
    for row in out["rows"]:
        if row["theta_deg"] == 0.0:
            print(f"{row['Nt']:>4} {row['model']:>10} {row['theta_deg']:>4.0f} {row['r_m']:>5.1f} {row['std_r_m']:>8.3f} "
                  f"{row.get('std_r_phase_only_m', float('nan')):>9.3f} {row['rmse_bound_m']:>7.3f} {row['hit_gaussian']:>6.3f}")


if __name__ == "__main__":
    main()
