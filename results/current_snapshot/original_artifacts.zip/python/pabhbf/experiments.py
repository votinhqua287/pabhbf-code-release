"""Experiment plans of docs/EXPERIMENT_PLAN.md (Task 14).

  python -m pabhbf.experiments <plan> [<plan> ...] [--parallel 3] [--threads 8] [--lam-main 1] [--dry-run]

Plans: datasets_extra, teacher_sweeps, g2, e1, baselines, e1d, e2, ablations, mismatch, phase_bits, agentic, temporal,
nt_sweep. Every training job is chained with its evaluation. Completed jobs are skipped on a rerun.
"""
from __future__ import annotations

import argparse
import re

from .utils.config import load_config
from .utils.jobs import run_queue

PY = "python -u -m"
REDUCED = "--attackers mlp_xy knn grid"


def _fmt(x: float) -> str:
    return f"{x:g}"


def train_eval(tag, seed, train_args, exp, kind="pabhbf", threads=8, eval_args="", prefix_args=""):
    module, ckdir = ("pabhbf.train.pabhbf", "pabhbf") if kind == "pabhbf" else ("pabhbf.train.baselines", "baselines")
    train = f"{PY} {module} {train_args} {prefix_args} --tag {tag} --seed {seed} --threads {threads}"
    ev = f"{PY} pabhbf.eval.evaluate --ckpt results/checkpoints/{ckdir}/{tag}_s{seed}_*.pt --exp {exp} --threads {threads} {eval_args}"
    return dict(name=f"{exp}__{tag}__s{seed}", cmd=f"{train} && {ev}")


def two_stage(tag, seed, lam, extra, exp, threads=8, eval_args="", prefix_args="", pre_tag=None):
    """Adversarial PAB-HBF run with the protocol of E1: pretraining epochs, then adversarial epochs with a fresh optimizer.

    The pretraining uses the same extra arguments as the adversarial stage. pre_tag reuses an existing pretraining
    checkpoint (for example the E1 one, tag 'pre') when the extra arguments only change the adversarial epochs.
    """
    module = f"{PY} pabhbf.train.pabhbf"
    pre = pre_tag or f"{tag}_pre"
    steps = [] if pre_tag else [f"{module} --mode adversarial --pretrain-only {extra} {prefix_args} --tag {pre} --seed {seed} --threads {threads}"]
    steps.append(f"{module} --mode adversarial --lam {_fmt(lam)} --init-ckpt results/checkpoints/pabhbf/{pre}_s{seed}_*.pt --epochs-pre 0 "
                 f"{extra} {prefix_args} --tag {tag} --seed {seed} --threads {threads}")
    steps.append(f"{PY} pabhbf.eval.evaluate --ckpt results/checkpoints/pabhbf/{tag}_s{seed}_*.pt --exp {exp} --threads {threads} {eval_args}")
    return dict(name=f"{exp}__{tag}__s{seed}", cmd=" && ".join(steps))


def plan_jobs(plan: str, args, cfg) -> list[dict]:
    th, seeds, lam_main = args.threads, cfg["training"]["seeds"], args.lam_main
    jobs = []
    if plan == "datasets_extra":
        for name, cfgfile, splits, extra in (
                ("mm_range", "mismatch_range.yaml", "test", ""), ("mm_range", "mismatch_range.yaml", "val attack", "--no-teacher"),
                ("mm_channel", "mismatch_channel.yaml", "test", ""), ("mm_channel", "mismatch_channel.yaml", "val attack", "--no-teacher"),
                ("defaultT4", "temporal.yaml", "attack val test", "--no-teacher --T 4")):
            jobs.append(dict(name=f"data__{name}__{splits.replace(' ', '_')}",
                             cmd=f"{PY} pabhbf.data.make_datasets --config {cfgfile} --prefix {name} --splits {splits} {extra} --chunk 1000"))
    elif plan == "teacher_sweeps":
        jobs.append(dict(name="teacher_sweep__default", cmd=f"{PY} pabhbf.eval.teacher_sweep --prefix default --n-drops 2000"))
        # E9: the teacher recomputed with the phase resolution of the tools, at the stored SNR of every test drop, as in
        # the phase_bits evaluation of the trained controllers
        for bits in ("2", "3", "ideal"):
            jobs.append(dict(name=f"teacher_sweep__bits{bits}_stored",
                             cmd=f"{PY} pabhbf.eval.teacher_sweep --prefix default --phase-bits {bits} --stored-snr"))
    elif plan == "g2":
        jobs += [train_eval("lam0", 1, "--mode task", "e1", threads=th),
                 train_eval("raw_csi", 1, "--rep raw_csi", "baselines", "baseline", th),
                 train_eval("lam1", 1, "--mode adversarial --lam 1", "e1", threads=th)]
    elif plan == "probe":
        # short adversarial fine-tunes from the seed-1 pretraining, used only to place the lambda grid of E1
        for lam in (args.lams or [0.01, 0.03, 0.1, 0.3]):
            jobs.append(dict(name=f"probe__lam{_fmt(lam)}",
                             cmd=f"{PY} pabhbf.train.pabhbf --mode adversarial --lam {_fmt(lam)} --init-ckpt "
                                 f"results/checkpoints/pabhbf/pre_s1_*.pt --epochs-pre 0 --epochs-adv 6 --val-drops 500 "
                                 f"--tag probe_lam{_fmt(lam)} --seed 1 --threads {th}"))
    elif plan == "e1pre":
        # shared pretraining of every lambda > 0 run of a seed (identical to the first epochs of a full run)
        for seed in seeds:
            jobs.append(dict(name=f"e1pre__s{seed}", cmd=f"{PY} pabhbf.train.pabhbf --mode adversarial --pretrain-only --tag pre --seed {seed} --threads {th}"))
    elif plan == "e1":
        lams = args.lams if args.lams else cfg["privacy"]["lambda_list"]
        for seed in seeds:
            for lam in lams:
                if lam == 0:
                    mode = "--mode task"
                else:
                    mode = (f"--mode adversarial --lam {_fmt(lam)} --init-ckpt results/checkpoints/pabhbf/pre_s{seed}_*.pt "
                            "--epochs-pre 0")
                jobs.append(train_eval(f"lam{_fmt(lam)}", seed, mode, "e1", threads=th, eval_args="" if seed == 1 else REDUCED))
    elif plan == "baselines":
        for seed in seeds:
            for rep in ("raw_csi", "pca", "random_projection", "scalar_quant", "top_m_beams", "autoencoder", "angle_domain"):
                jobs.append(train_eval(rep, seed, f"--rep {rep}", "baselines", "baseline", th, "" if seed == 1 else REDUCED))
        for sigma in (0.1, 0.2, 0.4, 0.8):
            jobs.append(train_eval(f"gaussian_pca_{_fmt(sigma)}", 1, f"--rep gaussian_pca --sigma {_fmt(sigma)}", "baselines", "baseline", th, REDUCED))
        for eps in (10, 30, 100, 300):
            jobs.append(train_eval(f"laplace_pca_{eps}", 1, f"--rep laplace_pca --epsilon {eps}", "baselines", "baseline", th, REDUCED))
    elif plan == "e1d":
        for seed in seeds[:2]:
            for eps in cfg["privacy"]["budget_list"]:
                jobs.append(train_eval(f"dual{_fmt(eps)}", seed, f"--mode dual --eps {_fmt(eps)} --lam 0.1 --init-ckpt "
                                       f"results/checkpoints/pabhbf/pre_s{seed}_*.pt --epochs-pre 0", "e1d", threads=th, eval_args=REDUCED))
    elif plan == "e2":
        for d in (4, 8, 16, 64):
            jobs.append(two_stage(f"dz{d}_lam{_fmt(lam_main)}", 1, lam_main, f"--d-z {d}", "e2", th, REDUCED))
            jobs.append(train_eval(f"dz{d}_lam0", 1, f"--mode task --d-z {d}", "e2", threads=th, eval_args=REDUCED))
            jobs.append(train_eval(f"autoencoder_dz{d}", 1, f"--rep autoencoder --d-z {d}", "e2", "baseline", th, REDUCED))
            jobs.append(train_eval(f"pca_dz{d}", 1, f"--rep pca --d-z {d}", "e2", "baseline", th, REDUCED))
    elif plan == "e2seeds":
        # small payloads over seeds 2 and 3: task-only and adversarial encoders with d_z in {4, 8}, for the Pareto comparison
        for seed in seeds[1:]:
            for d in (4, 8):
                jobs.append(train_eval(f"dz{d}_lam0", seed, f"--mode task --d-z {d}", "e2", threads=th, eval_args=REDUCED))
                jobs.append(two_stage(f"dz{d}_lam{_fmt(lam_main)}", seed, lam_main, f"--d-z {d}", "e2", th, REDUCED))
    elif plan == "ablations":
        # variants that change only the adversarial epochs reuse the E1 pretraining of seed 1
        for tag, extra, pre in (("vib", "--kind vib --beta-kl 0.001", None), ("norate", "--w-rate 0", None),
                                ("continuous", "--bits none", None), ("reversal", "--privacy-loss reversal", "pre"),
                                ("angleinput", "--input angle_domain", None), ("cnn", "--arch cnn", None),
                                ("antennainput", "--input antenna", None), ("onestep", "--attacker-steps 1", "pre")):
            jobs.append(two_stage(f"abl_{tag}_lam{_fmt(lam_main)}", 1, lam_main, extra, "ablations", th, REDUCED, pre_tag=pre))
    elif plan == "mismatch":
        tag = f"lam{_fmt(lam_main)}"
        for mm in ("mm_range", "mm_channel"):
            for t in (tag, "lam0"):
                jobs.append(dict(name=f"mismatch__{mm}__{t}", cmd=f"{PY} pabhbf.eval.evaluate --ckpt results/checkpoints/pabhbf/{t}_s1_*.pt "
                                 f"--exp mismatch --prefix {mm} --test-prefix {mm} --attack-prefix {mm} --label {t}_{mm} --threads {th} {REDUCED}"))
            for rep in ("pca", "raw_csi", "autoencoder"):
                jobs.append(dict(name=f"mismatch__{mm}__{rep}", cmd=f"{PY} pabhbf.eval.evaluate --ckpt results/checkpoints/baselines/{rep}_s1_*.pt "
                                 f"--exp mismatch --prefix {mm} --test-prefix {mm} --attack-prefix {mm} --label {rep}_{mm} --threads {th} {REDUCED}"))
    elif plan == "phase_bits":
        for bits in ("2", "3", "ideal"):
            for t in (f"lam{_fmt(lam_main)}", "lam0"):
                jobs.append(dict(name=f"phase_bits__{t}__{bits}", cmd=f"{PY} pabhbf.eval.evaluate --ckpt results/checkpoints/pabhbf/{t}_s1_*.pt "
                                 f"--exp phase_bits --phase-bits {bits} --no-privacy --no-snr-sweep --label {t}_bits{bits} --threads {th}"))
    elif plan == "agentic":
        ckpt = f"results/checkpoints/pabhbf/lam{_fmt(lam_main)}_s1_*.pt"
        jobs.append(dict(name="agentic__main", cmd=f"{PY} pabhbf.eval.agentic --ckpt {ckpt} --threads {th}"))
        # cost weights of the learned tool policy (reward = rate ratio - mu * ms / 10 - nu * bits / 8): with the defaults
        # (0.02, 0.02) every drop prefers the direct chain, so lower weights show what the policy trades for feedback
        for mu_lat, nu_bits in ((0.0, 0.0), (0.02, 0.001), (0.02, 0.005)):
            jobs.append(dict(name=f"agentic__costs_{_fmt(mu_lat)}_{_fmt(nu_bits)}",
                             cmd=f"{PY} pabhbf.eval.agentic --ckpt {ckpt} --mu-latency {_fmt(mu_lat)} --nu-bits {_fmt(nu_bits)} "
                                 f"--exp e13_agentic_costs --threads {th}"))
    elif plan == "temporal":
        for t in (f"lam{_fmt(lam_main)}", "lam0"):
            jobs.append(dict(name=f"temporal__{t}", cmd=f"{PY} pabhbf.attacks.temporal --ckpt results/checkpoints/pabhbf/{t}_s1_*.pt --prefix defaultT4 --T 1 2 4 --threads {th}"))
        jobs.append(dict(name="temporal__raw_csi", cmd=f"{PY} pabhbf.attacks.temporal --ckpt results/checkpoints/baselines/raw_csi_s1_*.pt --prefix defaultT4 --T 1 2 4 --threads {th}"))
    elif plan == "nt_sweep":
        for nt in (32, 64, 128):
            pre = f"--config nt{nt}.yaml --prefix nt{nt}"
            if nt != 64:
                jobs.append(dict(name=f"data__nt{nt}", cmd=f"{PY} pabhbf.data.make_datasets --config nt{nt}.yaml --prefix nt{nt} --splits train val test --far-field-twin --chunk 1000 && "
                                 f"{PY} pabhbf.data.make_datasets --config nt{nt}.yaml --prefix nt{nt} --splits attack --no-teacher --chunk 1000"))
            jobs.append(two_stage(f"nt{nt}_lam{_fmt(lam_main)}", 1, lam_main, "", "nt_sweep", th, REDUCED, prefix_args=pre))
            jobs.append(train_eval(f"nt{nt}_lam0", 1, "--mode task", "nt_sweep", threads=th, eval_args=REDUCED, prefix_args=pre))
            jobs.append(train_eval(f"nt{nt}_raw_csi", 1, "--rep raw_csi", "nt_sweep", "baseline", th, REDUCED, prefix_args=pre))
    else:
        raise ValueError(f"unknown plan {plan}")
    return jobs


def main():
    ap = argparse.ArgumentParser()
    ap.add_argument("plans", nargs="+")
    ap.add_argument("--parallel", type=int, default=3)
    ap.add_argument("--threads", type=int, default=8)
    ap.add_argument("--lam-main", type=float, default=1.0)
    ap.add_argument("--lams", type=float, nargs="*", default=None, help="lambda values of the probe and E1 plans")
    ap.add_argument("--dry-run", action="store_true")
    ap.add_argument("--exclude", default=None, help="regular expression; jobs whose names match are not queued")
    args = ap.parse_args()
    cfg = load_config()
    jobs, seen = [], set()
    exclude = re.compile(args.exclude) if args.exclude else None
    for plan in args.plans:
        for j in plan_jobs(plan, args, cfg):
            if exclude is not None and exclude.search(j["name"]):
                continue
            if j["name"] not in seen:  # plans share jobs (for example g2 and e1); identical names run once
                seen.add(j["name"])
                jobs.append(j)
    run_queue(jobs, max_parallel=args.parallel, dry_run=args.dry_run, threads_per_job=args.threads)


if __name__ == "__main__":
    main()
