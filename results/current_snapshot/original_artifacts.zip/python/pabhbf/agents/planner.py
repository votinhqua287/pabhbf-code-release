"""Agentic tool orchestration (Task 13).

The planner sees only the representations, the priority weights and the reference SNR, through the controller's
logits. Trusted tools run at the base station on the raw estimates. They return only their declared outputs. Every call
is counted, and every value returned to the planner is counted as exposure bits.

Trusted tools
- select_nearfield_beams and run_rzf: beam assignment within the requested groups and RZF directions (no return value)
- allocate_power: projected-gradient power allocation on the estimated coupling matrix (no return value)
- run_wmmse_refinement: WMMSE digital precoder for the assigned beams (no return value)
- evaluate_candidate: estimated weighted sum rate of a candidate action, quantized to feedback_bits and returned

Planners
- DirectAction: the controller's decoded action with RZF and the controller's shares
- RulePlanner: the decoded action, base-station power allocation and WMMSE refinement above SNR thresholds
- SearchPlanner: C candidate schedules from the controller scores, scored by evaluate_candidate, best one executed
- LearnedToolPolicy: a multinomial logistic classifier that picks one of these chains per drop from controller
  confidence features, trained on held-out drops to maximize the realized rate ratio minus latency and exposure costs
"""
from __future__ import annotations

import time
from collections import defaultdict

import numpy as np
from sklearn.linear_model import LogisticRegression

from ..phy import hbf
from ..phy.teacher import optimize_shares
from ..phy.wmmse import wmmse_digital


def _softmax(x, axis=-1):
    e = np.exp(x - x.max(axis=axis, keepdims=True))
    return e / e.sum(axis=axis, keepdims=True)


def decode(sched_logits, group_logits, power_logits, Ns, sel=None):
    """Numpy decoding of controller logits; sel (n, Ns) overrides the top-Ns user selection."""
    order = np.argsort(-sched_logits, axis=1, kind="stable")
    sched = np.sort(order[:, :Ns] if sel is None else sel, axis=1)
    groups = np.take_along_axis(group_logits, sched[:, :, None], axis=1).argmax(-1)
    shares = _softmax(np.take_along_axis(power_logits, sched, axis=1).astype(np.float64), axis=1)
    return sched, groups, shares, order


class TrustedToolbox:
    def __init__(self, Hhat, w, snr_db, cb, feedback_bits: int = 8, rate_max: float = 400.0):
        self.Hhat, self.w, self.cb = Hhat, w, cb
        self.snr = 10.0 ** (np.asarray(snr_db, float) / 10.0)
        self.gains = hbf.codeword_gains(Hhat, cb)
        self.feedback_bits, self.rate_max = feedback_bits, rate_max
        self.calls = defaultdict(int)
        self.exposure_bits = 0

    def _build(self, rows, sched, groups, shares):
        return hbf.build_precoders(self.Hhat[rows], sched, groups, shares, self.cb, self.snr[rows], gains=self.gains[rows])

    def evaluate_candidate(self, rows, sched, groups, shares) -> np.ndarray:
        _, FRF, Fbar = self._build(rows, sched, groups, shares)
        FBB = hbf.power_scaling(FRF, Fbar, shares)
        g = hbf.sinr(hbf.gather_users(self.Hhat[rows], sched), FRF, FBB, 1.0 / self.snr[rows])
        v = np.sum(hbf.gather_users(self.w[rows], sched) * np.log2(1.0 + g), axis=1)
        levels = 2**self.feedback_bits
        q = np.clip(np.floor(v / self.rate_max * levels), 0, levels - 1)
        self.calls["evaluate_candidate"] += len(rows)
        self.exposure_bits += self.feedback_bits * len(rows)
        return (q + 0.5) * self.rate_max / levels

    def execute(self, rows, sched, groups, shares, power: str = "controller", wmmse: bool = False):
        _, FRF, Fbar = self._build(rows, sched, groups, shares)
        self.calls["select_nearfield_beams"] += len(rows)
        self.calls["run_rzf"] += len(rows)
        Hh_S = hbf.gather_users(self.Hhat[rows], sched)
        w_S = hbf.gather_users(self.w[rows], sched)
        if power == "optimized":
            A = hbf.coupling_matrix(Hh_S, FRF, Fbar)
            shares = optimize_shares(A, w_S, 1.0 / self.snr[rows], iters=60)
            self.calls["allocate_power"] += len(rows)
        FBB = hbf.power_scaling(FRF, Fbar, shares)
        if wmmse:
            FBB = wmmse_digital(Hh_S, FRF, FBB, w_S, 1.0 / self.snr[rows], iters=10)
            self.calls["run_wmmse_refinement"] += len(rows)
        return FRF, FBB


def _fill(n, Nt, S):
    return np.empty((n, S), int), np.empty((n, Nt, S), complex), np.empty((n, S, S), complex)


class DirectAction:
    name = "direct"

    def run(self, L, box, rows, Ns):
        sched, groups, shares, _ = decode(*(x[rows] for x in L), Ns)
        FRF, FBB = box.execute(rows, sched, groups, shares)
        return sched, FRF, FBB


class RulePlanner:
    name = "rule"

    def __init__(self, snr_power_db: float = -np.inf, snr_wmmse_db: float = 10.0):
        self.snr_power_db, self.snr_wmmse_db = snr_power_db, snr_wmmse_db

    def run(self, L, box, rows, Ns):
        rows = np.asarray(rows)
        sched, groups, shares, _ = decode(*(x[rows] for x in L), Ns)
        snr_db = 10.0 * np.log10(box.snr[rows])
        S_out, FRF_out, FBB_out = _fill(len(rows), box.Hhat.shape[-1], Ns)
        for power, wmmse, mask in (("controller", False, snr_db < self.snr_power_db),
                                   ("optimized", False, (snr_db >= self.snr_power_db) & (snr_db < self.snr_wmmse_db)),
                                   ("optimized", True, snr_db >= self.snr_wmmse_db)):
            if mask.any():
                FRF, FBB = box.execute(rows[mask], sched[mask], groups[mask], shares[mask], power, wmmse)
                S_out[mask], FRF_out[mask], FBB_out[mask] = sched[mask], FRF, FBB
        return S_out, FRF_out, FBB_out


class SearchPlanner:
    name = "search"

    def __init__(self, n_candidates: int = 4, power: str = "optimized", wmmse: bool = False):
        self.C, self.power, self.wmmse = n_candidates, power, wmmse
        self.name = f"search{n_candidates}"

    def run(self, L, box, rows, Ns):
        rows = np.asarray(rows)
        sl, gl, pl = (x[rows] for x in L)
        order = np.argsort(-sl, axis=1, kind="stable")
        best_v = np.full(len(rows), -np.inf)
        best = [None, None, None]
        for j in range(self.C):
            sel = order[:, :Ns].copy()
            if j > 0:
                sel[:, Ns - j] = order[:, Ns - 1 + j]
            sched, groups, shares, _ = decode(sl, gl, pl, Ns, sel=sel)
            v = box.evaluate_candidate(rows, sched, groups, shares)
            better = v > best_v
            best_v = np.where(better, v, best_v)
            for i, arr in enumerate((sched, groups, shares)):
                best[i] = arr.copy() if best[i] is None else np.where(better.reshape((-1,) + (1,) * (arr.ndim - 1)), arr, best[i])
        FRF, FBB = box.execute(rows, best[0], best[1], best[2], self.power, self.wmmse)
        return best[0], FRF, FBB


def confidence_features(L, snr_db, Ns) -> np.ndarray:
    sl, gl, pl = L
    s = -np.sort(-sl, axis=1)
    margin = s[:, Ns - 1] - s[:, Ns]
    sched, _, shares, _ = decode(sl, gl, pl, Ns)
    gconf = _softmax(np.take_along_axis(gl, sched[:, :, None], axis=1).astype(np.float64), axis=-1).max(-1).mean(1)
    entropy = -(shares * np.log(shares + 1e-12)).sum(1)
    return np.stack([np.asarray(snr_db) / 10.0, margin, gconf, entropy], axis=1)


class LearnedToolPolicy:
    name = "learned"

    def __init__(self, chains, mu_latency: float = 0.02, nu_bits: float = 0.02):
        self.chains, self.mu, self.nu = chains, mu_latency, nu_bits

    def fit(self, L, box, rows, realized_wsr, teacher_wsr, Ns):
        """realized_wsr(sched, FRF, FBB, rows) -> (n,) true weighted sum rate, used offline on simulated drops."""
        rewards, self.chain_costs = [], []
        for chain in self.chains:
            bits0, t0 = box.exposure_bits, time.time()
            sched, FRF, FBB = chain.run(L, box, rows, Ns)
            ms = 1e3 * (time.time() - t0) / len(rows)
            bits = (box.exposure_bits - bits0) / len(rows)
            self.chain_costs.append(dict(ms_per_drop=ms, bits_per_drop=bits))
            rewards.append(realized_wsr(sched, FRF, FBB, rows) / teacher_wsr - self.mu * ms / 10.0 - self.nu * bits / 8.0)
        labels = np.argmax(np.stack(rewards, axis=1), axis=1)
        X = confidence_features(tuple(x[rows] for x in L), 10.0 * np.log10(box.snr[rows]), Ns)
        self.single = len(np.unique(labels)) == 1
        self.label0 = int(labels[0])
        if not self.single:
            self.clf = LogisticRegression(max_iter=2000).fit(X, labels)
        self.label_counts = np.bincount(labels, minlength=len(self.chains)).tolist()
        return self

    def run(self, L, box, rows, Ns):
        rows = np.asarray(rows)
        X = confidence_features(tuple(x[rows] for x in L), 10.0 * np.log10(box.snr[rows]), Ns)
        choice = np.full(len(rows), self.label0) if self.single else self.clf.predict(X)
        S_out, FRF_out, FBB_out = _fill(len(rows), box.Hhat.shape[-1], Ns)
        for c, chain in enumerate(self.chains):
            mask = choice == c
            if mask.any():
                s, F1, F2 = chain.run(L, box, rows[mask], Ns)
                S_out[mask], FRF_out[mask], FBB_out[mask] = s, F1, F2
        self.last_choice_counts = np.bincount(choice, minlength=len(self.chains)).tolist()
        return S_out, FRF_out, FBB_out
