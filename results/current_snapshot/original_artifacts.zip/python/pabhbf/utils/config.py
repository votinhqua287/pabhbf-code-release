"""Configuration loading and derived system parameters (Task 2).

All simulation parameters come from configs/default.yaml, optionally overridden by further YAML files
or by a dictionary. Derived quantities are computed once in SystemParams.
"""
from __future__ import annotations

import copy
import pathlib
from dataclasses import dataclass

import numpy as np
import yaml

from .units import aperture, db2lin, fresnel_distance, rayleigh_distance, wavelength

ROOT = pathlib.Path(__file__).resolve().parents[3]
CONFIG_DIR = ROOT / "configs"


def _deep_merge(base: dict, over: dict) -> dict:
    out = copy.deepcopy(base)
    for key, value in over.items():
        if isinstance(value, dict) and isinstance(out.get(key), dict):
            out[key] = _deep_merge(out[key], value)
        else:
            out[key] = copy.deepcopy(value)
    return out


def load_config(*override_files: str | pathlib.Path, overrides: dict | None = None) -> dict:
    with open(CONFIG_DIR / "default.yaml", encoding="utf-8") as fh:
        cfg = yaml.safe_load(fh)
    for path in override_files:
        path = pathlib.Path(path)
        if not path.is_absolute():
            path = CONFIG_DIR / path
        with open(path, encoding="utf-8") as fh:
            cfg = _deep_merge(cfg, yaml.safe_load(fh) or {})
    if overrides:
        cfg = _deep_merge(cfg, overrides)
    return cfg


@dataclass(frozen=True)
class SystemParams:
    Nt: int
    Nrf: int
    K: int
    Ns: int
    phase_bits: int
    fc: float
    lam: float
    d: float
    D: float
    rayleigh: float
    fresnel: float
    r_min: float
    r_max: float
    theta_max: float
    model: str
    L: int
    kappa: float
    eta: float
    shadow_std_db: float
    r_sc: float
    r_ref: float
    sigma_est2: float
    delta_cb: float
    G: int
    r_dist: str = "area"

    @property
    def area(self) -> float:
        return self.theta_max * (self.r_max**2 - self.r_min**2)


def system_params(cfg: dict) -> SystemParams:
    Nt, Nrf, K, Ns = int(cfg["Nt"]), int(cfg["Nrf"]), int(cfg["K"]), int(cfg["Ns"])
    if not (1 <= Ns <= Nrf <= Nt) or Ns > K:
        raise ValueError(f"invalid dimensions Nt={Nt}, Nrf={Nrf}, K={K}, Ns={Ns}")
    lam = wavelength(float(cfg["carrier_frequency_hz"]))
    d = lam / 2
    D = aperture(Nt, d)
    reg, ch = cfg["region"], cfg["channel"]
    r_min, r_max = float(reg["r_min_m"]), float(reg["r_max_m"])
    if not 0 < r_min < r_max:
        raise ValueError("invalid region radii")
    r_ref = r_max if ch.get("reference_distance", "r_max") == "r_max" else float(ch["reference_distance"])
    if ch["model"] not in ("near_field", "far_field"):
        raise ValueError(f"unknown channel model {ch['model']}")
    r_dist = reg.get("distribution", "area")
    if r_dist not in ("area", "range"):
        raise ValueError(f"unknown user distribution {r_dist}")
    return SystemParams(
        Nt=Nt, Nrf=Nrf, K=K, Ns=Ns, phase_bits=int(cfg["phase_bits"]),
        fc=float(cfg["carrier_frequency_hz"]), lam=lam, d=d, D=D,
        rayleigh=rayleigh_distance(D, lam), fresnel=fresnel_distance(D, lam),
        r_min=r_min, r_max=r_max, theta_max=np.deg2rad(float(reg["theta_max_deg"])),
        model=ch["model"], L=int(ch["num_nlos_paths"]), kappa=float(db2lin(ch["rician_k_db"])),
        eta=float(ch["pathloss_exponent"]), shadow_std_db=float(ch["shadowing_std_db"]),
        r_sc=float(ch["scatterer_radius_m"]), r_ref=r_ref,
        sigma_est2=float(db2lin(-float(cfg["estimation"]["pilot_snr_db"]))),
        delta_cb=float(cfg["codebook"]["correlation_level"]), G=int(cfg["codebook"]["groups"]), r_dist=r_dist,
    )
