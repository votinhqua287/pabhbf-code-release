"""Bounded-concurrency job queue for the experiment matrix.

Each job is a shell command with a unique name. The queue writes one log per job to results/raw/logs/queue/ and a
.done marker (return code 0) or a .failed marker, and skips jobs whose .done marker exists, so a plan can be resumed.
"""
from __future__ import annotations

import json
import os
import subprocess
import time

from .config import ROOT

LOG_DIR = ROOT / "results" / "raw" / "logs" / "queue"


def run_queue(jobs: list[dict], max_parallel: int = 3, poll_s: float = 15.0, dry_run: bool = False,
              threads_per_job: int | None = None) -> dict:
    LOG_DIR.mkdir(parents=True, exist_ok=True)
    env = dict(os.environ, PYTHONPATH=str(ROOT / "python"), PYTHONUNBUFFERED="1")
    if threads_per_job:
        # NumPy's BLAS otherwise starts one thread per logical core in every job and oversubscribes the machine
        for var in ("OMP_NUM_THREADS", "MKL_NUM_THREADS", "OPENBLAS_NUM_THREADS", "NUMEXPR_NUM_THREADS"):
            env[var] = str(threads_per_job)
    names = [j["name"] for j in jobs]
    if len(set(names)) != len(names):
        raise ValueError("job names must be unique")
    pending = [j for j in jobs if not (LOG_DIR / f"{j['name']}.done").exists()]
    if dry_run:
        for j in pending:
            print(j["name"], "|", j["cmd"])
        return {}
    running, status = {}, {}
    while pending or running:
        while pending and len(running) < max_parallel:
            j = pending.pop(0)
            (LOG_DIR / f"{j['name']}.failed").unlink(missing_ok=True)
            log = open(LOG_DIR / f"{j['name']}.log", "w", encoding="utf-8")
            proc = subprocess.Popen(j["cmd"], shell=True, cwd=ROOT, env=env, stdout=log, stderr=subprocess.STDOUT)
            running[j["name"]] = (proc, log, time.time())
            print(f"[{time.strftime('%H:%M:%S')}] start {j['name']}", flush=True)
        time.sleep(poll_s)
        for name, (proc, log, t0) in list(running.items()):
            if proc.poll() is None:
                continue
            log.close()
            info = dict(returncode=proc.returncode, seconds=time.time() - t0, finished=time.strftime("%Y-%m-%d %H:%M:%S"))
            (LOG_DIR / f"{name}.{'done' if proc.returncode == 0 else 'failed'}").write_text(json.dumps(info))
            status[name] = info
            print(f"[{time.strftime('%H:%M:%S')}] end {name} rc={proc.returncode} ({info['seconds']:.0f} s)", flush=True)
            del running[name]
    return status
