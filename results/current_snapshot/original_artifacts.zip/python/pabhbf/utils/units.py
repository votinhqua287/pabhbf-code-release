"""Unit conversions, array constants, real/complex packing, and seeding (Task 2)."""
from __future__ import annotations

import random

import numpy as np

C0 = 299_792_458.0  # speed of light in m/s


def db2lin(x):
    """Power ratio in dB to linear scale."""
    return 10.0 ** (np.asarray(x, dtype=float) / 10.0)


def lin2db(x):
    """Linear power ratio to dB. Raises for non-positive inputs instead of silently clipping."""
    x = np.asarray(x, dtype=float)
    if np.any(x <= 0):
        raise ValueError("lin2db requires strictly positive values")
    return 10.0 * np.log10(x)


def wavelength(fc_hz: float) -> float:
    if fc_hz <= 0:
        raise ValueError("carrier frequency must be positive")
    return C0 / fc_hz


def aperture(nt: int, spacing: float) -> float:
    """Distance between the two outermost antennas of a ULA."""
    return (nt - 1) * spacing


def rayleigh_distance(aperture_m: float, lam: float) -> float:
    return 2.0 * aperture_m**2 / lam


def fresnel_distance(aperture_m: float, lam: float) -> float:
    return 0.5 * np.sqrt(aperture_m**3 / lam)


def c2r(z: np.ndarray) -> np.ndarray:
    """Stack real and imaginary parts along the last axis: C^n -> R^{2n}."""
    z = np.asarray(z)
    return np.concatenate([z.real, z.imag], axis=-1)


def r2c(x: np.ndarray) -> np.ndarray:
    """Inverse of c2r."""
    x = np.asarray(x)
    n = x.shape[-1]
    if n % 2:
        raise ValueError("last dimension must be even")
    return x[..., : n // 2] + 1j * x[..., n // 2 :]


def seed_everything(seed: int) -> np.random.Generator:
    """Seed Python, NumPy and PyTorch and return a NumPy generator for explicit use."""
    random.seed(seed)
    np.random.seed(seed % 2**32)
    try:
        import torch

        torch.manual_seed(seed)
    except ImportError:  # pragma: no cover
        pass
    return np.random.default_rng(seed)
