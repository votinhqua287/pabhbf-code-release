#!/usr/bin/env bash
# Compile the manuscript into manuscript/build (pdflatex, bibtex, two more pdflatex passes) and report problems.
set -euo pipefail
cd "$(dirname "$0")/../manuscript"
mkdir -p build
cp ./*.bib build/
pdflatex -interaction=nonstopmode -output-directory=build main.tex > build/pass1.log || true
(cd build && bibtex main > bibtex.log) || true
pdflatex -interaction=nonstopmode -output-directory=build main.tex > build/pass2.log || true
pdflatex -interaction=nonstopmode -output-directory=build main.tex > build/pass3.log || true
if grep -E "^! |Undefined control|undefined on input|Overfull" build/main.log; then
  echo "build finished with the problems listed above"
else
  echo "build finished: no errors, undefined references, or overfull boxes"
fi
